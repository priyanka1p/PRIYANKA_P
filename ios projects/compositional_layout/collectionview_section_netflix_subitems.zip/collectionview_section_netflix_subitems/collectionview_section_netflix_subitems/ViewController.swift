import UIKit

struct Movie {
    let title: String
    let imageURL: String
}

class NetflixStyleViewController: UIViewController, UICollectionViewDelegate {
    var collectionView: UICollectionView!
    
    // Sample data (4 sections)
    let sections: [(title: String, movies: [Movie])] = [
        ("Trending Now", [
            Movie(title: "Movie 1", imageURL: "https://img.freepik.com/free-vector/mother-daughter_24908-83058.jpg"),
            Movie(title: "Movie 2", imageURL: "https://m.economictimes.com/thumb/height-450,width-600,imgsize-24680,msid-121853077/fathers-day.jpg"),
            Movie(title: "Movie 3", imageURL: "https://static.vecteezy.com/system/resources/previews/046/157/418/non_2x/simple-design-of-the-silhouette-of-a-child-and-mother-walking-under-the-rain-vector.jpg"),
            Movie(title: "Movie 12", imageURL: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCGELU32eU9TX1BWS-C9a87XFnZ-FYQlQ-Ow&s"),
            Movie(title: "Movie 4", imageURL: "https://picsum.photos/200/300?random=4"),
            Movie(title: "Movie 5", imageURL: "https://picsum.photos/200/300?random=5"),
            Movie(title: "Movie 3", imageURL: "https://static.vecteezy.com/system/resources/previews/046/157/418/non_2x/simple-design-of-the-silhouette-of-a-child-and-mother-walking-under-the-rain-vector.jpg"),
            Movie(title: "Movie 12", imageURL: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSCGELU32eU9TX1BWS-C9a87XFnZ-FYQlQ-Ow&s"),
            Movie(title: "Movie 4", imageURL: "https://picsum.photos/200/300?random=4"),
            Movie(title: "Movie 5", imageURL: "https://picsum.photos/200/300?random=5"),
            Movie(title: "Movie 6", imageURL: "https://picsum.photos/200/300?random=6")
        
        ]),
        ("Top Picks for You", [
            Movie(title: "Movie 4", imageURL: "https://picsum.photos/200/300?random=4"),
            Movie(title: "Movie 5", imageURL: "https://picsum.photos/200/300?random=5"),
            Movie(title: "Movie 6", imageURL: "https://picsum.photos/200/300?random=6")
        ]),
        ("Continue Watching", [
            Movie(title: "Movie 7", imageURL: "https://picsum.photos/200/300?random=7"),
            Movie(title: "Movie 8", imageURL: "https://picsum.photos/200/300?random=8")
        ]),
        ("New Releases", [
            Movie(title: "Movie 9", imageURL: "https://picsum.photos/200/300?random=9"),
            Movie(title: "Movie 10", imageURL: "https://picsum.photos/200/300?random=10"),
            Movie(title: "Movie 11", imageURL: "https://cdn11.bigcommerce.com/s-x49po/images/stencil/1500x1500/products/52182/279443/1593618449872_IMG_20200528_102333__76288.1687412997.jpg?c=2")
        ])
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Netflix Style"
        view.backgroundColor = .systemBackground
        configureCollectionView()
    }
    
    private func configureCollectionView() {
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: createLayout())
        collectionView.backgroundColor = .systemBackground
        collectionView.register(MovieCell.self, forCellWithReuseIdentifier: MovieCell.reuseId)
        
        // Register both headers
        collectionView.register(HeaderView.self,
                                forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                                withReuseIdentifier: HeaderView.reuseId)
    
        
        collectionView.dataSource = self
        collectionView.delegate = self
        view.addSubview(collectionView)
        
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    private func createLayout() -> UICollectionViewCompositionalLayout {
        return UICollectionViewCompositionalLayout { sectionIndex, _ in
            // Item
            let itemSize = NSCollectionLayoutSize(
                widthDimension: .fractionalWidth(0.5),
                heightDimension: .fractionalHeight(1.0)
            )
            let item = NSCollectionLayoutItem(layoutSize: itemSize)
            item.contentInsets = NSDirectionalEdgeInsets(top: 5, leading: 5, bottom: 5, trailing: 5)
            
            // Group
            let groupSize = NSCollectionLayoutSize(
                widthDimension: .fractionalWidth(0.75),
                heightDimension: .fractionalHeight(0.3)
            )
            let group = NSCollectionLayoutGroup.horizontal(
                layoutSize: groupSize,
                subitem: item,
                count:3
            )
            
            // Section
            let section = NSCollectionLayoutSection(group: group)
            section.orthogonalScrollingBehavior = .groupPagingCentered
            section.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10)
            
            // Header size
            let headerSize = NSCollectionLayoutSize(
                widthDimension: .fractionalWidth(1.0),
                heightDimension: .absolute(60)
            )

            let header = NSCollectionLayoutBoundarySupplementaryItem(
                layoutSize: headerSize,
                elementKind: UICollectionView.elementKindSectionHeader,
                alignment: .top
            )

            // Only one header per section
            section.boundarySupplementaryItems = [header]
            return section
        }
    }
}

// MARK: - DataSource
extension NetflixStyleViewController: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        sections.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        numberOfItemsInSection section: Int) -> Int {
        sections[section].movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let movie = sections[indexPath.section].movies[indexPath.item]
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MovieCell.reuseId, for: indexPath) as! MovieCell
        cell.configure(with: movie, imageURL: movie.imageURL)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(
            ofKind: kind,
            withReuseIdentifier: HeaderView.reuseId,
            for: indexPath
        ) as! HeaderView

        header.titleLabel.text = sections[indexPath.section].title
        header.subtitleLabel.text = "Subheader )"
        header.rightLabel.text = "See All >"

        return header
    }

}
