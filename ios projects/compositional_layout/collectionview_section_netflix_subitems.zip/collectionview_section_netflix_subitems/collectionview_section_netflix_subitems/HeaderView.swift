import UIKit

class HeaderView: UICollectionReusableView {
    static let reuseId = "HeaderView"

    let titleLabel = UILabel()
    let subtitleLabel = UILabel()
    let rightLabel = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)

        titleLabel.font = UIFont.boldSystemFont(ofSize: 18)
        subtitleLabel.font = UIFont.systemFont(ofSize: 14)
        subtitleLabel.textColor = .secondaryLabel

        rightLabel.font = UIFont.systemFont(ofSize: 14)
        rightLabel.textColor = .systemBlue
        //rightLabel.textAlignment = .right

        // Left stack = title + subtitle vertically
        let leftStack = UIStackView(arrangedSubviews: [titleLabel, subtitleLabel])
        leftStack.axis = .vertical
        leftStack.spacing = 2

        // Horizontal stack = left + right
        let mainStack = UIStackView(arrangedSubviews: [leftStack, rightLabel])
        mainStack.axis = .horizontal
        //mainStack.alignment = .center
        mainStack.distribution = .equalSpacing

        addSubview(mainStack)
        mainStack.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            mainStack.topAnchor.constraint(equalTo: topAnchor, constant: 5),
            mainStack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            mainStack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            mainStack.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -5)
        ])
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
}
