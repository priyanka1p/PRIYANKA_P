
import UIKit

class AsyncImageView: UIImageView {
    private static let imageCache = NSCache<NSURL, UIImage>()   // shared cache
    private static var ongoingTasks: [URL: [((UIImage?) -> Void)]] = [:] // to avoid duplicate downloads
    //Without currentURL, if the url1 download finishes late, it might set the wrong image in the reused cell
    private var currentURL: URL?//stores the URL it is currently trying to load.
    
    
    func loadImage(from url: URL, delay: TimeInterval = 0) {
        currentURL = url
        
        // If cached, use immediately
        if let cachedImage = AsyncImageView.imageCache.object(forKey: url as NSURL) {
            print("Loaded from cache: \(url.lastPathComponent)")//prints the image file name
            self.image = cachedImage
            return
        }
        
        // Placeholder if needed
        self.image = UIImage(systemName: "photo")
        
        // If download already in progress, append callback
        if var handlers = AsyncImageView.ongoingTasks[url] {
            print("callback closure called")
            //It adds a closure (callback) to the handlers list.
            //This closure will be called when the first download finishes.
            
            handlers.append { [weak self] img in
                guard let self = self, self.currentURL == url else { return }
                print("inside callback")
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                    self.image = img
                }
            }
            AsyncImageView.ongoingTasks[url] = handlers
            return
        } else {
            print("callback closure ele block called")
            AsyncImageView.ongoingTasks[url] = []//Creates a new entry for this URL with an empty handlers list.
        }
        
        // Start download once
        URLSession.shared.dataTask(with: url) { data, _, error in
            print("called *****************")
            
            var img: UIImage? = nil
            if let data = data, error == nil {
                img = UIImage(data: data)
                if let img = img {
                    //storing the downloaded image into the in-memory cache
                    AsyncImageView.imageCache.setObject(img, forKey: url as NSURL)
                }
            }
            
            DispatchQueue.main.async {
                // Apply image only if still the right cell
                if self.currentURL == url {
                    self.image = img
                }
                // Notify other waiting handlers
                //Prevents duplicate downloads

                if let handlers = AsyncImageView.ongoingTasks[url] {
                    for h in handlers { h(img) }
                }
                AsyncImageView.ongoingTasks[url] = nil
            }
        }.resume()
    }
    
    func cancelLoad() {
        // No cancel needed (downloads continue), just clear current cell’s pointer
        currentURL = nil
    }
}
 

