import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let tableView = UITableView()
    @IBOutlet weak var btn: UIButton!
    
    var names = ["Apple","Banana","Cat","Dog","Elephant","Fish","Giraffe","Horse","Iguana","Jellyfish","Kangaroo","Lion","Monkey","Narwhal","Octopus","Penguin","QUAIL","Apple","Banana","Cat","Dog","Elephant","Fish","Giraffe","Horse","Iguana","Jellyfish","Kangaroo","Lion","Monkey","Narwhal","Octopus","Penguin","QUAIL","shri","You", "Rahul", "Anita", "mohan", "kiran", "ashvika",
        "shruthi", "sheela", "vikram","shri","ashok","1","2","3","4","5","6","7","8","9","10","11",]
    
    
    
    var images = [
        "https://media.istockphoto.com/id/184276818/photo/red-apple.jpg?s=612x612&w=0&k=20&c=NvO-bLsG0DJ_7Ii8SSVoKLurzjmV0Qi4eGfn6nW3l5w=",
        
        "https://learnandsupport.getolympus.com/sites/default/files/styles/hero_large/public/2023-05/20230331-_3310123-edit-ftsmithphotos.jpg?itok=M4h9TNHW",
        
        "https://learnandsupport.getolympus.com/sites/default/files/styles/hero_large/public/2023-05/20230331-_3310123-edit-ftsmithphotos.jpg?itok=M4h9TNHW",
        "https://i.pinimg.com/736x/fd/20/5f/fd205f1b17fa02e44d983d2b63ced660.jpg",
        
        "https://i.pinimg.com/736x/c1/22/de/c122de7d3109ea030ca33dc0a4a6ada3.jpg",
        
        "https://i.pinimg.com/736x/68/1e/aa/681eaad349937f397136be5ac7090026.jpg",
        
        "https://i.pinimg.com/736x/85/9d/22/859d2206848b45014b8d9bd8606a34de.jpg",
        
        "https://i.pinimg.com/736x/09/47/b8/0947b894f1464afcee9e53df20c5ccb6.jpg",
        "https://i.pinimg.com/736x/21/3f/1e/213f1e92d5cf1bce05fca67c7c6ee49e.jpg",
        "https://i.pinimg.com/736x/c0/d3/ac/c0d3ac168bcace037dff94d0d7536cc1.jpg",
        
        "https://i.pinimg.com/736x/85/64/72/85647200497ac46cdc052efda7b428c6.jpg",
        
        "https://i.pinimg.com/736x/2d/80/2d/2d802d6c20313b16f2b6b41ac9577806.jpg",
        
        "https://i.pinimg.com/736x/81/f4/74/81f4748945854167d8d266388205cfb0.jpg",
        
        "https://i.pinimg.com/1200x/11/4c/25/114c250c458483502e20ba8b2fe7b562.jpg",
        
        "https://i.pinimg.com/1200x/68/14/0f/68140fcd50c6e77114181b43eb296acb.jpg",
        
        "https://i.pinimg.com/736x/29/be/84/29be8432012aedbcea35f3a6e3b731e1.jpg",
        
        "https://i.pinimg.com/736x/e8/fd/06/e8fd06290e0817e6622ca023be91a750.jpg",
        
        "https://media.istockphoto.com/id/184276818/photo/red-apple.jpg?s=612x612&w=0&k=20&c=NvO-bLsG0DJ_7Ii8SSVoKLurzjmV0Qi4eGfn6nW3l5w=",
        
        
        "https://learnandsupport.getolympus.com/sites/default/files/styles/hero_large/public/2023-05/20230331-_3310123-edit-ftsmithphotos.jpg?itok=M4h9TNHW",
        
        "https://cdn.pixabay.com/photo/2017/11/09/21/41/cat-2934720_1280.jpg",
        
        "https://i.pinimg.com/736x/fd/20/5f/fd205f1b17fa02e44d983d2b63ced660.jpg",
        
        "https://i.pinimg.com/736x/c1/22/de/c122de7d3109ea030ca33dc0a4a6ada3.jpg",
        
        "https://i.pinimg.com/736x/68/1e/aa/681eaad349937f397136be5ac7090026.jpg",
        
        "https://i.pinimg.com/736x/85/9d/22/859d2206848b45014b8d9bd8606a34de.jpg",
        
        "https://i.pinimg.com/736x/09/47/b8/0947b894f1464afcee9e53df20c5ccb6.jpg",
        "https://i.pinimg.com/736x/21/3f/1e/213f1e92d5cf1bce05fca67c7c6ee49e.jpg",
        "https://i.pinimg.com/736x/c0/d3/ac/c0d3ac168bcace037dff94d0d7536cc1.jpg",
        
        "https://i.pinimg.com/736x/85/64/72/85647200497ac46cdc052efda7b428c6.jpg",
        
        "https://i.pinimg.com/736x/2d/80/2d/2d802d6c20313b16f2b6b41ac9577806.jpg",
        
        "https://i.pinimg.com/736x/81/f4/74/81f4748945854167d8d266388205cfb0.jpg",
        
        "https://i.pinimg.com/1200x/11/4c/25/114c250c458483502e20ba8b2fe7b562.jpg",
        
        "https://i.pinimg.com/1200x/68/14/0f/68140fcd50c6e77114181b43eb296acb.jpg",
        
        "https://i.pinimg.com/736x/29/be/84/29be8432012aedbcea35f3a6e3b731e1.jpg",
        
        "https://i.pinimg.com/736x/e8/fd/06/e8fd06290e0817e6622ca023be91a750.jpg",
        "https://i.pinimg.com/736x/bf/1a/03/bf1a031f0f65e284e2d500009ab78263.jpg",
        
        "https://runtothefinish.com/wp-content/uploads/2023/04/Topo-Ultraventure.jpg",
        
        "https://t3.ftcdn.net/jpg/07/80/61/16/360_F_780611640_2NsIsJuDJ66EdVB9I1I06aCdUC8ERIGl.jpg",
        
        "https://i.pinimg.com/736x/bf/1a/03/bf1a031f0f65e284e2d500009ab78263.jpg",
        
        "https://runtothefinish.com/wp-content/uploads/2023/04/Topo-Ultraventure.jpg",
        
        "https://cdn.pixabay.com/photo/2024/05/26/10/15/bird-8788491_1280.jpg",
        
        "https://i.pinimg.com/736x/bf/1a/03/bf1a031f0f65e284e2d500009ab78263.jpg",
        
        "https://runtothefinish.com/wp-content/uploads/2023/04/Topo-Ultraventure.jpg",
        
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9EZNefY1fRsA4qVFTBviWyj-5KHY6U8LG0g&s",
        
        "https://media.istockphoto.com/id/814423752/photo/eye-of-model-with-colorful-art-make-up-close-up.jpg?s=612x612&w=0&k=20&c=l15OdMWjgCKycMMShP8UK94ELVlEGvt7GmB_esHWPYE=",
        
        "https://cdn.pixabay.com/photo/2024/05/26/10/15/bird-8788491_1280.jpg",
        
        "https://learnandsupport.getolympus.com/sites/default/files/styles/hero_large/public/2023-05/20230331-_3310123-edit-ftsmithphotos.jpg?itok=M4h9TNHW",
        
        "https://runtothefinish.com/wp-content/uploads/2023/04/Topo-Ultraventure.jpg",
        
        "https://cdn.pixabay.com/photo/2024/05/26/10/15/bird-8788491_1280.jpg",
        
        "https://cdn.imago-images.com/Images/header/hello-we-are-imago_03-2023.jpg",
        "https://tinypng.com/static/images/boat.png",
        
        "https://thumbs.dreamstime.com/b/monarch-orange-butterfly-bright-summer-flowers-background-blue-foliage-fairy-garden-macro-artistic-image-monarch-167030287.jpg",
        
        "https://static.vecteezy.com/system/resources/thumbnails/057/068/323/small/single-fresh-red-strawberry-on-table-green-background-food-fruit-sweet-macro-juicy-plant-image-photo.jpg",
        
        "https://www.befunky.com/images/prismic/1f427434-7ca0-46b2-b5d1-7d31843859b6_funky-focus-red-flower-field-after.jpeg?auto=avif,webp&format=jpg&width=863",
        
        "https://cdn.pixabay.com/photo/2016/04/05/11/04/india-1309206_1280.jpg",
        "https://cdn.pixabay.com/photo/2023/09/21/14/17/italy-8266783_1280.jpg",
        
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRoBuMvSuYezLE9rwI-zOJeIOmcIGfDPqOvFA&s",
        
        "https://images.squarespace-cdn.com/content/v1/57879a6cbebafb879f256735/1712832754805-I7IJ7FRXF629FN3PIS3O/KC310124-27.jpg",
        
        
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        
        tableView.delegate = self
        tableView.dataSource = self
        
        //UITableView doesn’t automatically know what a "ContactCell" is.
        //        When you dequeue a reusable cell, the table view looks in its reuse pool.
        //If a cell exists → it reuses it.
        
        tableView.register(ContactCell.self, forCellReuseIdentifier: "ContactCell")
        tableView.rowHeight = UITableView.automaticDimension
        
        //        It’s just a guess (in points) for each cell’s height.
        //        The table view will use this number initially while scrolling and rendering cells offscreen.
        //        Once a cell is about to appear, Auto Layout calculates its real height and replaces the estimate.
        //        tableView.estimatedRowHeight = 150
        
        // Add "Edit" and "Add" buttons to navigation bar
        navigationItem.rightBarButtonItem = editButtonItem
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add,
                                                           target: self,
                                                           action: #selector(addContact))
        
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: btn.topAnchor, constant: -20)
        ])
    }
    
    override func setEditing(_ editing: Bool, animated: Bool) {
        
        super.setEditing(editing, animated: animated)//Edit button won’t toggle automatically.
        tableView.setEditing(editing, animated: true)// It tells the table view to enter or exit editing mode.
    }
    // TableView DataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactCell", for: indexPath) as! ContactCell
        print("Reusing/creating cell for row: \(indexPath.row)")
        
        cell.nameLabel.text = names[indexPath.row]
        if let url = URL(string: images[indexPath.row]) {
            cell.profileImageView.loadImage(from: url, delay: 2.0) // delay
        }
        return cell
    }
    
    
    //     Disable swipe-to-delete which is default
    func tableView(_ tableView: UITableView,
                   canEditRowAt indexPath: IndexPath) -> Bool {
        
        return tableView.isEditing   // only editable in edit mode
    }
    
    func tableView(_ tableView: UITableView,
                   trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath)
    -> UISwipeActionsConfiguration? {
        
        print("trailing swipe")
        //action,view,completion , red - destructive
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { _,_,completion in
            self.names.remove(at: indexPath.row)
            self.images.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            completion(true)
        }
        
        let insertAction = UIContextualAction(style: .normal, title: "Insert") { _,_,completion in
            
            let alert = UIAlertController(title: "New Contact",message: "Enter a name",preferredStyle:.alert)
            alert.addTextField { textField in
                textField.placeholder = "Name"
            }
            
            let addAction = UIAlertAction(title: "Add", style: .default) { _ in
                if let name = alert.textFields?.first?.text, !name.isEmpty {
                    // Insert at indexPath.row + 1
                    self.names.insert(name, at: indexPath.row + 1)
                    self.images.insert("https://cdn.mos.cms.futurecdn.net/B8yswTP4sxA9mQGHWvxfwP.jpg",
                                       at: indexPath.row + 1)
                    
                    let newIndexPath = IndexPath(row: indexPath.row + 1, section: 0)
                    tableView.insertRows(at: [newIndexPath], with: .automatic)
                }
                completion(true) // Finish swipe action
            }
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
                completion(false)
            }
            
            alert.addAction(addAction)
            alert.addAction(cancelAction)
            
            if let vc = tableView.window?.rootViewController {
                vc.present(alert, animated: true, completion: nil)
            }
        }
        
        insertAction.backgroundColor = .blue
        //For this row, when the user swipes from the trailing edge (right-to-left), show these two contextual actions: deleteAction and insertAction
        return UISwipeActionsConfiguration(actions: [deleteAction, insertAction])
    }
    
    //    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
    //        print("HEIGHTforfooterinsection")
    //
    //        return 200
    //    }
    //
//        func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
//            print("viewforfooterinsection")
//            let v = UIView()
//            v.backgroundColor = .blue
//            return v
//        }
    
    
    //    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    //        return 100   // or different height per indexPath
    //    }
    
    // Handle row tap
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let contact = names[indexPath.row]
        print("Tapped: \(contact)")
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    // which row can able to move
    //    func tableView(_ tableView: UITableView,
    //                   canMoveRowAt indexPath: IndexPath) -> Bool {
    //        return true
    //    }
    
    
    func tableView(_ tableView: UITableView,
                   moveRowAt sourceIndexPath: IndexPath,
                   to destinationIndexPath: IndexPath) {
        let movedName = names.remove(at: sourceIndexPath.row)
        let movedImage = images.remove(at: sourceIndexPath.row)
        
        names.insert(movedName, at: destinationIndexPath.row)
        images.insert(movedImage, at: destinationIndexPath.row)
    }
    
    @objc func addContact() {
        let alert = UIAlertController(title: "Add Contact",
                                      message: "Enter a name for the new contact",
                                      preferredStyle: .alert)
        
        // Add text field to alert
        alert.addTextField { textField in
            textField.placeholder = "Enter name"
        }
        
        // Add "Cancel" button
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        // Add "Add" button
        alert.addAction(UIAlertAction(title: "Add", style: .default, handler: { [weak self] _ in
            guard let self = self else { return }
            if let name = alert.textFields?.first?.text, !name.isEmpty {
                // Append user input to names array
                self.names.append(name)
                
                self.images.append("https://cdn.pixabay.com/photo/2024/05/26/10/15/bird-8788491_1280.jpg")
                
                let newIndexPath = IndexPath(row: self.names.count - 1, section: 0)
                self.tableView.insertRows(at: [newIndexPath], with: .automatic)
            }
        }))
        
        // Present the alert
        present(alert, animated: true, completion: nil)
    }
    
}
