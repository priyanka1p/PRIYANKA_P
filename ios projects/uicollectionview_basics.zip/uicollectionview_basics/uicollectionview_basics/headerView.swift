import UIKit
class headerView: UICollectionReusableView {
    static let reuseIdentifier = "hv"
    let title = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .lightGray
        title.textAlignment = .center
        title.font = UIFont.boldSystemFont(ofSize: 18)
        addSubview(title)
        title.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            title.centerXAnchor.constraint(equalTo: centerXAnchor),
            title.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
