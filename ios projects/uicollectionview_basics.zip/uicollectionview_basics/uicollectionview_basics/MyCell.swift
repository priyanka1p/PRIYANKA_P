//
//  MyCell.swift
//  uicollectionview_basics
//
//  Created by Priyanka on 05/09/25.
//

import UIKit

class MyCell: UICollectionViewCell {
    var label = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        label.backgroundColor = .black
        label.textColor = .white
        label.textAlignment = .center
        contentView.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            label.topAnchor.constraint(equalTo: contentView.topAnchor),
            label.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            label.leftAnchor.constraint(equalTo: contentView.leftAnchor),
            label.rightAnchor.constraint(equalTo: contentView.rightAnchor)
        ])
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


