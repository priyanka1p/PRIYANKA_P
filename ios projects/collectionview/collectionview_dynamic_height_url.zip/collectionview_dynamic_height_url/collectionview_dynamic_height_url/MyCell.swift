//
//  MyCell.swift
//  collectionview_dynamic_height_url
//
//  Created by Priyanka on 08/09/25.
//

import UIKit

class MyCell: UICollectionViewCell {
    static let id = "cell"
    private var currentURL:String?
    private let imgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private let label: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        let stack = UIStackView(arrangedSubviews: [imgView, label])
        stack.axis = .vertical
        stack.spacing = 0
        
        stack.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(stack)
        
        NSLayoutConstraint.activate([
            imgView.widthAnchor.constraint(equalToConstant: 250),
            imgView.heightAnchor.constraint(equalToConstant: 150),
            stack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            stack.topAnchor.constraint(equalTo: contentView.topAnchor),
            stack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
            ])
        
    }
    
    func configure(img:String, para:String){
        label.text = para
        currentURL = img
        if let url = URL(string: img){
            URLSession.shared.dataTask(with: url) { data, _, _ in
                if let data = data, let imgage = UIImage(data: data) {
                    if self.currentURL == img {
                        DispatchQueue.main.async { self.imgView.image = imgage }
                    }
                }
            }.resume()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

