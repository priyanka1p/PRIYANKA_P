//
//  ViewController.swift
//  collectionview_dynamic_height_url
//
//  Created by Priyanka on 08/09/25.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource {
    
    private var collectionView: UICollectionView!
    
    private let comments: [(image: String, text: String)] = [
        ("https://img.freepik.com/free-vector/mother-daughter_24908-83058.jpg", "This is a short comment."),
        ("https://m.economictimes.com/thumb/height-450,width-600,imgsize-24680,msid-121853077/fathers-day.jpg"
         , "This comment is a bit longer and should wrap to multiple lines in order to test the dynamic height resizing of ouThis comment is a bit longer and should wrap to multiple lines in order to test the dynamic height resizing of ouThis comment is a bit longer and should wrap to multiple lines in order to test the dynamic height resizing of our UICollectionViewCell."),
        ("https://img.freepik.com/free-vector/mother-daughter_24908-83058.jpg", "TinyThis comment is a bit longer and should wrap to multiple lines in order to test the dynamic height resizing of ouThis comment is a bit longer and should wrap to multiple lines in order to test the dynamic height resizing of ouThis comment is a bit longer and should wrap to multiple lines in order to test the dynamic height resizing of ouThis comment is a bit longer and should wrap to multiple lines in order to test the dynamic height resizing of ou."),
        ("https://m.economictimes.com/thumb/height-450,width-600,imgsize-24680,msid-121853077/fathers-day.jpg"
         , "Sometimes we need UICollectionView’s cells to resize based on their content. This example demonstrates dynamic sizing using Auto Layout and preferredLayoutAttributesFitting. Works on iOS 14+ without third-party libraries!")
    ]
    override func viewDidLoad() {
        super.viewDidLoad()
        let layout = UICollectionViewFlowLayout()
        layout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
        layout.minimumLineSpacing = 10
        
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.register(MyCell.self, forCellWithReuseIdentifier: MyCell.id)
        view.addSubview(collectionView)
        collectionView.dataSource = self
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)])
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return comments.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MyCell.id, for: indexPath) as? MyCell else{
            return UICollectionViewCell()
        }
        let item = comments[indexPath.item]
        cell.configure(img: item.image, para: item.text)
        return cell
    }
    
}

