//
import UIKit

class MyCell: UICollectionViewCell {
    var img = UIImageView()
    var label = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        // Configure image
        img.contentMode = .scaleAspectFit
        img.clipsToBounds = true
        img.backgroundColor = .systemMint
        img.layer.borderWidth = 1
        
        // Configure label
        label.textColor = .white
        label.textAlignment = .center
        label.numberOfLines = 0
        let labelContainer = UIView()
        labelContainer.backgroundColor = .black

        label.translatesAutoresizingMaskIntoConstraints = false
        labelContainer.addSubview(label)

        NSLayoutConstraint.activate([
            label.topAnchor.constraint(equalTo: labelContainer.topAnchor, constant: 10),
            label.leadingAnchor.constraint(equalTo: labelContainer.leadingAnchor, constant: 10),
            label.trailingAnchor.constraint(equalTo: labelContainer.trailingAnchor, constant: -10),
            label.bottomAnchor.constraint(equalTo: labelContainer.bottomAnchor, constant: -10)
        ])
        // StackView
        let stack = UIStackView(arrangedSubviews: [img, labelContainer])
        stack.axis = .vertical
        stack.spacing = 0
        stack.alignment = .fill
        stack.distribution = .fill
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addSubview(stack)
        
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 0),
            stack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 0),
            stack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: 0),
            stack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: 0)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


extension UIImageView {
    func loadImage(from url: URL) {
        DispatchQueue.global().async {
            if let data = try? Data(contentsOf: url),
               let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.image = image
                }
            } else {
                DispatchQueue.main.async {
                    self.image = UIImage(systemName: "photo") // fallback
                }
            }
        }
    }
}

        


 
