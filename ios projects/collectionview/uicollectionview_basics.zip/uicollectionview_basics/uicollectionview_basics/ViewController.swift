import UIKit

class ViewController: UIViewController {
    var collectionView: UICollectionView!
    var image:[String] = [
        "https://media.istockphoto.com/id/184276818/photo/red-apple.jpg?s=612x612&w=0&k=20&c=NvO-bLsG0DJ_7Ii8SSVoKLurzjmV0Qi4eGfn6nW3l5w=",
        
        "https://learnandsupport.getolympus.com/sites/default/files/styles/hero_large/public/2023-05/20230331-_3310123-edit-ftsmithphotos.jpg?itok=M4h9TNHW",
        
        "https://learnandsupport.getolympus.com/sites/default/files/styles/hero_large/public/2023-05/20230331-_3310123-edit-ftsmithphotos.jpg?itok=M4h9TNHW",
        "https://i.pinimg.com/736x/fd/20/5f/fd205f1b17fa02e44d983d2b63ced660.jpg",
        
        "https://i.pinimg.com/736x/c1/22/de/c122de7d3109ea030ca33dc0a4a6ada3.jpg",
        
        "https://i.pinimg.com/736x/68/1e/aa/681eaad349937f397136be5ac7090026.jpg",
        
        "https://i.pinimg.com/736x/85/9d/22/859d2206848b45014b8d9bd8606a34de.jpg",
        
        "https://i.pinimg.com/736x/09/47/b8/0947b894f1464afcee9e53df20c5ccb6.jpg",
        "https://i.pinimg.com/736x/21/3f/1e/213f1e92d5cf1bce05fca67c7c6ee49e.jpg",
        "https://i.pinimg.com/736x/c0/d3/ac/c0d3ac168bcace037dff94d0d7536cc1.jpg",
      
    ]
    var data = ["rani","ayoutConstraate([img.topAnchor.conontentView.topAnchor, constant: 10),img.raint(equalTo: conte, constant:label.topAncht(equalTo: img.botttomAnchor, constant: 100),label.bottomraint(equalTo: cotentView.bottomAnchor),label.leftAnchstraint(equalTo: contentView.leftAnchor), labelAnchor.constraint(equalTo: contentViewgfytgu.rightAnchor)ayoutConstraate([img.topAnchor.conontentView.topAnchor, constant: 10),img.raint(equalTo: conte, constant:label.topAncht(equalTo: img.botttomAnchor, constant: 100),label.bottomraint(equalTo: cotentView.bottomAnchor),label.leftAnchstraint(equalTo: contentView.leftAnchor), labelAnchor.constraint(equalTo: contentViewgfytgu.rightAnchor)", "A","b","c","d","e","f","g","h"]

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Demo"
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        

        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.register(MyCell.self, forCellWithReuseIdentifier: "myCell")
        collectionView.register(headerView.self,
                                forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader,
                                withReuseIdentifier: "hv")

        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(collectionView)

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leftAnchor.constraint(equalTo: view.leftAnchor, constant: 10),
            collectionView.rightAnchor.constraint(equalTo: view.rightAnchor, constant: -10),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])


    }
}

extension ViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.count
    }

    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCell", for: indexPath) as! MyCell
        
        cell.label.text = data[indexPath.row]

        if let url = URL(string: image[indexPath.row]) {
            cell.img.loadImage(from: url)
        }
        
        return cell
    }

    func collectionView(_ collectionView: UICollectionView,
                        viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(
            ofKind: kind,
            withReuseIdentifier: "hv",
            for: indexPath
        ) as! headerView
        header.title.text = "Topic"
        return header
    }
}

extension ViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView,
                           layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        // Calculate label height dynamically
        let text = data[indexPath.row]
        let font = UIFont.systemFont(ofSize: 29)
        let labelWidth = collectionView.frame.width
        
        let boundingRect = NSString(string: text).boundingRect(
            with: CGSize(width: labelWidth, height: CGFloat.greatestFiniteMagnitude),
            options: [ .usesLineFragmentOrigin],
            attributes: [.font: font],
            context: nil
        )
        
        let labelHeight = ceil(boundingRect.height)
        
        
        // Image height = width * 0.75
        let imageHeight = labelWidth * 0.75
        
        // Total cell height
        let cellHeight =  imageHeight + labelHeight 
        
        print(collectionView.frame.width)
        return CGSize(width: labelWidth, height: cellHeight)
        
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 50) 
    }
}

extension ViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        print("Highlight item at \(indexPath)")
    }

    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        print("Unhighlight item at \(indexPath)")
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("Tapped item at section \(indexPath.section), row \(indexPath.item)")
    }

    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        print("Deselected item at \(indexPath)")
    }
}


