import UIKit

class ViewController: UIViewController, UICollectionViewDataSource {

    private var collectionView: UICollectionView!

    private let comments: [(image: String, text: String)] = [
        ("https://img.freepik.com/free-vector/mother-daughter_24908-83058.jpg", "This is a short comment."),
        ("https://m.economictimes.com/thumb/height-450,width-600,imgsize-24680,msid-121853077/fathers-day.jpg",
         "This comment is a bit longer and should wrap to multiple lines in order to test the dynamic height resizing of our UICollectionViewCell."),
        ("https://img.freepik.com/free-vector/mother-daughter_24908-83058.jpg",
         "Tiny. This comment is longer and should wrap across multiple lines to demonstrate proper dynamic sizing."),
        ("https://m.economictimes.com/thumb/height-450,width-600,imgsize-24680,msid-121853077/fathers-day.jpg",
         "Sometimes we need UICollectionView’s cells to resize based on their content. This example demonstrates dynamic sizing using Auto Layout and preferredLayoutAttributesFitting.")
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Dynamic Comments"  // Added from first code

        let layout = UICollectionViewFlowLayout()
        layout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
        layout.minimumLineSpacing = 10
        layout.sectionInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10) // optional

        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.register(MyCell.self, forCellWithReuseIdentifier: MyCell.id)

        view.addSubview(collectionView)
        collectionView.dataSource = self
        collectionView.delegate = self   // Added delegate to match first code

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("numberofitemsinsection")
        return comments.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        print("cellfor item at")
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MyCell.id, for: indexPath) as? MyCell else {
            return UICollectionViewCell()
        }
        let item = comments[indexPath.item]
        cell.configure(img: item.image, para: item.text)
        return cell
    }
}

extension ViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        print("sizeforitemat")
        let width = (collectionView.bounds.width - 20) // respect left+right insets
        return CGSize(width: width , height: UICollectionViewFlowLayout.automaticSize.height)
    }
}





