//
//  MyCell.swift
//  collectionview_dynamic_height_url_preferred
//
//  Created by Priyanka on 09/09/25.
//


import UIKit

class MyCell: UICollectionViewCell {
    static let id = "cell"
    private var currentURL: String?

    private let imgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFit
        imgView.translatesAutoresizingMaskIntoConstraints = false
        return imgView
    }()

    private let label: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 15)
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        print("mycell override")
        contentView.backgroundColor = .secondarySystemBackground
        setupViews()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupViews() {
        let stack = UIStackView(arrangedSubviews: [imgView, label])
        stack.axis = .vertical
        stack.spacing = 8
        stack.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(stack)

        NSLayoutConstraint.activate([
            imgView.heightAnchor.constraint(equalToConstant: 250),

            stack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 0),
            stack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 0),
            stack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: 0),
            stack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10)
        ])
    }

    func configure(img: String, para: String) {
        print("configure")
        label.text = para
        currentURL = img
        imgView.image = UIImage(systemName: "film") // placeholder

        if let url = URL(string: img) {
            URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
                guard let self = self else { return }
                if let data = data, let image = UIImage(data: data) {
                    if self.currentURL == img {
                        DispatchQueue.main.async {
                            self.imgView.image = image
                        }
                    }
                }
            }.resume()
        }
    }

    /// systemLayoutSizeFitting asks Auto Layout:
//    Given my constraints, how much space do I need?”
//    It returns a CGSize that satisfies all your constraints.
//    The width is taken from layoutAttributes.size.width (the proposed width from the layout).
//    The height is computed based on your content (label text wrapping, spacing, etc.).
    override func preferredLayoutAttributesFitting(
        //layoutAttributes contains information about the cell’s frame (position & size) as proposed by the layout.
        _ layoutAttributes: UICollectionViewLayoutAttributes
    ) -> UICollectionViewLayoutAttributes {
        //Something may have changed, recalc constraints on next layout.
        setNeedsLayout()
//        Forces the cell to immediately lay out its subviews (image view, label, stack view).
//        Ensures Auto Layout has calculated the correct sizes before you measure the content.
        layoutIfNeeded()

        let size = contentView.systemLayoutSizeFitting(layoutAttributes.size)
        var newFrame = layoutAttributes.frame
        newFrame.size.height = ceil(size.height)
        layoutAttributes.frame = newFrame
        return layoutAttributes
    }
}
