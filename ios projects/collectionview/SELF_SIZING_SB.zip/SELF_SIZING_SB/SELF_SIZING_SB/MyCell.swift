import UIKit

class MyCell: UICollectionViewCell {
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var mainView: UIView!
    private var currentURL: String!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        // Fix width, allow height to grow dynamically
        imgView.contentMode = .scaleAspectFit
        imgView.clipsToBounds = true
        mainView.backgroundColor = .systemPink
//        let height = UIScreen.main.bounds.height - 140 // 20 left + 20 right
//        contentView.heightAnchor.constraint(equalToConstant: height).isActive = true
        let width = UIScreen.main.bounds.width - 40 // 20 left + 20 right
        contentView.widthAnchor.constraint(equalToConstant: width).isActive = true
        print(width)
    }
    func configure(img:String){
        currentURL = img
        if let url = URL(string: img){
            URLSession.shared.dataTask(with: url) { data, _, _ in
                if let data = data, let imgage = UIImage(data: data) {
                    if self.currentURL == img {
                        DispatchQueue.main.async { self.imgView.image = imgage }
                    }
                }
            }.resume()
        }
    }
}
