import UIKit

class ViewController: UIViewController, UICollectionViewDataSource {
    
    @IBOutlet weak var collectionView: UICollectionView!
    let image = ["https://img.freepik.com/free-vector/mother-daughter_24908-83058.jpg",
                 "https://m.economictimes.com/thumb/height-450,width-600,imgsize-24680,msid-121853077/fathers-day.jpg",
                 "https://static.vecteezy.com/system/resources/previews/046/157/418/non_2x/simple-design-of-the-silhouette-of-a-child-and-mother-walking-under-the-rain-vector.jpg",
                 "https://img.freepik.com/free-vector/mother-daughter_24908-83058.jpg",
                 "https://m.economictimes.com/thumb/height-450,width-600,imgsize-24680,msid-121853077/fathers-day.jpg",
                 "https://static.vecteezy.com/system/resources/previews/046/157/418/non_2x/simple-design-of-the-silhouette-of-a-child-and-mother-walking-under-the-rain-vector.jpg",
                 "https://img.freepik.com/free-vector/mother-daughter_24908-83058.jpg",
                 "https://m.economictimes.com/thumb/height-450,width-600,imgsize-24680,msid-121853077/fathers-day.jpg",
                 "https://static.vecteezy.com/system/resources/previews/046/157/418/non_2x/simple-design-of-the-silhouette-of-a-child-and-mother-walking-under-the-rain-vector.jpg",
                 "https://m.economictimes.com/thumb/height-450,width-600,imgsize-24680,msid-121853077/fathers-day.jpg",
                 "https://img.freepik.com/free-vector/mother-daughter_24908-83058.jpg",
                 "https://m.economictimes.com/thumb/height-450,width-600,imgsize-24680,msid-121853077/fathers-day.jpg",



    ]
    var comments = [
        "This is a short comment.",
        "This is a much longer comment that should automatically expand the cell height so you don’t need to hardcode anything.",
        "Tiny.",
        "Another example of a multi-line self-sizing UICollectionViewCell using Auto Layout and Storyboard/XIB.","This is a short comment.",
        "This is a much longer comment that should automatically expand the cell height so you don’t need to hardcode anything.Another example of a multi-line self-sizing UICollectionViewCell using Auto Layout and Storyboard/XIB.Another example of a multi-line self-sizing UICollectionViewCell using Auto Layout and Storyboard/XIB.",
        "Tiny.",
        "Another example of a multi-line self-sizing UICollectionViewCell using Auto Layout and Storyboard/XIB.",
        "This is a short comment.Another example of a multi-line self-sizing UICollectionViewCell using Auto Layout and Storyboard/XIB.",
        "This is a much longer comment that should automatically expand the cell height so you don’t need to hardcode anything.",
        "Tiny.",
        "Another example of a multi-line self-sizing UICollectionViewCell using Auto Layout and Storyboard/XIB."
        
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Register XIB cell
        collectionView.register(UINib(nibName: "MyCell", bundle: nil), forCellWithReuseIdentifier: "MyCell")
        collectionView.dataSource = self
//        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
//            layout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
//        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.comments[2] = "This is a much longer comment that should automatically expand the cell height so you don’t need to hardcode anything."
            self.collectionView.reloadData()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print(comments.count)
        return comments.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MyCell", for: indexPath) as! MyCell
        cell.titleLabel.text = comments[indexPath.item]
        cell.configure(img: image[indexPath.item])
        cell.backgroundColor = .systemBlue
        return cell
    }
}
