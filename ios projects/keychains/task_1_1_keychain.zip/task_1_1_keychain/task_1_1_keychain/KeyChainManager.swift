import Foundation
import Security

class KeychainManager {
    static let shared = KeychainManager()
    private init() {}

    private let service = "com.priyanka.task-1-1-keychain"

    // Save item (email/password) in Keychain
    private func save(_ value: String, account: String) -> Bool {
        guard let data = value.data(using: .utf8) else { return false }

        // Delete old item if exists
        delete(account: account)

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data
        ]

        let status = SecItemAdd(query as CFDictionary, nil)
        return status == errSecSuccess
    }

    private func get(account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,   // <--- IMPORTANT
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var item: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess,
              let data = item as? Data,
              let value = String(data: data, encoding: .utf8) else { return nil }
        return value
    }

    private func delete(account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }

    func saveEmail(_ email: String) -> Bool {
        return save(email, account: "userEmail")
    }

    func savePassword(_ password: String) -> Bool {
        return save(password, account: "userPassword")
    }

    func getEmail() -> String? {
        return get(account: "userEmail")
    }

    func getPassword() -> String? {
        return get(account: "userPassword")
    }

    func deleteEmail() {
        delete(account: "userEmail")
    }

    func deletePassword() {
        delete(account: "userPassword")
    }

    func clearAll() {
        deleteEmail()
        deletePassword()
    }
}
