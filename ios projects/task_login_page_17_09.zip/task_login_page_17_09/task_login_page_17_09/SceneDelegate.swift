import UIKit
import UIKit
class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    
    var window: UIWindow?
    
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        
        guard let windowScene = (scene as? UIWindowScene) else { return }
        
        window = UIWindow(windowScene: windowScene)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        //get the login state which is stored in userdefaults
        let isLoggedIn = UserDefaults.standard.bool(forKey: "isLoggedIn")
        
        //check which view controller to be displayed based on login state and valid credentials.
        //if all are valid, go to home page
        //else, go to login page
        if isLoggedIn,
           let savedEmail = KeychainManager.shared.get(account: AccountName.userEmail.rawValue),
           let savedPassword = KeychainManager.shared.get(account: AccountName.userPassword.rawValue) {
            
            print("isloggedin ",savedEmail,savedPassword)
            //call api to check credentials valid or not
            AuthService.shared.login(email: savedEmail, password: savedPassword) { result in
                DispatchQueue.main.async {
                    print("scene")
                    switch result {
                    case .success(let authResponse):
                        let homeVC = storyboard.instantiateViewController(withIdentifier: "homeVC") as! HomeViewController
                        homeVC.userName = authResponse.userName
                        homeVC.thumbNail = authResponse.thumbnail
                        self.window?.rootViewController = UINavigationController(rootViewController: homeVC)
                        self.window?.makeKeyAndVisible()
                        
                    case .failure:
                        print("failure")
                        ImageDownloader.clearCache()
                        KeychainManager.shared.delete(account: AccountName.userEmail.rawValue)
                        KeychainManager.shared.delete(account: AccountName.userPassword.rawValue)
                        UserDefaults.standard.set(false, forKey: "isLoggedIn")
                        let loginVC = storyboard.instantiateViewController(withIdentifier: "loginVC") as! ViewController
                        self.window?.rootViewController = UINavigationController(rootViewController: loginVC)
                        self.window?.makeKeyAndVisible()
                    }
                }
            }
        } else {
            
            let loginVC = storyboard.instantiateViewController(withIdentifier: "loginVC") as! ViewController
            window?.rootViewController = UINavigationController(rootViewController: loginVC)
            window?.makeKeyAndVisible()
        }
    }
}

