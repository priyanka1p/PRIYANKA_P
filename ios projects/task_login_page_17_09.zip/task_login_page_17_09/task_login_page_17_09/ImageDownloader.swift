import UIKit

class ImageDownloader: UIImageView {
    
    static let imageCache = NSCache<NSURL, UIImage>() // memory cache
    private var receivedData = Data() // to receive data  from server
    private var currentURL: URL? // to store image url
    var aspectRatioConstraint: NSLayoutConstraint? // to set constraints for image
    
    // Disk cache directory
    static var diskDirectory: URL = {
        let directory = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask)[0]
        let diskDirectory = directory.appendingPathComponent("ios_login")
        
        if !FileManager.default.fileExists(atPath: diskDirectory.path) {
            try? FileManager.default.createDirectory(at: diskDirectory,
                                                     withIntermediateDirectories: true)
        }
        return diskDirectory
    }()
    
    func startDownload(url: URL) {
        currentURL = url
        
        // Check memory cache
        if let cachedImage = ImageDownloader.imageCache.object(forKey: url as NSURL) {
            print("Loaded from memory cache")
            self.setImage(cachedImage)
            return
        }
        
        // Check disk cache
        let filename = url.lastPathComponent
        let diskFile = ImageDownloader.diskDirectory.appendingPathComponent(filename)
        if FileManager.default.fileExists(atPath: diskFile.path),
           let image = UIImage(contentsOfFile: diskFile.path) {
            print("Loaded from disk cache")
            ImageDownloader.imageCache.setObject(image, forKey: url as NSURL)
            self.setImage(image)
            return
        }
        
        // Show placeholder
        self.image = UIImage(systemName: "photo")
        
        // Start download
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: self, delegateQueue: nil)
        let task = session.dataTask(with: url)
        task.resume()
    }
    
    //to delete files from disk
    static func clearCache() {
        //delete from cache
        imageCache.removeAllObjects()
        if FileManager.default.fileExists(atPath: diskDirectory.path) {
            try? FileManager.default.removeItem(at: diskDirectory)
            print("Cleared disk cache at:", diskDirectory.path)
        }
    }
    //imageview constraints wrt to image aspect ratio
    func setImage(_ image: UIImage) {
        self.image = image
        
        // Remove old constraint if any
        if let oldConstraint = aspectRatioConstraint {
            print("remove constraint")
            self.removeConstraint(oldConstraint)
        }
        // Add new aspect ratio
        let aspectRatio = image.size.height / image.size.width
        aspectRatioConstraint = self.heightAnchor.constraint(equalTo: self.widthAnchor,multiplier: aspectRatio)
        aspectRatioConstraint?.isActive = true
    }
}

extension ImageDownloader:URLSessionDataDelegate{
    func urlSession(
        _ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive response: URLResponse,
        completionHandler: @escaping (URLSession.ResponseDisposition) -> Void
    ) {
        print("Server responding")
        receivedData = Data()
        completionHandler(.allow)
    }
    
    func urlSession(
        _ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive data: Data
    ) {
        receivedData.append(data)
    }
    
    func urlSession(
        _ session: URLSession,
        task: URLSessionTask,
        didCompleteWithError error: Error?
    ) {
        if let error = error {
            print("Download error:", error)
            return
        }
        
        guard let image = UIImage(data: receivedData),
              let url = currentURL else {
            print("Failed to decode image")
            return
        }
        //add to memory cache
        ImageDownloader.imageCache.setObject(image, forKey: url as NSURL)
        let filename = url.lastPathComponent
        let diskFile = ImageDownloader.diskDirectory.appendingPathComponent(filename)
        //write to disk
        try? receivedData.write(to: diskFile)
        print("Saved to disk cache:")
        
        DispatchQueue.main.async {
            self.setImage(image)
        }
    }
}
