import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    //outlets of text field
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    // Labels to show email/password validation messages
    @IBOutlet weak var emailValidationLabel: UILabel!
    @IBOutlet weak var passwordValidationLabel: UILabel!
    
    // Login buttons
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var appleButton: UIButton!
    @IBOutlet weak var googleButton: UIButton!
    @IBOutlet weak var facebookButton: UIButton!
    
    // Go to signup page
    @IBAction func signupBtn(_ sender: Any) {
        print("Create an account as a new user")
    }
    
    // Forgot password flow
    @IBAction func forgotBtn(_ sender: Any) {
        print("Forgot password")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //to dismiss keyboard
        let tapGesture = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissKeyboard)
        )
        view.addGestureRecognizer(tapGesture)
        
        // system notification to adjust keyboard wrt to contents present at bottom
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillShow(_:)),
            name: UIResponder.keyboardWillShowNotification,
            object: nil
        )
        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(keyboardWillHide(_:)),
            name: UIResponder.keyboardWillHideNotification,
            object: nil
        )
        
        emailTextField.delegate = self
        passwordTextField.delegate = self
        
        // Clear validation labels initially
        emailValidationLabel.text = ""
        passwordValidationLabel.text = ""
        
        // Add clear button inside email field
        emailTextField.clearButtonMode = .whileEditing
        
        // Monitor text changes for enabling login button dynamically
//        passwordTextField.addTarget(self, action: #selector(textFieldsChanged), for: .editingChanged)
//        emailTextField.addTarget(self, action: #selector(textFieldsChanged), for: .editingChanged)
        
        // Add password eye toggle icon
        setupPasswordToggle()
        
        // Style login button
        loginButton.backgroundColor = .systemGray
        loginButton.layer.cornerRadius = 10
        
        // Add shadow effect for other login buttons
        setupShadow(for: appleButton)
        setupShadow(for: googleButton)
        setupShadow(for: facebookButton)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @objc func keyboardWillShow(_ notification: Notification) {
        if let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
            let keyboardHeight = keyboardFrame.height
            let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardHeight, right: 0)
            
            scrollView.contentInset = contentInsets
            scrollView.scrollIndicatorInsets = contentInsets
        }
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        scrollView.contentInset = .zero
        scrollView.scrollIndicatorInsets = .zero
    }
    
//    //check fields to enable login button
//    @objc func textFieldsChanged() {
//        let isEmailEmpty = emailTextField.text?.isEmpty ?? true
//        let isPasswordEmpty = passwordTextField.text?.isEmpty ?? true
//
//        // Enable login button only if both fields are non-empty
//        if !isEmailEmpty && !isPasswordEmpty {
//            loginButton.isEnabled = true
//            loginButton.backgroundColor = .systemBlue
//            loginButton.setTitleColor(.white, for: .normal)
//        }
//    }
//
    // email validation fuuction
    func isValidEmail(_ email: String) -> Bool {
        let pattern = "^[^0-9.][A-Za-z0-9._%+-]{0,49}@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        return NSPredicate(format: "SELF MATCHES %@", pattern).evaluate(with: email)
    }
    
    // Add eye icon for toggle password visibility
    func setupPasswordToggle() {
        let toggleButton = UIButton(type: .custom)
        toggleButton.setImage(UIImage(systemName: "eye.slash"), for: .normal)
        toggleButton.tintColor = .gray
        toggleButton.addTarget(self, action: #selector(togglePasswordVisibility(_:)), for: .touchUpInside)
        
        passwordTextField.rightView = toggleButton
        passwordTextField.rightViewMode = .always
        passwordTextField.isSecureTextEntry = true
    }
    
    // Toggle between secure text entry and plain text
    @objc func togglePasswordVisibility(_ sender: UIButton) {
        passwordTextField.isSecureTextEntry.toggle()
        let iconName = passwordTextField.isSecureTextEntry ? "eye.slash" : "eye"
        sender.setImage(UIImage(systemName: iconName), for: .normal)
    }
    
    //add shadows to button
    func setupShadow(for button: UIButton) {
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.2
        button.layer.shadowOffset = CGSize(width: 0, height: 0)
        button.layer.shadowRadius = 5
        button.translatesAutoresizingMaskIntoConstraints = false
    }
    
    //login button logic
    @IBAction func loginBtnPressed(_ sender: UIButton) {
        loginButton.isEnabled = false
        guard let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines),
              let password = passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) else { return }
        
        if !isValidEmail(email) {
            emailValidationLabel.text = "Invalid Email"
            emailValidationLabel.textColor = .systemRed
            return
        }
        //call api for login
        AuthService.shared.login(
            email: email,
            password: password
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let authResponse):
                    
                    // Save email and password in keychain
                    let _ = KeychainManager.shared.save(password, account: AccountName.userPassword.rawValue)
                    let _ = KeychainManager.shared.save(email, account: AccountName.userEmail.rawValue)
                    
                    //save the login state in userdefaults
                    UserDefaults.standard.set(true, forKey: "isLoggedIn")
                    
                    //go to HomeViewController
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let homeVC = storyboard.instantiateViewController(withIdentifier: "homeVC") as! HomeViewController
                    homeVC.userName = authResponse.userName
                    homeVC.thumbNail = authResponse.thumbnail
                    self.navigationController?.setViewControllers([homeVC], animated: true)
                    
                case .failure:
                    self.passwordValidationLabel.text = "Login failed"
                    self.passwordValidationLabel.textColor = .systemRed
                    //self.loginButton.isEnabled = true
                }
            }
        }
    }
    
}

extension ViewController:UITextFieldDelegate{
    //to go to next text field when clicking next button in keyboard
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField {
            passwordTextField.becomeFirstResponder() //shifts focus to the password text field.
        } else {
            textField.resignFirstResponder()//Keyboard is dismissed.
        }
        return true
    }
    
    // to enable and disable the login button
    func textFieldDidChangeSelection(_ textField: UITextField) {
        passwordValidationLabel.text = ""
        let isEmailEmpty = emailTextField.text?.isEmpty ?? true
        let isPasswordEmpty = passwordTextField.text?.isEmpty ?? true
        
        // Enable login button only if both fields are non-empty
        if !isEmailEmpty && !isPasswordEmpty {
            loginButton.isEnabled = true
            loginButton.backgroundColor = .systemBlue
        }
        else{
            loginButton.isEnabled = false
            loginButton.backgroundColor = .systemGray
        }
    }    
}
      
