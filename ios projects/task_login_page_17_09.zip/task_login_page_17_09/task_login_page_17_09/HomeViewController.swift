import UIKit

class HomeViewController: UIViewController {
    // label to display the userName from the server
    @IBOutlet weak var userLabel: UILabel!
    @IBOutlet weak var contentView: UIView!
    
    var userName: String?
    var thumbNail: String?
    
    // imageView for displaying the image from the server
    let imageView: ImageDownloader = {
        let imageView = ImageDownloader()
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .yellow
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userLabel.text = userName
        contentView.addSubview(imageView)
        
        // Auto Layout
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: userLabel.bottomAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
        ])
        
        // Logout button
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            title: "Logout",
            style: .plain,
            target: self,
            action: #selector(logoutTapped)
        )
        
        // Trigger download of the image
        if let thumbNail = thumbNail, let url = URL(string: thumbNail) {
            imageView.startDownload(url: url)
        } else {
            print("thumbNail is nil")
        }
        
        
    }
    
    @objc func logoutTapped() {
        // Clear Keychain
        KeychainManager.shared.delete(account: AccountName.userEmail.rawValue)
        KeychainManager.shared.delete(account: AccountName.userPassword.rawValue)
        
        //clear the image stored in disk.
        ImageDownloader.clearCache()
        
        // Reset login state
        UserDefaults.standard.set(false, forKey: "isLoggedIn")
        
        // Show login screen
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let loginVC = storyboard.instantiateViewController(withIdentifier: "loginVC") as! ViewController
        let nav = UINavigationController(rootViewController: loginVC)
        //Gets the app’s main UIWindowScene
        //Finds the UIWindow associated with that scene.
        //Replaces its root view controller with your new navigation controller containing the login screen.
        //makeKeyAndVisible() tells iOS: this window is active and ready to be shown.
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first {
            window.rootViewController = nav
            window.makeKeyAndVisible()
        }
        
    }
}
