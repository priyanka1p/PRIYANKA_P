import UIKit

class AsyncImageView: UIImageView {
    private static let imageCache = NSCache<NSURL, UIImage>()   // memory cache
    private static var ongoingTasks: [URL: [((UIImage?) -> Void)]] = [:]
    
    private var currentURL: URL?
    
    //    Creates a folder inside Documents/ImageCaches/.
    //    This persists even if the app restarts.
    //    If folder doesn’t exist → it creates it.
    //    It tells iOS/macOS that you want directories inside the user’s home directory
    private static var diskCacheDirectory: URL = {
        let docDir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let cacheDir = docDir.appendingPathComponent("ImageCaches")
        print("ImageCache folder: \(cacheDir.path)")
        
        if !FileManager.default.fileExists(atPath: cacheDir.path) {
            try? FileManager.default.createDirectory(at: cacheDir, withIntermediateDirectories: true)
        }
        return cacheDir
    }()
    //    Builds a file path for storing the image on disk.
    private static func filePath(for url: URL) -> URL {
        return diskCacheDirectory.appendingPathComponent(url.lastPathComponent)
    }
    
    func loadImage(from url: URL, delay: TimeInterval = 0) {
        currentURL = url
        
        //  Check memory cache
        if let cachedImage = AsyncImageView.imageCache.object(forKey: url as NSURL) {
            print(" Loaded from memory cache: \(url.lastPathComponent)")
            self.image = cachedImage
            return
        }
        
        // Check disk cache (Documents/ImageCache)
        let diskPath = AsyncImageView.filePath(for: url)
        if FileManager.default.fileExists(atPath: diskPath.path),
           //diskPath.path converts the URL into a string path
           let img = UIImage(contentsOfFile: diskPath.path) {
            print(" Loaded from disk cache: \(diskPath.lastPathComponent)")
            AsyncImageView.imageCache.setObject(img, forKey: url as NSURL) // also store in memory
            self.image = img
            return
        }
        
        // Placeholder
        self.image = UIImage(systemName: "photo")
        
        // If download already in progress
        if var handlers = AsyncImageView.ongoingTasks[url] {
            handlers.append { [weak self] img in
                guard let self = self, self.currentURL == url else { return }
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                    self.image = img
                }
            }
            AsyncImageView.ongoingTasks[url] = handlers
            return
        } else {
            AsyncImageView.ongoingTasks[url] = []
        }
        
        // Download
        URLSession.shared.dataTask(with: url) { data, _, error in
            print(" Downloaded: \(url.lastPathComponent)")
            var img: UIImage? = nil
            if let data = data, error == nil {
                img = UIImage(data: data)
                if let img = img {
                    // Save to memory cache
                    AsyncImageView.imageCache.setObject(img, forKey: url as NSURL)
                    
                    // Save to disk cache
                    //                    It will attempt to write.
                    //                    If it fails (e.g., permission denied, invalid path, no space left), it will not crash — it just returns nil silently.
                    try? data.write(to: diskPath)
                    print(" Saved to disk: \(diskPath.lastPathComponent)")
                }
            }
            
            DispatchQueue.main.async {
                if self.currentURL == url {
                    self.image = img
                }
                if let handlers = AsyncImageView.ongoingTasks[url] {
                    for h in handlers { h(img) }
                }
                AsyncImageView.ongoingTasks[url] = nil
            }
        }.resume()
    }
    
    func cancelLoad() {
        currentURL = nil
    }
    
}
