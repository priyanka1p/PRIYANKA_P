//
//  CommentFlowLayout.swift
//  collectionview_dynamic_cell_height
//
//  Created by Priyanka on 08/09/25.
//


import UIKit

class CommentFlowLayout: UICollectionViewFlowLayout {
    override init() {
        super.init()
        scrollDirection = .vertical
        estimatedItemSize = UICollectionViewFlowLayout.automaticSize
        minimumLineSpacing = 10
    }
    required init?(coder: NSCoder) { fatalError() }
}
