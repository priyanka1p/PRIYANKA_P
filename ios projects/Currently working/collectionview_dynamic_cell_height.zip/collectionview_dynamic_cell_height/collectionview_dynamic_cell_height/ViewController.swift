import UIKit

class ViewController: UIViewController, UICollectionViewDataSource {

    private var collectionView: UICollectionView!

    private let comments: [(image: String, text: String)] = [
        ("apple_80", "This is a short comment."),
        ("facebook_80", "This comment is a bit longer and should wrap to multiple lines in order to test the dynamic height resizing of our UICollectionViewCell."),
        ("google_80", "Tiny."),
        ("apple_30", "Sometimes we need UICollectionView’s cells to resize based on their content. This example demonstrates dynamic sizing using Auto Layout and preferredLayoutAttributesFitting. Works on iOS 14+ without third-party libraries!")
    ]


    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Dynamic Comments"
        view.backgroundColor = .systemBackground

        let layout = UICollectionViewFlowLayout()
        layout.estimatedItemSize = UICollectionViewFlowLayout.automaticSize
        layout.minimumLineSpacing = 10
        //layout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)

        collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .systemBackground
        collectionView.dataSource = self
        collectionView.delegate = self

        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.register(CommentCell.self, forCellWithReuseIdentifier: CommentCell.identifier)

        view.addSubview(collectionView)

        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    // MARK: UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        comments.count
    }

    func collectionView(
        _ collectionView: UICollectionView,
        cellForItemAt indexPath: IndexPath
    ) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: CommentCell.identifier,
            for: indexPath
        ) as? CommentCell else {
            return UICollectionViewCell()
        }
        let comment = comments[indexPath.item]
        cell.configure(imageName: comment.image, comment: comment.text)

        return cell
    }
}

extension ViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.width // respect section insets
        return CGSize(width: width, height: UICollectionViewFlowLayout.automaticSize.height)
    }
}
