import CryptoKit
import CommonCrypto
import UIKit
// Base64 encode the wrapper JSON if required
//        let encodedData = Data(jsonString.utf8)
//        let encodedRequest = encodedData.base64EncodedString()

/*
let requestWrapper: [String: Any] = ["Request": jsonString]
guard let wrapperData = try? JSONSerialization.data(withJSONObject: requestWrapper, options: [.sortedKeys]) else {
    print("Failed to create JSON data")
    return
}
let encodedRequest = wrapperData.base64EncodedString()
*/

class ViewController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    //outlets of text field
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    // Labels to show email/password validation messages
    @IBOutlet weak var emailValidationLabel: UILabel!
    @IBOutlet weak var passwordValidationLabel: UILabel!
    
    // Login button
    @IBOutlet weak var loginButton: UIButton!
    
    // other sign-in buttons
    
    @IBOutlet weak var appleButton: UIButton!
    @IBOutlet weak var googleButton: UIButton!
    @IBOutlet weak var facebookButton: UIButton!
    
    // Go to signup page
    @IBAction func signupBtn(_ sender: Any) {
        print("Create an account as a new user")
    }
    
    // Forgot password flow
    @IBAction func forgotBtn(_ sender: Any) {
        print("Forgot password")
    }
    
    // database of users login
    let emailDatabase: [String: String] = [
        "john@gmail.com": "John@123",
        "alice@example.com": "Alice@123",
        "priya@gmail.com": "Priya@123",
        "viji@gmail.com": "v@123"
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(keyboardWillShow(_:)),
                                               name: UIResponder.keyboardWillShowNotification,
                                               object: nil)
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(keyboardWillHide(_:)),
                                               name: UIResponder.keyboardWillHideNotification,
                                               object: nil)
        
        emailTextField.delegate = self
        passwordTextField.delegate = self
        
        // Clear validation labels initially
        emailValidationLabel.text = ""
        passwordValidationLabel.text = ""
        
        // Add clear button inside email field
        emailTextField.clearButtonMode = .whileEditing
        
        // Monitor text changes for enabling login button dynamically
        passwordTextField.addTarget(self, action: #selector(textFieldsChanged), for: .editingChanged)
        emailTextField.addTarget(self, action: #selector(textFieldsChanged), for: .editingChanged)
        
        // Add password eye toggle icon
        setupPasswordToggle()
        
        // Style login button
        loginButton.layer.cornerRadius = 10
        
        // Add shadow effect for other login buttons
        setupShadow(for: appleButton)
        setupShadow(for: googleButton)
        setupShadow(for: facebookButton)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    
    @objc func keyboardWillShow(_ notification: Notification) {
        if let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
            let keyboardHeight = keyboardFrame.height
            let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardHeight, right: 0)
            
            scrollView.contentInset = contentInsets
            scrollView.scrollIndicatorInsets = contentInsets
        }
    }
    
    @objc func keyboardWillHide(_ notification: Notification) {
        scrollView.contentInset = .zero
        scrollView.scrollIndicatorInsets = .zero
    }
    
    
    //check fields to enable login button
    @objc func textFieldsChanged() {
        let isEmailEmpty = emailTextField.text?.isEmpty ?? true
        let isPasswordEmpty = passwordTextField.text?.isEmpty ?? true
        
        // Enable login button only if both fields are non-empty
        if !isEmailEmpty && !isPasswordEmpty {
            loginButton.isEnabled = true
            loginButton.backgroundColor = .systemBlue
            loginButton.setTitleColor(.white, for: .normal)
        }
    }
    
    // email validation fuuction
    func isValidEmail(_ email: String) -> Bool {
        let pattern = "^[^0-9.][A-Za-z0-9._%+-]{0,49}@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        return NSPredicate(format: "SELF MATCHES %@", pattern).evaluate(with: email)
    }
    
    // Add eye icon for toggle password visibility
    func setupPasswordToggle() {
        let toggleButton = UIButton(type: .custom)
        toggleButton.setImage(UIImage(systemName: "eye.slash"), for: .normal)
        toggleButton.tintColor = .gray
        toggleButton.addTarget(self, action: #selector(togglePasswordVisibility(_:)), for: .touchUpInside)
        
        passwordTextField.rightView = toggleButton
        passwordTextField.rightViewMode = .always
        passwordTextField.isSecureTextEntry = true
    }
    
    // Toggle between secure text entry and plain text
    @objc func togglePasswordVisibility(_ sender: UIButton) {
        passwordTextField.isSecureTextEntry.toggle()
        let iconName = passwordTextField.isSecureTextEntry ? "eye.slash" : "eye"
        sender.setImage(UIImage(systemName: iconName), for: .normal)
    }
    
    //add shadows to button
    func setupShadow(for button: UIButton) {
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.2
        button.layer.shadowOffset = CGSize(width: 0, height: 0)
        button.layer.shadowRadius = 5
        button.translatesAutoresizingMaskIntoConstraints = false
    }

    func md5Hash(_ input: String) -> String {
        let inputData = Data(input.utf8)
        let hashed = Insecure.MD5.hash(data: inputData)
        return hashed.map { String(format: "%02x", $0) }.joined()
    }


    //login button logic
    @IBAction func loginBtnPressed(_ sender: UIButton) {
        guard let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines),
              let password = passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) else { return }
        
        if !isValidEmail(email) {
            emailValidationLabel.text = "Invalid Email"
            emailValidationLabel.textColor = .systemRed
            return
        }
//        Token:  NO-TOKEN
//        CLIENT KEY: "eQmqIhqfIeNs0OX6avY5YpauB"
//        CLIENT ID: "21V21B337GMX2"
//        CLIENT VERSION: 2.2
//        API VERSION: 2.3
//        let sessionHashUUID = UUID().uuidString.lowercased().replacingOccurrences(of: "-", with: "")
//        print(sessionHashUUID)
        
        let md5 = md5Hash(password)
        print("MD5 Hash: \(md5)")
        let requestBody: [String: Any] = [
            "User":[
                "email": email,
                "password": md5,
                "timezone": TimeZone.current.identifier
            ],
            "Client": [
                "identity": "21V21B337GMX2",
                "version": "2.2",
                "session_hash": "5ace3dce4ade4cc290889cb01d856b23",

            ],
            "api": [
                "app_version": "7.7.6",
                "version": "2.3"
            ],
            "Session" : [
                 "token" : "NO-TOKEN"
            ]
        ]
        
        let requestWrapper: [String: Any] = ["Request": requestBody]
        
        // Convert the wrapper to JSON string
        guard let jsonData = try? JSONSerialization.data(withJSONObject: requestWrapper, options: [.sortedKeys]),
              let jsonString = String(data: jsonData, encoding: .utf8) else {
            print("Failed to create JSON string for checksum")
            return
        }
       
        
//        let encodedData = Data(jsonString.utf8)
//        let encodedRequest = encodedData.base64EncodedString()
        
        // Compute checksum: token + request + clientKey
        let requestToken = "NO-TOKEN"
        let clientKey = "eQmqIhqfIeNs0OX6avY5YpauB"
        let rawString =   requestToken + jsonString + clientKey
//        print(rawString)
        let checksum = hmacSHA256(msg: rawString, key: requestToken)
        //intern+ios@mobicip.com
        
        print("****************")
        print(checksum)
        print("****************")

        //final request
        let finalBody: [String: Any] = [
            "mwsRequest": [
                "String": requestWrapper,
                "Checksum": checksum
            ]
        ]
        guard let finalJsonData = try? JSONSerialization.data(withJSONObject: finalBody, options: [.sortedKeys]) else { return }
        print(finalBody)
        // creating the HTTP POST request
        let baseURL = "https://webd.prgr.in/api/v2"
        var request = URLRequest(url: URL(string: baseURL + "/login")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = finalJsonData

        
        // Call API
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error:", error)
                return
            }
            guard let data = data,//converts the raw bytes into a Swift dictionary
                  let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
                print("Invalid response")
                return
            }
            
            print("Response JSON:", json)
            
            // Parse status
            if let status = json["status"] as? [String: Any],
               let code = status["code"] as? String,
               code == "000" {
                
                // Success → extract user name & image
                var userName = ""
                var thumbnailURL = ""
                
                if let managedUsers = json["managedUsers"] as? [[String: Any]],
                   let firstUser = managedUsers.first {
                    userName = firstUser["name"] as? String ?? ""
                    thumbnailURL = firstUser["thumbnail"] as? String ?? ""
                }
                
                // Save credentials securely
                KeychainManager.shared.saveEmail(email)
                KeychainManager.shared.savePassword(password)
                UserDefaults.standard.set(true, forKey: "isLoggedIn")
                
                DispatchQueue.main.async {
                    // Navigate to HomeVC
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let homeVC = storyboard.instantiateViewController(withIdentifier: "homeVC") as! HomeViewController
                    homeVC.email = userName
                    self.navigationController?.setViewControllers([homeVC], animated: true)
                }
            } else {
                DispatchQueue.main.async {
                    self.passwordValidationLabel.text = "Login failed"
                    self.passwordValidationLabel.textColor = .systemRed
                }
            }
        }.resume()
    }
    //HMAC combines a hash function (like SHA-256) with a secret key to produce a signature that ensures:
    //produces a fixed-length 256-bit hash (32 bytes)
    func hmacSHA256(msg:String,key: String) -> String {
        //HMAC calculation works on raw bytes (
        let keyData = Data(key.utf8)
        let messageData = Data(msg.utf8)
        //This represents your secret key for HMAC.
        let keySym = SymmetricKey(data: keyData)
        //signature is a Data buffer containing raw bytes.
        let signature = HMAC<SHA256>.authenticationCode(for: messageData, using: keySym)
        //let base64HMAC = Data(signature).base64EncodedString()

        return Data(signature).map { String(format: "%02hhx", $0) }.joined()
    }
//    func hmacSHA256(msg: String, key: String) -> String {
//        let keyData = key.data(using: .utf8)!
//        let dataData = msg.data(using: .utf8)!
//        
//        var hmac = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
//        
//        keyData.withUnsafeBytes { keyBytes in
//            dataData.withUnsafeBytes { dataBytes in
//                CCHmac(CCHmacAlgorithm(kCCHmacAlgSHA256), keyBytes.baseAddress, keyData.count, dataBytes.baseAddress, dataData.count, &hmac)
//            }
//        }
//        
//        return Data(hmac).map { String(format: "%02hhx", $0) }.joined()
//    }
}

extension ViewController:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == emailTextField {
            passwordTextField.becomeFirstResponder() //shifts focus to the password text field.
        } else {
            textField.resignFirstResponder()//Keyboard is dismissed.
        }
        return true
    }
}
      
