//
//  HomeViewController.swift
//  task_login_10_9_6_30
//
//  Created by Priyanka on 10/09/25.
//


import UIKit

class HomeViewController: UIViewController, URLSessionDataDelegate {
    
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var contentView: UIView!        // connect in storyboard
    
    var email: String?
    let imageView = UIImageView()
    var aspectRatioConstraint: NSLayoutConstraint?
    
    // This will store the downloaded data
    var receivedData = Data()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        emailLabel.text = email
        
        // Setup UIImageView
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .yellow
        imageView.translatesAutoresizingMaskIntoConstraints = false
        
        // Add imageView inside the scroll view’s contentView
        contentView.addSubview(imageView)
        
        // Auto Layout constraints
        NSLayoutConstraint.activate([
            imageView.topAnchor.constraint(equalTo: emailLabel.bottomAnchor, constant: 20),
            imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
            imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
            //imageView.heightAnchor.constraint(equalToConstant: 200)
        ])
        navigationItem.hidesBackButton = true

            // Add Logout button on right
            navigationItem.rightBarButtonItem = UIBarButtonItem(
                title: "Logout",
                style: .plain,
                target: self,
                action: #selector(logoutTapped)
            )
        fetchImage()
    }
    
    @objc func logoutTapped() {
            // Clear login state
            UserDefaults.standard.set(false, forKey: "isLoggedIn")
            UserDefaults.standard.removeObject(forKey: "loggedInEmail")

            // Navigate back to LoginVC
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let loginVC = storyboard.instantiateViewController(withIdentifier: "loginVC") as! ViewController
            navigationController?.setViewControllers([loginVC], animated: true)
        }
    
    func fetchImage() {
        let url = URL(string: "https://i.pinimg.com/originals/42/90/74/42907405f16ba768786a616095a8cfb2.jpg")!
        
        // Create a URLSession with self as delegate
        let sessionConfig = URLSessionConfiguration.default
        let session = URLSession(configuration: sessionConfig, delegate: self, delegateQueue: nil)
        
        // Create a data task
        let task = session.dataTask(with: url)
        task.resume()
    }
    
    
    // Called when server responds
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        print("Server responding")
        receivedData = Data() // reset for new response
        completionHandler(.allow) // proceed with receiving data
    }
    
    // Called each time new chunk of data arrives
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        print("*******************************")
        print("data:\(data)")
        print("*******************************")
        print("device recieve data")
        receivedData.append(data)
    }
    
    // Called when the task finishes
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error = error {
            print("Error:", error)
            return
        }
        
        // Convert received data to UIImage
        if let image = UIImage(data: receivedData) {
            print("all data received successfully")
            DispatchQueue.main.async {
                self.setImage(image)
            }
        }
    }
    
    func setImage(_ image: UIImage) {
        imageView.image = image
        
        //Remove old aspect ratio constraint if any
        if let oldConstraint = aspectRatioConstraint {
        imageView.removeConstraint(oldConstraint)
        }
        
        let aspectRatio = image.size.height / image.size.width
        aspectRatioConstraint = imageView.heightAnchor.constraint(equalTo: imageView.widthAnchor, multiplier: aspectRatio)
        //aspectRatioConstraint?.priority = .defaultHigh
        aspectRatioConstraint?.isActive = true
    }
    /*import UIKit
     
     class HomeViewController: UIViewController {
     
     @IBOutlet weak var emailLabel: UILabel!
     @IBOutlet weak var scrollView: UIScrollView!   // connect in storyboard
     @IBOutlet weak var contentView: UIView!        // connect in storyboard
     
     var email: String?
     let imageView = UIImageView()
     var aspectRatioConstraint: NSLayoutConstraint?
     
     override func viewDidLoad() {
     super.viewDidLoad()
     
     emailLabel.text = email
     
     // Setup UIImageView
     
     imageView.contentMode = .scaleAspectFit
     imageView.backgroundColor = .yellow
     imageView.translatesAutoresizingMaskIntoConstraints = false
     
     // Add imageView inside the scroll view’s contentView
     contentView.addSubview(imageView)
     
     // Auto Layout constraints
     NSLayoutConstraint.activate([
     imageView.topAnchor.constraint(equalTo: emailLabel.bottomAnchor, constant: 20),
     imageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 10),
     imageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -10),
     // with this alone u will get growing effect
     //imageView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 20)
     // height will be dynamic
     ])
     
     fetchImage()
     }
     //https://miro.medium.com/1*MIrLuyiCDpdNbnFYxYlKtA.png
     //https://i.pinimg.com/originals/42/90/74/42907405f16ba768786a616095a8cfb2.jpg
     func fetchImage() {
     //closure baseed approach
     let url = URL(string: "https://miro.medium.com/1*MIrLuyiCDpdNbnFYxYlKtA.png")!
     URLSession.shared.dataTask(with: url) { data, _, error in
     if let error = error {
     print("Error:", error)
     return
     }
     if let data = data, let image = UIImage(data: data) {
     DispatchQueue.main.async {
     self.setImage(image)
     }
     }
     }.resume()
     }
     
     func setImage(_ image: UIImage) {
     imageView.image = image
     if let oldConstraint = aspectRatioConstraint {
     imageView.removeConstraint(oldConstraint)
     }
     
     let aspectRatio = image.size.height / image.size.width
     aspectRatioConstraint = imageView.heightAnchor.constraint(equalTo: imageView.widthAnchor, multiplier: aspectRatio)
     aspectRatioConstraint?.isActive = true
     
     
     }
     }
     */
}
