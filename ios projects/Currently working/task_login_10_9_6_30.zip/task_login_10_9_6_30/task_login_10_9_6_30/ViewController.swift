import UIKit

class ViewController: UIViewController {
    
    //outlets of text field
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    // Labels to show email/password validation messages
    @IBOutlet weak var emailValidationLabel: UILabel!
    @IBOutlet weak var passwordValidationLabel: UILabel!
    
    // Login button
    @IBOutlet weak var loginButton: UIButton!
    
    // other sign-in buttons
    
    @IBOutlet weak var appleButton: UIButton!
    @IBOutlet weak var googleButton: UIButton!
    @IBOutlet weak var facebookButton: UIButton!
    
    // Go to signup page
    @IBAction func signupBtn(_ sender: Any) {
        print("Create an account as a new user")
    }
    
    // Forgot password flow
    @IBAction func forgotBtn(_ sender: Any) {
        print("Forgot password")
    }
    
    // database of users login
    let emailDatabase: [String: String] = [
        "john.doe@gmail.com": "John@123",
        "alice@example.com": "Alice@123",
        "priya@gmail.com": "Priya@123"
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Clear validation labels initially
        emailValidationLabel.text = ""
        passwordValidationLabel.text = ""
        
        // Add clear button inside email field
        emailTextField.clearButtonMode = .whileEditing
        
        // Monitor text changes for enabling login button dynamically
        passwordTextField.addTarget(self, action: #selector(textFieldsChanged), for: .editingChanged)
        emailTextField.addTarget(self, action: #selector(textFieldsChanged), for: .editingChanged)
        
        // Add password eye toggle icon
        setupPasswordToggle()
        
        // Style login button
        loginButton.layer.cornerRadius = 10
        
        // Add shadow effect for other login buttons
        setupShadow(for: appleButton)
        setupShadow(for: googleButton)
        setupShadow(for: facebookButton)
    }
    
    //check fields to enable login button
    @objc func textFieldsChanged() {
        let isEmailEmpty = emailTextField.text?.isEmpty ?? true
        let isPasswordEmpty = passwordTextField.text?.isEmpty ?? true
        
        // Enable login button only if both fields are non-empty
        if !isEmailEmpty && !isPasswordEmpty {
            loginButton.isEnabled = true
            loginButton.backgroundColor = .systemBlue
            loginButton.setTitleColor(.white, for: .normal)
        }
    }
    
    // email validation fuuction
    func isValidEmail(_ email: String) -> Bool {
        let pattern = "^[^0-9.][A-Za-z0-9._%+-]{0,49}@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        return NSPredicate(format: "SELF MATCHES %@", pattern).evaluate(with: email)
    }
    
    // Add eye icon for toggle password visibility
    func setupPasswordToggle() {
        let toggleButton = UIButton(type: .custom)
        toggleButton.setImage(UIImage(systemName: "eye.slash"), for: .normal)
        toggleButton.tintColor = .gray
        toggleButton.addTarget(self, action: #selector(togglePasswordVisibility(_:)), for: .touchUpInside)
        
        passwordTextField.rightView = toggleButton
        passwordTextField.rightViewMode = .always
        passwordTextField.isSecureTextEntry = true
    }
    
    // Toggle between secure text entry and plain text
    @objc func togglePasswordVisibility(_ sender: UIButton) {
        passwordTextField.isSecureTextEntry.toggle()
        let iconName = passwordTextField.isSecureTextEntry ? "eye.slash" : "eye"
        sender.setImage(UIImage(systemName: iconName), for: .normal)
    }
    
    //add shadows to button
    func setupShadow(for button: UIButton) {
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOpacity = 0.2
        button.layer.shadowOffset = CGSize(width: 0, height: 0)
        button.layer.shadowRadius = 5
        button.translatesAutoresizingMaskIntoConstraints = false
    }
    
    //login button logic
    @IBAction func loginBtnPressed(_ sender: UIButton) {
        
        // Trim leadiing spaces and trailing spaces from password
        guard let email = emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines),
              let password = passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) else { return }
        
        // Check email format
        if !isValidEmail(email) {
            emailValidationLabel.text = "Invalid Email"
            emailValidationLabel.textColor = .systemRed
            return
        }
        
        // Check if email exists in database
        if let savedPassword = emailDatabase[email] {
            if savedPassword == password {
                
                UserDefaults.standard.set(true, forKey: "isLoggedIn")
                    UserDefaults.standard.set(email, forKey: "loggedInEmail")

                    // Navigate to HomeVC
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let homeVC = storyboard.instantiateViewController(withIdentifier: "homeVC") as! HomeViewController
                    homeVC.email = email
                    navigationController?.setViewControllers([homeVC], animated: true)
//                emailValidationLabel.text = "login successful"
//                //trigger the segue in the storyboard, also passes info(email)
//                performSegue(withIdentifier: "goToHome", sender: email)
//
                 //using navigation method
                  // pass email here
                 
                 
                /* //to present it modally - without pushing to stack
                 let storyboard = UIStoryboard(name: "Main", bundle: nil)
                 let homeVC = storyboard.instantiateViewController(withIdentifier: "homeVC") as! HomeViewController
                 homeVC.email = email
                 homeVC.modalPresentationStyle = .fullScreen
                 present(homeVC, animated: true)
                 
                 */
            } else {
                print("Incorrect password")
                passwordValidationLabel.text = "Incorrect password"
                passwordValidationLabel.textColor = .systemRed
            }
        } else {
            print("Email not registered")
            passwordValidationLabel.text = "Email not found"
            passwordValidationLabel.textColor = .systemRed
        }
        
    }
    // This method is automatically called by UIKit
    // right before a segue transition happens.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToHome" {
            //typecast UIviewController to HomeViewzController
            if let destinationVC = segue.destination as? HomeViewController {
                //Pass the email text from the current screen’s text field into the email property of
                //HomeViewController,so it can be displayed there.
                destinationVC.email = sender as? String
            }
        }
    }
}
