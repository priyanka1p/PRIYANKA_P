//
//  UserKeys.swift
//  demo_userdafaults
//
//  Created by Priyanka on 10/09/25.
//


import UIKit

struct UserKeys {
    static let name = "name"
    static let age = "age"
    static let gender = "gender"
}

