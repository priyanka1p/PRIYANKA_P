//
//  ViewController.swift
//  demo_userdafaults
//
//  Created by Priyanka on 10/09/25.
//
//integer(forKey:) returns an integer if the key existed, or 0 if not.
//bool(forKey:) returns a boolean if the key existed, or false if not.
//float(forKey:) returns a float if the key existed, or 0.0 if not.
//double(forKey:) returns a double if the key existed, or 0.0 if not.
//object(forKey:) returns Any? so you need to conditionally typecast it to your data type.

//how data gets stored in userdefaults?
//saving
// the valules are saved in memory cache and then to .plist
//if app closes, the data is still saved in .plist
// retrieving
// when again app launches, the values are loaded from .plist to memory chache for read/write.
//.plist can only store int, string, bool, float, double, dict
// if we want to store struct or complex data types, then it is encoded to json format and decode to normal struct while retriving and stored in plist as
//<key>myProfile</key>
//<data>
//eyJ1c2VybmFtZSI6ICJQcml5YSIsICJhZ2UiOiAyNSwgImdlbmRlciI6ICJGZW1hbGUiLCAiYWN0aXZlIjogdHJ1ZSwgImxhc3RTZWVuIjogIjIwMjUtMDktMTBUMTI6MDA6MDBaIn0=
//</data>

//path - explanation
//This is the shared instance of UserDefaults for your app.
//Every app has its own sandboxed preferences file (the .plist we talked about).
//Every app has a unique bundle identifier (like com.priya.demo_userdefaults).
//This string is used as the filename for your app’s UserDefaults .plist.
//A persistent domain is the dictionary of all key–value pairs stored for a given domain name (usually) your app’s bundle identifier).
                                                    
                                                    
                        
                                                    
import UIKit

class ViewController: UIViewController {
    
    // MARK: - UI Elements
    private let nameTextField: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Enter Name"
        tf.borderStyle = .roundedRect
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()
    
    private let ageTextField: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Enter Age"
        tf.keyboardType = .numberPad
        tf.borderStyle = .roundedRect
        tf.translatesAutoresizingMaskIntoConstraints = false
        return tf
    }()
    
    private let genderSegment: UISegmentedControl = {
        let sc = UISegmentedControl(items: ["Male", "Female"])
        sc.selectedSegmentIndex = 0
        sc.translatesAutoresizingMaskIntoConstraints = false
        return sc
    }()
    
    private let saveButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Save", for: .normal)
        btn.backgroundColor = .systemBlue
        btn.tintColor = .white
        btn.layer.cornerRadius = 8
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()
    
    private let loadButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Load", for: .normal)
        btn.backgroundColor = .systemGreen
        btn.tintColor = .white
        btn.layer.cornerRadius = 8
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()
    
    private let clearButton: UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("Clear", for: .normal)
        btn.backgroundColor = .systemRed
        btn.tintColor = .white
        btn.layer.cornerRadius = 8
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()
    let lastSeen = [
        "Priya": Date(),
        "Praba": Date(),
        "Viji": Date()
    ]
  
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        let defaults = UserDefaults.standard

        if let path = UserDefaults.standard
            .persistentDomain(forName: Bundle.main.bundleIdentifier!) {
            print(path)
        }
        defaults.set(lastSeen, forKey: "lastSeenDict")

        if let saved = defaults.dictionary(forKey: "lastSeenDict") as? [String: Date] {
            print(saved["Priya"] ?? "")
        }
        if let saved = defaults.dictionary(forKey: "lastSeenDict") as? [String: Date] {
            print(saved["Praba"] ?? "")
        }
        if let saved = defaults.dictionary(forKey: "lastSeenDict") as? [String: Date] {
            print(saved["Viji"] ?? "")
        }
        
        
       
        setupLayout()
        setupActions()
    }
    
    private func setupLayout() {
        let stack = UIStackView(arrangedSubviews: [
            nameTextField,
            ageTextField,
            genderSegment,
            saveButton,
            loadButton,
            clearButton
        ])
        stack.axis = .vertical
        stack.spacing = 15
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(stack)
        
        NSLayoutConstraint.activate([
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30)
        ])
    }
    
    private func setupActions() {
        saveButton.addTarget(self, action: #selector(saveData), for: .touchUpInside)
        loadButton.addTarget(self, action: #selector(loadData), for: .touchUpInside)
        clearButton.addTarget(self, action: #selector(clearData), for: .touchUpInside)
    }
    
    @objc private func saveData() {
        let defaults = UserDefaults.standard
        defaults.set(nameTextField.text, forKey: UserKeys.name)
        defaults.set(Int(ageTextField.text ?? "0"), forKey: UserKeys.age)
        defaults.set(genderSegment.selectedSegmentIndex == 0 ? "Male" : "Female", forKey: UserKeys.gender)
        
        showAlert(title: "Saved", message: "User data has been saved.")
    }
    
    @objc private func loadData() {
        let defaults = UserDefaults.standard
        let name = defaults.string(forKey: UserKeys.name) ?? ""
        let age = defaults.integer(forKey: UserKeys.age)
        let gender = defaults.string(forKey: UserKeys.gender) ?? "Male"
        
        nameTextField.text = name
        ageTextField.text = age == 0 ? "" : "\(age)"
        genderSegment.selectedSegmentIndex = (gender == "Male") ? 0 : 1
        print("Loaded: \(name), \(age), \(gender)")
        showAlert(title: "Loaded", message: "User data has been loaded.")
    }
    
    @objc private func clearData() {
        let defaults = UserDefaults.standard
        defaults.removeObject(forKey: UserKeys.name)
        defaults.removeObject(forKey: UserKeys.age)
        defaults.removeObject(forKey: UserKeys.gender)
        
        nameTextField.text = ""
        ageTextField.text = ""
        genderSegment.selectedSegmentIndex = 0
        
        showAlert(title: "Cleared", message: "User data has been cleared.")
    }
    
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

