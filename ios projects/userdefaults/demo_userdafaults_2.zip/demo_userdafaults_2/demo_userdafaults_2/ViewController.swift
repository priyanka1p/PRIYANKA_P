import UIKit

struct Profile: Codable {
    let username: String
    let age: Int
    let gender: String
    let active: Bool
    let lastSeen: Date
}

class ViewController: UIViewController {

    let defaults = UserDefaults.standard

    override func viewDidLoad() {
        super.viewDidLoad()

        // Create a profile
        let myProfile = Profile(username: "saygilitalha",
                                age: 26,
                                gender: "Male",
                                active: true,
                                lastSeen: Date())

        // Save profile
        saveProfile(profile: myProfile)

        if let path = UserDefaults.standard
            .persistentDomain(forName: Bundle.main.bundleIdentifier!) {
            print(path)
        }

        // Retrieve profile
        if let loadedProfile = loadProfile() {
            print("Saved User: \(loadedProfile)")
        }

        // Remove profile
        deleteProfile()
    }

    // Save Profile
    func saveProfile(profile: Profile) {
        let encoder = JSONEncoder()
        //defaults.set(profile, forKey: "myProfile")//Attempt to insert non-property list object demo_userdafaults_2

        if let encoded = try? encoder.encode(profile) {
            defaults.set(encoded, forKey: "myProfile")
            print("Profile saved ")
        }
    }

    // Load Profile
    func loadProfile() -> Profile? {
        if let savedData = defaults.object(forKey: "myProfile") as? Data {
            let decoder = JSONDecoder()
            if let loadedProfile = try? decoder.decode(Profile.self, from: savedData) {
                return loadedProfile
            }
        }
        return nil
    }

    func deleteProfile() {
        defaults.removeObject(forKey: "myProfile")
        print("Profile deleted ")
        if let load = loadProfile(){
            print(load )
        }
        else{
            print("nil")
        }
        
    }
}

