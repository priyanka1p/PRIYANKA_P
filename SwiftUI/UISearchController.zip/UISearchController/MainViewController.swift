
import UIKit

class MainViewController: UIViewController {

    let tableView = UITableView()
    var items = ["Apple", "Banana", "Cherry", "Date", "Grape", "Mango", "Orange", "Papaya", "Pineapple", "Strawberry"]
    var searchController: UISearchController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        title = "Fruits"
        
        setupTableView()
        setupSearchController()
        
    }

    func setupTableView() {
        tableView.frame = view.bounds
        tableView.dataSource = self
        view.addSubview(tableView)
    }

    func setupSearchController() {
        //  Create results view controller
        let resultsVC = ResultsViewController()
        
        // Create search controller
        searchController = UISearchController(searchResultsController: resultsVC)
        
        //  Assign searchResultsUpdater
        searchController.searchResultsUpdater = self
        
        //  Delegate to observe events
        searchController.delegate = self
        
        //  Customize behavior
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.hidesNavigationBarDuringPresentation = true
        searchController.automaticallyShowsCancelButton = true
        searchController.automaticallyShowsScopeBar = true
        searchController.automaticallyShowsSearchResultsController = true

//        let suggestions: [UISearchSuggestionItem] = [
//                    UISearchSuggestionItem(localizedSuggestion: "Tropical Fruits"),
//                    UISearchSuggestionItem(localizedSuggestion: "Citrus"),
//                    UISearchSuggestionItem(localizedSuggestion: "Berries")
//                ]
//        
//        searchController.searchSuggestions = suggestions

        //  Add search bar to navigation
        navigationItem.hidesSearchBarWhenScrolling = false
        navigationItem.searchController = searchController
        definesPresentationContext = true // when entering text result occupies entire screen including the search bar
        
        
        print("Search Controller setup complete.")
    }
}

extension MainViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = items[indexPath.row]
        return cell
    }
}



extension MainViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        guard let query = searchController.searchBar.text, !query.isEmpty else {
            print(" Search text cleared.")
            if let resultsVC = searchController.searchResultsController as? ResultsViewController {
                resultsVC.updateResults(with: [])
                

            }
            return
        }
        
        print("Searching for: \(query)")
        
        let filtered = items.filter { $0.lowercased().contains(query.lowercased()) }
        if let resultsVC = searchController.searchResultsController as? ResultsViewController {
            resultsVC.updateResults(with: filtered)
        }

    }
}

extension MainViewController: UISearchControllerDelegate {
    func willPresentSearchController(_ searchController: UISearchController) {
        print(" willPresentSearchController")
    }
    
    func didPresentSearchController(_ searchController: UISearchController) {
        print("didPresentSearchController")
    }
    
    func willDismissSearchController(_ searchController: UISearchController) {
        print("willDismissSearchController")
    }
    
    func didDismissSearchController(_ searchController: UISearchController) {
        print("didDismissSearchController")
    }
    
   
}
