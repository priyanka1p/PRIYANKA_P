//
//  ResultsViewController.swift
//  UISearchController
//
//  Created by Priyanka on 14/10/25.
//


import UIKit

class ResultsViewController: UIViewController {
    let tableView = UITableView()
    var filteredItems: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGroupedBackground
        tableView.frame = view.bounds
        tableView.dataSource = self
        view.addSubview(tableView)
    }

    func updateResults(with items: [String]) {
        filteredItems = items
        tableView.reloadData()
        print("RESULT TABLE -  Updated Results: \(items)")
    }
}

extension ResultsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "resultCell")
        cell.textLabel?.text = filteredItems[indexPath.row]
        return cell
    }
}
