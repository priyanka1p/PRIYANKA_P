import SwiftUI

struct Item: Identifiable {
    let id = UUID()
    let name: String
}
struct color:Identifiable{
    let id = UUID()
    let name: String
}

class ItemStore: ObservableObject {
    @Published var items: [Item] = [
        Item(name: "Apple"),
        Item(name: "Banana"),
        Item(name: "Cherry")
    ]
    
    @Published var colors:[color] = [
        color(name: "blue"),
        color(name: "red"),
        color(name: "green")
    ]
    
    func addItem(name: String,name2:String) {
        items.append(Item(name: name))
        colors.append(color(name: name2))
    }
}

struct ContentView: View {
    @StateObject private var store = ItemStore()
    
    var body: some View {
        NavigationStack {
            List {
                Section("FRUITS") {
                    ForEach(store.items) { item in
                        NavigationLink(item.name) {
                            DetailView(name: item.name)
                        }
                    }
                }
                Section("COLORS") {
                    ForEach(store.colors) { color in
                        NavigationLink(color.name) {
                            DetailView(name: color.name)
                        }
                    }
                }
            }
            .navigationTitle("Fruits & Colors")
            .toolbar {
                Button("Add") {
                    store.addItem(name: "Mango",name2:"gray")
                    
                }
            }
        }
    }
}

struct DetailView: View {
    let name: String
    
    var body: some View {
        VStack {
            Text(name)
                .font(.largeTitle)
                .padding()
        }
        .navigationTitle(name)
    }
}




#Preview {
    ContentView()
}
