//
//  navigationStack_arrayApp.swift
//  navigationStack_array
//
//  Created by Priyanka on 29/09/25.
//

import SwiftUI

@main
struct navigationStack_arrayApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
