
import SwiftUI

@main
struct stateobjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
