import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDataSource {
    @IBOutlet weak var tableView: UITableView!

    var authors: [Author] = []
    // Use viewContext (Main queue context)
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        fetchAuthors()
    }

    func fetchAuthors() {
        let request: NSFetchRequest<Author> = Author.fetchRequest()
        do {
            authors = try context.fetch(request)
        } catch {
            print("Fetch Authors error: \(error)")
        }
        tableView.reloadData()
    }

    @IBAction func addAuthor(_ sender: UIBarButtonItem) {
        // Create new Author
        let author = Author(context: context)
        author.name = "Author \(authors.count + 1)"

        // Create Book related to Author
        let book1 = Book(context: context)
        book1.title = "Book 1"
        book1.year = 2025
        book1.author = author // Set inverse

        author.addToBooks(book1) // Update 'books' Set on Author side

        // You can add another book as well
        let book2 = Book(context: context)
        book2.title = "Book 2"
        book2.year = 2024
        book2.author = author
        author.addToBooks(book2)

        // Save context
        do {
            try context.save()
            fetchAuthors() // Refresh UI
        } catch {
            print("Save error: \(error)")
        }
    }


    func numberOfSections(in tableView: UITableView) -> Int {
        return authors.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let author = authors[section]
        let count = author.books?.count ?? 0
        return count
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return authors[section].name ?? "Unknown Author"
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") ??
            UITableViewCell(style: .subtitle, reuseIdentifier: "Cell")

        let author = authors[indexPath.section]
        if let books = author.books?.allObjects as? [Book] {
            let book = books[indexPath.row]
            cell.textLabel?.text = book.title ?? "No Title"
            cell.detailTextLabel?.text = "Year: \(book.year)"
        }

        return cell
    }
}
