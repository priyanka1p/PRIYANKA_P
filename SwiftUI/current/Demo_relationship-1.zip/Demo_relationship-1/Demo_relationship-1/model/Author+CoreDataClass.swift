//
//  Author+CoreDataClass.swift
//  Demo_relationship-1
//
//  Created by Priyanka on 14/10/25.
//
//

import Foundation
import CoreData

@objc(Author)
public class Author: NSManagedObject {

}
