import UIKit
import CoreData

class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    var originalRightBarButtonItems: [UIBarButtonItem]?
    var people: [Person] = []
    let container = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    var searchController: UISearchController!

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")

        originalRightBarButtonItems = navigationItem.rightBarButtonItems

        // Setup UISearchController
        searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search by name"
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false

        fetchPeople()
    }

    func fetchPeople() {
        guard let context = context else { return }
        let req = Person.fetchRequest() as NSFetchRequest<Person>
        do {
            self.people = try context.fetch(req)
        } catch {
            print("error")
        }
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
    }

    @IBAction func editbutton(_ sender: Any) {
        guard let barButton = sender as? UIBarButtonItem else { return }
        tableView.setEditing(!tableView.isEditing, animated: true)
        barButton.title = tableView.isEditing ? "Done" : "Edit"
    }

    @IBAction func addName(_ sender: UIBarButtonItem) {
        let addButton = sender
        let alert = UIAlertController(title: "New Name",
                                      message: "Add a new name",
                                      preferredStyle: .alert)

        let saveAction = UIAlertAction(title: "Save", style: .default)
        { [weak self] action in
            addButton.isEnabled = false
            guard let textField = alert.textFields?.first,
                  let nameToSave = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines),
                  !nameToSave.isEmpty else { return }
            guard let textField2 = alert.textFields?[1].text, let age = Int64(textField2) else { return }
            DispatchQueue.global().async {
                self?.save(name: nameToSave, age: age) {
                    addButton.isEnabled = true
                }
            }
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        alert.addTextField(){ t in t.placeholder = "enter name" }
        alert.addTextField(){ t in t.placeholder = "enter age" }
        alert.addAction(cancelAction)
        alert.addAction(saveAction)
        present(alert, animated: true)
    }

    func save(name: String, age: Int64, completion: @escaping () -> Void) {
        let backgroundContext = self.container?.newBackgroundContext()
        backgroundContext?.performAndWait {
            guard let bg = backgroundContext else { return }
            let entity = Person(context: bg)
            entity.name = name
            entity.age = age
            do {
                try bg.save()
            } catch {
                print("BG save error: \(error)")
            }
            self.context?.performAndWait {
                self.fetchPeople()
            }
            self.context?.perform {
                completion()
            }
        }
    }

    func filterContent(for searchText: String) {
        guard let context = context else { return }
        let request: NSFetchRequest<Person> = Person.fetchRequest()
        if !searchText.isEmpty {
            request.predicate = NSPredicate(format: "name BEGINSWITH[c] %@",searchText)
            request.sortDescriptors = [NSSortDescriptor(key: "age", ascending: false),NSSortDescriptor(key: "name", ascending: false)]
        }
        do {
            people = try context.fetch(request)
            tableView.reloadData()
        } catch {
            print("Error fetching data: \(error)")
        }
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = people[indexPath.row].name
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView,
                   commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            guard let context = context else { return }
            let personToDelete = people[indexPath.row]
            context.delete(personToDelete)
            do {
                try context.save()
            } catch {
                print("Failed to delete person: \(error)")
                return
            }
            people.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alert = UIAlertController(title: "add", message: "edit name", preferredStyle: .alert)
        alert.addTextField()
        alert.textFields?.first?.text = self.people[indexPath.row].name
        let submit = UIAlertAction(title: "submit", style: .default) { (_) in
            let person = self.people[indexPath.row]
            person.name = alert.textFields?.first?.text
            do {
                try self.context?.save()
            } catch {
                print("error iin save")
            }
            self.fetchPeople()
        }
        alert.addAction(submit)
        present(alert, animated: true)
    }
}

extension ViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        guard let searchText = searchController.searchBar.text else {
            fetchPeople()
            return
        }
        filterContent(for: searchText)
    }
}
