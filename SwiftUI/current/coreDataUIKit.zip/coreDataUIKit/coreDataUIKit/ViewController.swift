import UIKit
import CoreData

class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    var originalRightBarButtonItems: [UIBarButtonItem]?
    var people: [Person] = []
    let container = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    var searchController: UISearchController!

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")

        originalRightBarButtonItems = navigationItem.rightBarButtonItems

        // Setup UISearchController
        searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.searchBar.autocapitalizationType = .none

        searchController.searchBar.placeholder = "Search by name"
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false

        fetchPeople()
    }

    func fetchPeople() {
        guard let context = context else { return }
        let req = Person.fetchRequest() as NSFetchRequest<Person>
        do {
            self.people = try context.fetch(req)
        } catch {
            print("error")
        }
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
    }

    @IBAction func showAverageAge(_ sender: Any) {
        calculateAverageAge()
        countPeople()
        countPeopleAsync()
    }
    
    @IBAction func editbutton(_ sender: Any) {
        guard let barButton = sender as? UIBarButtonItem else { return }
        tableView.setEditing(!tableView.isEditing, animated: true)
        barButton.title = tableView.isEditing ? "Done" : "Edit"
    }

    @IBAction func addName(_ sender: UIBarButtonItem) {
        let addButton = sender
        let alert = UIAlertController(title: "New Name",
                                      message: "Add a new name",
                                      preferredStyle: .alert)

        let saveAction = UIAlertAction(title: "Save", style: .default)
        { [weak self] action in
            addButton.isEnabled = false
            guard let textField = alert.textFields?.first,
                  let nameToSave = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines),
                  !nameToSave.isEmpty else { return }
            guard let textField2 = alert.textFields?[1].text, let age = Int64(textField2) else { return }
            DispatchQueue.global().async {
                self?.save(name: nameToSave, age: age) {
                    addButton.isEnabled = true
                }
            }
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        alert.addTextField(){ t in t.placeholder = "enter name" }
        alert.addTextField(){ t in t.placeholder = "enter age" }
        alert.addAction(cancelAction)
        alert.addAction(saveAction)
        present(alert, animated: true)
    }

    func save(name: String, age: Int64, completion: @escaping () -> Void) {
        let backgroundContext = self.container?.newBackgroundContext()
        backgroundContext?.performAndWait {
            guard let bg = backgroundContext else { return }
            let entity = Person(context: bg)
            entity.name = name
            entity.age = age
            do {
                try bg.save()
            } catch {
                print("BG save error: \(error)")
            }
            self.context?.performAndWait {
                self.fetchPeople()
            }
            self.context?.perform {
                completion()
            }
        }
    }

    func filterContent(for searchText: String) {
        guard let context = context else { return }
        let request: NSFetchRequest<Person> = Person.fetchRequest()
        if !searchText.isEmpty {
            request.predicate = NSPredicate(format: "name BEGINSWITH[c] %@",searchText)
            request.sortDescriptors = [NSSortDescriptor(key: "age", ascending: false),NSSortDescriptor(key: "name", ascending: false)]
            request.fetchLimit = 2
            request.fetchOffset = 1
            
        }
        do {
            people = try context.fetch(request)
            tableView.reloadData()
        } catch {
            print("Error fetching data: \(error)")
        }
    }
    func calculateAverageAge() {
        guard let context = context else { return }

        // 1) Create a fetch request for Person
        let personFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Person")


        // 4) Create an expression for 'age' average
        let ageExpression = NSExpression(forKeyPath: "age")
        let averageExpression = NSExpression(forFunction: "average:", arguments: [ageExpression])

        // 5) ExpressionDescription to hold the result
        let expressionDescription = NSExpressionDescription()
        expressionDescription.name = "averageAge" //giuving name to computed property
        expressionDescription.expression = averageExpression
        expressionDescription.resultType = .double

        // 6) Configure fetch
        personFetch.propertiesToFetch = [expressionDescription]
        personFetch.resultType = .dictionaryResultType

        do {
            if let result = try context.fetch(personFetch) as? [[String: Any]],
               let average = result.first?["averageAge"] as? Double {
                print("Average age = \(average)")
                let alert = UIAlertController(title: "Average Age", message: "Average Age = \(average)", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                present(alert, animated: true)
            }
        } catch {
            print("Error calculating average age: \(error)")
        }
    }
    
    func countPeople() {
        
        guard let context = context else { return }

        let request = Person.fetchRequest()
        request.resultType = .countResultType // not mandatory
        do{
            let count = try context.count(for: request)
            print(count)
        }catch{
            print("********")
        }
        
        do {
            let idRequest = Person.fetchRequest()
            idRequest.resultType = .managedObjectIDResultType
            let ids = try context.fetch(idRequest) as! [NSManagedObjectID]
            print("IDs =", ids[0])
        } catch {
            print("ID fetch error:", error)
        }
        
        let personFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Person")
        let fetchReqExpression = NSExpression(forConstantValue: personFetch)
        let contextExpression = NSExpression(forConstantValue: context)

        // Use it properly now
        let fetchExpression = NSFetchRequestExpression.expression(
            forFetch: fetchReqExpression,
            context: contextExpression,
            countOnly: true
        )
//        print(fetchExpression)
        let expressionDescription = NSExpressionDescription()
        expressionDescription.name = "personCount"
        expressionDescription.expression = fetchExpression
        expressionDescription.resultType = .integer64

        let outerFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Person")
        outerFetch.propertiesToFetch = [expressionDescription]
        outerFetch.resultType = .dictionaryResultType

        do {
            if let result = try context.fetch(outerFetch) as? [[String: Any]],
               let count = result.first?["personCount"] as? Int64 {
                print("Total number of people: \(count)")
            }
        } catch {
            print("Error: \(error)")
        }
    }

    func countPeopleAsync() {
        guard let context = context else { return }

        // 1️⃣ Create a fetch request
        let request = Person.fetchRequest() as NSFetchRequest<Person>
        request.resultType = .countResultType // Only need the count

        // 2️⃣ Wrap it in an asynchronous fetch request
        let asyncRequest = NSAsynchronousFetchRequest(fetchRequest: request) { result in
            if let finalResult = result.finalResult {
                // Since resultType = .countResultType, we actually need to call count(for:)
                // But NSAsynchronousFetchRequest does not directly support countResultType
                // Instead, fetch objects and count them
                let count = finalResult.count
                print("Total number of people: \(count)")

                DispatchQueue.main.async {
                    let alert = UIAlertController(
                        title: "Person Count",
                        message: "Total number of people: \(count)",
                        preferredStyle: .alert
                    )
                    alert.addAction(UIAlertAction(title: "OK", style: .default))
                    self.present(alert, animated: true)
                }
            }
        }

        // 3️⃣ Execute asynchronously
        do {
            try context.execute(asyncRequest)
        } catch {
            print("Async count fetch failed: \(error)")
        }
    }

}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = people[indexPath.row].name
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView,
                   commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            guard let context = context else { return }
            let personToDelete = people[indexPath.row]
            context.delete(personToDelete)
            do {
                try context.save()
            } catch {
                print("Failed to delete person: \(error)")
                return
            }
            people.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alert = UIAlertController(title: "add", message: "edit name", preferredStyle: .alert)
        alert.addTextField()
        alert.textFields?.first?.text = self.people[indexPath.row].name
        let submit = UIAlertAction(title: "submit", style: .default) { (_) in
            let person = self.people[indexPath.row]
            person.name = alert.textFields?.first?.text
            do {
                try self.context?.save()
            } catch {
                print("error iin save")
            }
            self.fetchPeople()
        }
        alert.addAction(submit)
        present(alert, animated: true)
    }
}

extension ViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        guard let searchText = searchController.searchBar.text else {
            fetchPeople()
            return
        }
        filterContent(for: searchText)
    }
}

/*

| Property                        | Purpose                         | Default                    |
| ------------------------------- | ------------------------------- | -------------------------- |
| `resultType`                    | Type of fetch result            | `.managedObjectResultType` |
| `includesPendingChanges`        | Include unsaved context changes | `true`                     |
| `propertiesToFetch`             | Fetch specific attributes       | `nil`                      |
| `returnsDistinctResults`        | Remove duplicates               | `false`                    |
| `includesPropertyValues`        | Return full objects or just IDs | `true`                     |
| `shouldRefreshRefetchedObjects` | Refresh objects from store      | `false`                    |
| `returnsObjectsAsFaults`        | Return faults or full objects   | `true`                     |
*/
