//
//  ViewController.swift
//  coreDataUIKit
//
//  Created by Priyanka on 08/10/25.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
//    var names:[String] = []
    var people:[NSManagedObject] = []
    
    override func viewWillAppear(_ animated: Bool) {
      super.viewWillAppear(animated)
      guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
          return
      }
      
      let managedContext = appDelegate.persistentContainer.viewContext

      let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Person")

      do {
        people = try managedContext.fetch(fetchRequest)
      } catch let error as NSError {
        print("Could not fetch. \(error), \(error.userInfo)")
      }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        title = "The List"
          
    }
    
    @IBAction func addName(_ sender: UIBarButtonItem) {
      
      let alert = UIAlertController(title: "New Name",
                                    message: "Add a new name",
                                    preferredStyle: .alert)
      
      let saveAction = UIAlertAction(title: "Save",
                                     style: .default) {
        [weak self] action in
                                      
        guard let textField = alert.textFields?.first,
          let nameToSave = textField.text else {
            return
        }
        
          self?.save(name: nameToSave)
        self?.tableView.reloadData()
      }
      
      alert.addTextField()
      
      alert.addAction(saveAction)
      
      present(alert, animated: true)
    }
    func save(name: String) {
      
        //This default managed object context lives as a property of the NSPersistentContainer in the application delegate. To access it, you first get a reference to the app delegate.
      guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
        return
      }
      
      let managedContext = appDelegate.persistentContainer.viewContext

        //An entity description is the piece linking the entity definition from your Data Model with an instance of NSManagedObject at runtime.
      let entity = NSEntityDescription.entity(forEntityName: "Person",
                                   in: managedContext)!
      
        //create a new managed object and insert it into the managed object context.
      let person = NSManagedObject(entity: entity,
                                   insertInto: managedContext)

        //you set the name attribute using key-value coding. You must spell the KVC key exactly as it appears in your data model, otherwise, your app will crash at runtime.
        
      person.setValue(name, forKeyPath: "name")
      do {
        try managedContext.save()
        people.append(person)
      } catch let error as NSError {
        print("Could not save. \(error), \(error.userInfo)")
      }
    }


}
extension ViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = people[indexPath.row].value(forKeyPath: "name") as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}

