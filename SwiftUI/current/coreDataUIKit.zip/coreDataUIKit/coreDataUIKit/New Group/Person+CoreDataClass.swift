//
//  Person+CoreDataClass.swift
//  coreDataUIKit
//
//  Created by Priyanka on 08/10/25.
//
//

import Foundation
import CoreData

@objc(Person)
public class Person: NSManagedObject {

}
