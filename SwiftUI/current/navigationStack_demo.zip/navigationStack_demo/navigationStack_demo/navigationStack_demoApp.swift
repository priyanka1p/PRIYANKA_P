//
//  navigationStack_demoApp.swift
//  navigationStack_demo
//
//  Created by Priyanka on 30/09/25.
//

import SwiftUI

@main
struct navigationStack_demoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
