
import SwiftUI
struct Student:Hashable,Codable{
   var name:String
}
func save(path:NavigationPath){
    if let representation = path.codable{
        let data = try? JSONEncoder().encode(representation)
        UserDefaults.standard.set(data, forKey: "path")
    }
    else{
        return
    }
}
func load() ->NavigationPath{
    if let data = UserDefaults.standard.data(forKey: "path"){
        if let representation = try? JSONDecoder().decode(NavigationPath.CodableRepresentation.self, from: data){
            return NavigationPath(representation)
        }
    }
        return NavigationPath()
}
struct ContentView: View {
    @State var path = NavigationPath()
    @Environment(\.scenePhase) var scene
    var body: some View {
        //print(path)

        return NavigationStack(path: $path){
            VStack{
                NavigationLink("Go to display", value: Student(name: "priya"))
                NavigationLink("go to second",value: Student(name: "ashwini"))
                
            }
            .navigationTitle("title")
            
            .navigationDestination(for: Student.self){ student in
                DisplayView(name:student.name )
        }
            .navigationDestination(for: Int.self){
                DisplayView(name: "NUmber \($0)")
            }
        }
        .onChange(of: scene){old,new in
            if(new == .background){
                print("entered background")
                save(path: path)
            }
        }
        .onAppear(){
            print("onappear")
            //path = load()
           // path.append(Student(name: "teju"))

        }
        
    
    }
}

struct DisplayView:View {
    var name:String
    var body: some View {
        VStack{
            Text("Hello, world!")
            Text(name)
        }
    }
}
#Preview {
    ContentView()
}
