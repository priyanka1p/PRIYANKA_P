

import UIKit
import CoreData

class SingerVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var singers: [Singer] = []
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        fetchSingers()
    }

    func fetchSingers() {
        let fetchRequest: NSFetchRequest<Singer> = Singer.fetchRequest()
        do {
            singers = try context.fetch(fetchRequest)
            let song = try? context.fetch(Songs.fetchRequest()).count
            print("Number of singers: \(singers.count)")
            print("Number of songs: \(song ?? 0)")
            tableView.reloadData()
        } catch {
            print("Error fetching singers: \(error)")
        }
    }

    @IBAction func addSinger(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "New Singer", message: "", preferredStyle: .alert)
        alert.addTextField { $0.placeholder = "Singer Name" }
        let addAction = UIAlertAction(title: "Add", style: .default) { _ in
            let name = alert.textFields?.first?.text ?? ""
            let singer = Singer(context: self.context)
            singer.name = name
            do {
                try self.context.save()
                self.fetchSingers()
            } catch {
                print("Error saving singer: \(error)")
            }
        }
        alert.addAction(addAction)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }
}

extension SingerVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        singers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SingerCell", for: indexPath)
        cell.textLabel?.text = singers[indexPath.row].name
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let songsVC = storyboard.instantiateViewController(withIdentifier: "SongsVC") as? SongsVC {
            songsVC.singer = singers[indexPath.row]
            navigationController?.pushViewController(songsVC, animated: true)
        }
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let singer = singers[indexPath.row]
            context.delete(singer)
            do{
                try context.save()
            }
            catch{
                print("not saves")
            }
//            singers.remove(at: indexPath.row)
//            tableView.deleteRows(at: [indexPath], with: .fade)
            self.fetchSingers()
        }
    }
}
