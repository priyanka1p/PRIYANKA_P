//
//  Songs+CoreDataProperties.swift
//  CoreDataRelationship
//
//  Created by Priyanka on 13/10/25.
//
//

import Foundation
import CoreData


extension Songs {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Songs> {
        return NSFetchRequest<Songs>(entityName: "Songs")
    }

    @NSManaged public var title: String?
    @NSManaged public var releaseDate: String?
    @NSManaged public var singer: Singer?

}

extension Songs : Identifiable {

}
