//
//  Singer+CoreDataClass.swift
//  CoreDataRelationship
//
//  Created by Priyanka on 13/10/25.
//
//

import Foundation
import CoreData

@objc(Singer)
public class Singer: NSManagedObject {

}
