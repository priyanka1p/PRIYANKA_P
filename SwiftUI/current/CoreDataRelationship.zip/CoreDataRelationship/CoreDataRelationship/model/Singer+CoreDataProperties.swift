//
//  Singer+CoreDataProperties.swift
//  CoreDataRelationship
//
//  Created by Priyanka on 13/10/25.
//
//

import Foundation
import CoreData


extension Singer {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Singer> {
        return NSFetchRequest<Singer>(entityName: "Singer")
    }

    @NSManaged public var name: String?
    @NSManaged public var songs: NSSet?

}

extension Singer {

    @objc(addSongsObject:)
    @NSManaged public func addToSongs(_ value: Songs)

    @objc(removeSongsObject:)
    @NSManaged public func removeFromSongs(_ value: Songs)

    @objc(addSongs:)
    @NSManaged public func addToSongs(_ values: NSSet)

    @objc(removeSongs:)
    @NSManaged public func removeFromSongs(_ values: NSSet)

}

extension Singer : Identifiable {

}
