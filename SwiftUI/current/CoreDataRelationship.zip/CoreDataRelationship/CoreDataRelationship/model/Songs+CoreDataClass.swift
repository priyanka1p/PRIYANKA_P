//
//  Songs+CoreDataClass.swift
//  CoreDataRelationship
//
//  Created by Priyanka on 13/10/25.
//
//

import Foundation
import CoreData

@objc(Songs)
public class Songs: NSManagedObject {
    
}
