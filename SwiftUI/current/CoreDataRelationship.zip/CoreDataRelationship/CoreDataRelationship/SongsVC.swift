import UIKit
import CoreData

class SongsVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var singer: Singer!  // This will be set before pushing
    var songs: [Songs] = []
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        let addButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addSong))
           navigationItem.rightBarButtonItem = addButton
        fetchSongs()
    }

    func fetchSongs() {
        guard let singer = singer else { return }
        let fetchRequest: NSFetchRequest<Songs> = Songs.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "singer = %@", singer)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "releaseDate", ascending: false)]
        do {
            songs = try context.fetch(fetchRequest)
            tableView.reloadData()
        } catch {
            print("Error fetching songs: \(error)")
        }
    }

    @objc func addSong() {
        let alert = UIAlertController(title: "New Song", message: nil, preferredStyle: .alert)
        alert.addTextField { $0.placeholder = "Song Title" }
        alert.addTextField { $0.placeholder = "Release Date" }
        
        let addAction = UIAlertAction(title: "Add", style: .default) { _ in
            guard let title = alert.textFields?[0].text, !title.isEmpty,
                  let releaseDate = alert.textFields?[1].text, !releaseDate.isEmpty else { return }

            let song = Songs(context: self.context)
            song.title = title
            song.releaseDate = releaseDate
            song.singer = self.singer

            do {
                try self.context.save()
                self.fetchSongs()
            } catch {
                print("Error saving song: \(error)")
            }
        }
        alert.addAction(addAction)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

}

// MARK: - TableView
extension SongsVC: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        songs.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SongCell", for: indexPath)
        let song = songs[indexPath.row]
        cell.textLabel?.text = "\(song.title ?? "") (\(song.releaseDate ?? ""))"
        return cell
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let song = songs[indexPath.row]
            context.delete(song)
            try? context.save()
            songs.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
}
