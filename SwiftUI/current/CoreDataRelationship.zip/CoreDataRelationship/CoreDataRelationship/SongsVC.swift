import UIKit
import CoreData

class SongsVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var singer: Singer!  // Set before pushing SongsVC
    var songs: [Songs] = []
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addSong))
        fetchSongs()
    }

    @IBAction func clearAllSongs(_ sender: UIButton) {
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = Songs.fetchRequest()
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        batchDeleteRequest.resultType = .resultTypeObjectIDs
        do {
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            let result = try context.execute(batchDeleteRequest) as? NSBatchDeleteResult
            if let objectIDs = result?.result as? [NSManagedObjectID] {
                let changes = [NSDeletedObjectsKey: objectIDs]
                NSManagedObjectContext.mergeChanges(fromRemoteContextSave: changes, into: [context])
            }
            print("All songs deleted")
            self.fetchSongs()
            // Refresh UI or refetch here if needed
        } catch {
            print("Failed to clear songs: \(error)")
        }
    }

    func fetchSongs() {
        let fetchRequest: NSFetchRequest<Songs> = Songs.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "singer = %@", singer)
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "releaseDate", ascending: false)]
        let fetchRequest1: NSFetchRequest<Songs> = Songs.fetchRequest()
        let s = try? context.fetch(fetchRequest1)
        print("all songs count ",s?.count ?? 0)

        do {
            songs = try context.fetch(fetchRequest)
            print("singer's song ",singer?.songs?.count ?? 0)
            tableView.reloadData()
        } catch {
            print("Error fetching songs: \(error)")
        }
    }

    @objc func addSong() {
        let alert = UIAlertController(title: "New Song", message: nil, preferredStyle: .alert)
        alert.addTextField { $0.placeholder = "Song Title" }
        alert.addTextField { $0.placeholder = "Release Date" }
        
        let addAction = UIAlertAction(title: "Add", style: .default) { _ in
            guard let title = alert.textFields?[0].text, !title.isEmpty,
                  let releaseDate = alert.textFields?[1].text, !releaseDate.isEmpty else { return }

            let song = Songs(context: self.context)
            song.title = title
            song.releaseDate = releaseDate
            print(song.entity)                // Entity description
            print(song.objectID)              // NSManagedObjectID
            print(song.isInserted)            //has unsaved changes
            print(song.isFault)
            print(song.isDeleted)
            print(song.isUpdated)
            print(song.faultingState)
            print(song.managedObjectContext ?? "") // contextID
            print(song.hasChanges)
            self.singer?.addToSongs(song)
            
            do {
                // Validate relationship constraints on singer
                try self.singer.validateForUpdate()
                try self.context.save()
                self.fetchSongs()
            } catch {
                self.context.rollback()// rollback creation on failure
                self.showValidationError(error)
            }
        }
        alert.addAction(addAction)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    func showValidationError(_ error: Error) {
        let alert = UIAlertController(title: "Validation Error",
                                      message: error.localizedDescription,
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

extension SongsVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return songs.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SongCell", for: indexPath)
        let song = songs[indexPath.row]
        cell.textLabel?.text = "\(song.title ?? "") (\(song.releaseDate ?? ""))"
        return cell
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
//            let minCount = 1
//            let currentSongCount = singer.songs?.count ?? 0
//            if currentSongCount <= minCount{
//                let alert = UIAlertController(
//                    title: "Cannot Delete",
//                    message: "Minimum number of songs 1 required.",
//                    preferredStyle: .alert
//                )
//                alert.addAction(UIAlertAction(title: "OK", style: .default))
//                present(alert, animated: true)
//                return
//            }
            
            let song = songs[indexPath.row]
//            singer.removeFromSongs(song)
            context.delete(song)
            do{
                try self.singer.validateForDelete()
            }catch{
                context.rollback()
                print("nk")
                return
            }

            do{
                try context.save()
            }
            catch{
                print("rolled back")
                context.rollback()
            }
            self.fetchSongs()
            
                
        }
    }
}
