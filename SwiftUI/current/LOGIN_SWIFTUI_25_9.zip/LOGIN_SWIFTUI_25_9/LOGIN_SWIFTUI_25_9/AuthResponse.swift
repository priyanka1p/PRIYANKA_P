
import Foundation
import CryptoKit

// the desired response from server to be accessed by user.
struct AuthResponse {
    let userName: String
    let thumbnail: String
}

class AuthService {
    static let shared = AuthService()
    private init() {}
    
    // to hash the password - MD5
    func md5Hash(_ input: String) -> String {
        let inputData = Data(input.utf8)
        //The result is a Digest type, essentially a fixed-size array of bytes (16 bytes for MD5).
        let hashed = Insecure.MD5.hash(data: inputData)
        //two-digit lowercase hexadecimal string.
        return hashed.map { String(format: "%02x", $0) }.joined()
    }
    
    // to get checksum to ensure no tampering has happened to data, integrity
    func hmacSHA256(msg: String, key: String) -> String {
        let keyData = Data(key.utf8)
        let messageData = Data(msg.utf8)
        let keySym = SymmetricKey(data: keyData) // convert into symmetric key
        //authenticationCode- computes the HMAC for the given message using the symmetric key
        //The result is a fixed-size Digest (sequence of bytes)
        let signature = HMAC<SHA256>.authenticationCode(for: messageData, using: keySym)
        //Convert the Digest to Data, then map each byte
        return Data(signature).map { String(format: "%02x", $0) }.joined()
    }
    
    // to validate login credentials
    func login(
        email: String,
        password: String,
        completion: @escaping (Result<AuthResponse, Error>) -> Void
    ) {
        let md5Password = md5Hash(password)
        // request body
        let requestBody: [String: Any] = [
            "User":[
                "email": email,
                "password": md5Password,
                "timezone": TimeZone.current.identifier
            ],
            "Client": [
                "identity": "21V21B337GMX2",
                "version": "2.2",
                "session_hash": "ef1c795f5d1e40e286a9f1598312851c",
            ],
            "api": [
                "app_version": "7.7.6",
                "version": "2.3"
            ],
            "Session" : [
                "token" : "NO-TOKEN"
            ]
        ]
        
        let requestWrapper: [String: Any] = ["Request": requestBody]
        
        // serialized requestwrapper to calculate checksum
        // use sortedKeys to maintain the order of data
        // use withoutEscapingSlashes to prevent adding additional slashes
        guard let jsonData = try? JSONSerialization.data(
            withJSONObject: requestWrapper,
            options: [.sortedKeys , .withoutEscapingSlashes]
        ),
              let jsonString = String(data: jsonData, encoding: .utf8) else {
            completion(.failure(NSError(domain: "jsonEncoding", code: 0)))
            return
        }
        
        //calculate checksum
        let requestToken = "NO-TOKEN"
        let clientKey = "eQmqIhqfIeNs0OX6avY5YpauB"
        let rawString = requestToken + jsonString + clientKey
        let checksum = hmacSHA256(msg: rawString, key: requestToken)
        
        //final request to be sent to server
        let finalBody: [String: Any] = [
            "mwsRequest": [
                "String": requestWrapper,
                "Checksum": checksum
            ]
        ]
        
        // serialize the final request to send to internet
        guard let finalJsonData = try? JSONSerialization.data(
            withJSONObject: finalBody,
            options: [.sortedKeys]
        ) else {
            completion(.failure(NSError(domain: "finalJson", code: 0)))
            return
        }
        
        //create URL request
        let baseURL = "https://webd.prgr.in/api/v2/"
        var request = URLRequest(url: URL(string: baseURL + "/login")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = finalJsonData
        
        //task created to initate the request
        URLSession.shared.dataTask(with: request) { data, response, error in
            // 1. Handle networking errors first
            if let error = error {
                print("Request failed:", error.localizedDescription)
                return
            }
            //
            // 2. Validate HTTP response
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code:", httpResponse.statusCode)
                guard (200...299).contains(httpResponse.statusCode) else {
                    print("Server error: \(httpResponse.statusCode)")
                    return
                }
            }
            
            //decode the serialized json data, to read original data body.
            //code = 000, success
            //code = 004, checksum error
            //code = 006, wrong request body
            //code = 007, missing parameters( eg: url request creation - missing to set Content-Type)
            guard let data = data,
                  let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                  let mwsResponse = json["mwsResponse"] as? [String: Any],
                  let status = mwsResponse["status"] as? [String: Any],
                  let code = status["code"] as? String,
                  code == "000" else {
                completion(.failure(NSError(domain: "invalidResponse", code: 100)))
                return
            }
            
            var userName = ""
            var thumbnail = ""
            if let user = mwsResponse["user"] as? [String: Any] {
                userName = user["name"] as? String ?? ""
                thumbnail = user["thumbnail"] as? String ?? ""
            }
            
            completion(.success(AuthResponse(userName: userName, thumbnail: thumbnail)))
        }.resume()
    }
}
