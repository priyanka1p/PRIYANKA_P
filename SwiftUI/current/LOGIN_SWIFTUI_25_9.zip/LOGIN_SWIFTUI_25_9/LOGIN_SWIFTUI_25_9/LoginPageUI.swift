import SwiftUI


class LoginPageModel:ObservableObject {
    @Published var email:String = ""
    @Published var password:String = ""
    @Published var loginValidationLabel:String = ""
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "^[^0-9.][A-Za-z0-9._%+-]{0,49}@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        return email.range(of: emailRegex, options: .regularExpression) != nil
    }
    func loginButtonPressed(email:String,password:String) -> Bool{
        if isValidEmail(email) == false{
            loginValidationLabel = "Invalid Email"
            return false
        }
        
        let email = email.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = password.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if let saved_password = emailDatabase[email]{
            if saved_password == password{
                loginValidationLabel = "Login Successful"
                return true
            }
            else{
                loginValidationLabel = "Wrong Password"
                return false
            }
        }
        else{
            loginValidationLabel = "Email not found"
            return false
        }
    }
}

let emailDatabase: [String: String] = [
    "J@GMAIL.COM": "J",
    "alice@example.com": "Alice@123",
    "priya@gmail.com": "Priya@123"
]
struct LoginPageUI:View {
    @StateObject var loginPageModel:LoginPageModel = LoginPageModel()
    @Binding var isLoggedIn: Bool
    @Binding var email: String
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment:.leading) {
                    TitleLabel()
                    InputTextField(loginPageModel: loginPageModel, type:"email")
                    InputTextField(loginPageModel: loginPageModel, type: "password")
                    LoginButton(loginPageModel: loginPageModel, isLoggedIn: $isLoggedIn, email: $email)
                    MediaSignInOptions()
                    Forgotlabels()
                }
            }
            .padding(.top,50)
            .padding(.leading,10)
            .padding(.trailing,10)
            
            .navigationDestination(isPresented: $isLoggedIn) {
                HomePageUI(email: loginPageModel.email, isLoggedIn: $isLoggedIn)
                    .navigationBarBackButtonHidden(true)
                
            }
            
        }
    }
}
struct TitleLabel:View {
    var body: some View {
        Text("Parent/Guardian Log In")
            .fontWeight(.bold)
            .font(.title)
            .padding(.bottom,20)
    }
}
struct InputTextField: View {
    @ObservedObject var loginPageModel:LoginPageModel
    @State var isPasswordVisible: Bool = false
    @FocusState var focusedField: Field?
    enum Field {
        case email
        case password
    }
    var type:String
    var body: some View{
        if type == "email"{
            Text("Email")
                .font(.headline)
            TextField("enter your email address",text: $loginPageModel.email)
                .textInputAutocapitalization(.never)
                .focused($focusedField, equals: .email)
                .submitLabel(.next)
                .onSubmit {
                    focusedField = .password
                }
        }
        else {
            Text("Password")
                .font(.headline)
            HStack {
                if isPasswordVisible {
                    TextField("enter your password", text: $loginPageModel.password)
                        .textInputAutocapitalization(.never)
                        .focused($focusedField, equals: .password)
                        .submitLabel(.done)
                        .onSubmit {
                            focusedField = nil
                        }
                } else {
                    SecureField("enter your password", text: $loginPageModel.password)
                        .textInputAutocapitalization(.never)
                        .focused($focusedField, equals: .password)
                        .submitLabel(.done)
                        .onSubmit {
                            focusedField = nil
                        }
                }
                Button(action: {
                    isPasswordVisible.toggle()
                }) {
                    Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                        .foregroundColor(.gray)
                }
            }
        }
        
        Rectangle()
            .frame(height: 1)
            .foregroundColor(.black)
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}
struct LoginButton:View{
    @ObservedObject var loginPageModel:LoginPageModel
    @Binding var isLoggedIn: Bool
    @Binding var email: String

    var body: some View{
        Text(loginPageModel.loginValidationLabel)
            .font(.system(size: 12))
            .padding(.bottom,20)
        Button{
            let loggedInStatus = loginPageModel.loginButtonPressed(email: loginPageModel.email, password: loginPageModel.password)
            print("logged in \(loggedInStatus)")
            if loggedInStatus {
                isLoggedIn = true
                UserDefaults.standard.set(loggedInStatus, forKey: "isLoggedIn")
                UserDefaults.standard.set(loginPageModel.email, forKey: "email")
                
                email = loginPageModel.email
                isLoggedIn = true
            }
        } label:{
            Text("Log In")
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(.borderedProminent)
        .disabled(loginPageModel.email.isEmpty || loginPageModel.password.isEmpty)
        
    }
}

struct MediaSignInOptions: View {
    var body: some View {
        HStack{
            Spacer()
            VStack{
                Text("Or")
                HStack(spacing: 20){
                    Image("f_30")
                        .resizable()
                        .cornerRadius(2)
                        .frame(width: 40, height: 40)
                        .shadow(color: .black.opacity(0.5), radius: 2, x: 0, y: 0)
                    
                    Image("google_30")
                        .resizable()
                        .frame(width: 40, height: 40)
                        .cornerRadius(2)
                        .shadow(color: .black.opacity(0.5), radius: 2, x: 0, y: 0)
                    
                    Image("apple_35_2")
                        .resizable()
                        .frame(width: 40, height: 40)
                        .cornerRadius(2)
                        .shadow(color: .black.opacity(0.5), radius: 2, x: 0, y: 0)
                }
            }
            Spacer()
        }
        .padding(.bottom,20)
    }
}
struct Forgotlabels:View {
    var body: some View {
        VStack(alignment: .leading){
            HStack{
                Image(systemName: "network")
                Text("Forgot your password?")
                    .foregroundColor(Color.blue)
            }.padding(.top,2)
            HStack{
                Image(systemName: "person.fill")
                Text("Don't have an account? Sign Up")
                    .foregroundColor(Color.blue)
            }.padding(.top,2)
            
        }
    }
}

