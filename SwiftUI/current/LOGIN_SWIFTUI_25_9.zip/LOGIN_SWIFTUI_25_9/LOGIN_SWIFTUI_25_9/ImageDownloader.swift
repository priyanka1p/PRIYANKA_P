import SwiftUI


class ImageDownloader: ObservableObject {
    static let shared = ImageDownloader()
    let imageCache = NSCache<NSURL, UIImage>()
    private var activeURL: URL?
    @Published var image: UIImage? = nil

     var diskDirectory: URL = {
        let directory = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask)[0]
        let diskDirectory = directory.appendingPathComponent("ios_login")
        if !FileManager.default.fileExists(atPath: diskDirectory.path) {
            try? FileManager.default.createDirectory(at: diskDirectory, withIntermediateDirectories: true)
        }
        return diskDirectory
    }()


    func loadImage(from url: URL) {
        activeURL = url
        // Check memory cache
        if let cached = self.imageCache.object(forKey: url as NSURL) {
            self.image = cached
            return
        }

        // Check disk cache
        let diskFile = self.diskDirectory.appendingPathComponent(url.lastPathComponent)
        if FileManager.default.fileExists(atPath: diskFile.path),
           let diskImage = UIImage(contentsOfFile: diskFile.path) {
            self.imageCache.setObject(diskImage, forKey: url as NSURL)
            self.image = diskImage
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, let downloaded = UIImage(data: data) else { return }
            
            // Save in memory and disk cache
            self.imageCache.setObject(downloaded, forKey: url as NSURL)
            try? data.write(to: diskFile)
            
            if self.activeURL == url {
                DispatchQueue.main.async {
                    self.image = downloaded
                }
            } else {
                print("Downloaded image ignored (URL mismatch)")
            }
            
        }.resume()
    }

    func clearCache() {
        self.imageCache.removeAllObjects()
        if FileManager.default.fileExists(atPath: diskDirectory.path) {
            try? FileManager.default.removeItem(at: diskDirectory)
            try? FileManager.default.createDirectory(at: diskDirectory, withIntermediateDirectories: true)
        }
    }
}
