import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}

struct RootView: View {
    @State private var isLoggedIn: Bool = UserDefaults.standard.bool(forKey: "isLoggedIn")
    @State private var email: String = UserDefaults.standard.string(forKey: "email") ?? ""
    
    var body: some View {
        NavigationStack {
            if isLoggedIn {
                HomePageUI(email: email, isLoggedIn: $isLoggedIn)
                    .navigationBarBackButtonHidden(true)
            } else {
                LoginPageUI(isLoggedIn: $isLoggedIn, email: $email)
            }
        }
    }
}
