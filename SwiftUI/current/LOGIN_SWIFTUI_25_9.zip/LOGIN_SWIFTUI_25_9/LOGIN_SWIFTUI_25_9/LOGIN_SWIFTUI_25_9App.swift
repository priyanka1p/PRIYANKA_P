import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
enum Route:Hashable{
    case home(userName: String, thumbnail: String)
    case second
}

struct RootView: View {
    @State private var email: String = (KeychainManager.shared.get(account: AccountName.userEmail.rawValue) ?? "")
    @State private var password: String = (KeychainManager.shared.get(account: AccountName.userPassword.rawValue) ?? "")
    @State private var path = NavigationPath()

    var body: some View {
        print(email, UserDefaults.standard.bool(forKey: "isLoggedIn"))
        print(password)
        return NavigationStack(path: $path) {
            LoginPageUI( path: $path, rootEmail:$email)
                .navigationDestination(for: Route.self) { route in
                    switch route {
                    case .home(let userName, let thumbnail):
                        HomePageUI(userName: userName, thumbnail : thumbnail, email: email, path: $path)
                    case .second:
                        second(email: email)
                    }
                }
        }
        .onAppear {
            print("onappear")
            if UserDefaults.standard.bool(forKey: "isLoggedIn") {
                AuthService.shared.login(email: email, password: password) { result in
                    DispatchQueue.main.async {
                        print("scene")
                        switch result {
                            
                        case .success(let authResponse):
                            path.append(Route.home(userName: authResponse.userName, thumbnail: authResponse.thumbnail))
                        
                        case .failure:
                            print("failure")
                            ImageDownloader.shared.clearCache()
                            KeychainManager.shared.delete(account: AccountName.userEmail.rawValue)
                            KeychainManager.shared.delete(account: AccountName.userPassword.rawValue)
                            UserDefaults.standard.set(false, forKey: "isLoggedIn")
                        }
                    }
                }
            }
        }
    }
}
