import SwiftUI

struct HomePageUI: View {
    var email: String
    @Binding var isLoggedIn: Bool
    var body: some View {
        VStack(alignment:.center) {
            AsyncImage(url: URL(string: "https://images.indianexpress.com/2017/07/dhoni-m6.jpg?w=414")) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .frame(width: 200, height: 200)

                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                case .failure(_):
                        Image(systemName: "photo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 200)
                            .foregroundColor(.gray)
                    
                @unknown default:
                    fatalError("Unknown error occurred")
                }
            }
            Text("Welcome!!!")
                .font(.largeTitle)
            Text(email)
                .font(.headline)
            Spacer()
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("Logout") {
                    UserDefaults.standard.removeObject(forKey: "isLoggedIn")
                    UserDefaults.standard.removeObject(forKey: "email")
                    isLoggedIn = false
                }
            }
        }
    }
}

