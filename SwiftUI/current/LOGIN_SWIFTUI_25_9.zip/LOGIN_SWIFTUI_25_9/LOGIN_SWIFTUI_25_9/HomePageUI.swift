import SwiftUI

struct CachedImageView: View {
    @StateObject private var downloader = ImageDownloader()
    let url: URL

    var body: some View {
        VStack{
            if let image = downloader.image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .border(.blue)
            } else {
                ProgressView()
            }
        }
        .onAppear {
            downloader.loadImage(from: url)
        }
    }
}


struct HomePageUI: View {
    
    var userName: String
    var thumbnail: String
    var email: String
    @Binding var path: NavigationPath
    
    var body: some View {
        VStack {
            Text("Welcome!!!")
                .font(.title)
                .fontWeight(.bold)
            Group{
                if let url = URL(string: thumbnail) {
                    CachedImageView(url: url)
                } else {
                    Image(systemName: "person.circle.fill")
                        .resizable()
                        .foregroundColor(.gray)
                }
            }.frame(width: 350, height: 250)
            
            Text(userName)
                .font(.title3)
            Button("Go to profile"){
                path.append(Route.second)
            }
            Spacer()
        }
        .padding()
        .navigationBarBackButtonHidden(true)
        .toolbar{
            ToolbarItem(placement: .automatic){
                Button("logout") {
                    logout()
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }
    
    func logout() {
        KeychainManager.shared.delete(account: AccountName.userEmail.rawValue)
        KeychainManager.shared.delete(account: AccountName.userPassword.rawValue)
        ImageDownloader.shared.clearCache()
        UserDefaults.standard.set(false, forKey: "isLoggedIn")
        path.removeLast()
    }
}

struct second:View{
    var email:String
    var body: some View{
        VStack{
            Text(email)
        }
            .toolbar {
                ToolbarItem(placement: .principal){
                    Button("Title"){
                        print("title pressed")
                    }
                }
            }
        }
    }

            
//AsyncImage(url: url) { phase in
//    switch phase {
//    case .empty:
//        ProgressView()
//            .frame(width: 200, height: 200)
//        
//    case .success(let image):
//        image
//            .resizable()
//            .scaledToFit()
//    case .failure(_):
//        Image(systemName: "photo")
//            .resizable()
//            .scaledToFit()
//            .frame(width: 200, height: 200)
//            .foregroundColor(.gray)
//        
//    @unknown default:
//        fatalError("Unknown error occurred")
//    }
//}
