import SwiftUI

struct HomePageUI: View {
    var body: some View {
        VStack(alignment:.center) {
            AsyncImage(url: URL(string: "https://images.indianexpress.com/2017/07/dhoni-m6.jpg?w=414")) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .frame(width: 200, height: 200)

                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                case .failure(_):
                        Image(systemName: "photo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 200)
                            .foregroundColor(.gray)
                    
                @unknown default:
                    fatalError("Unknown error occurred")
                }
            }
            Text("Welcome!!!")
                .font(.largeTitle)
            Spacer()
        }
    }
}

#Preview {
    HomePageUI()
}
