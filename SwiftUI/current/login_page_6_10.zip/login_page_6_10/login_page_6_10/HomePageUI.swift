import SwiftUI

struct HomePageUI: View {
    var userName: String
    var thumbnail: String
    @Binding var email: String
    @Binding var isLoggedIn: Bool
    @State var goTo = false
    @StateObject private var imageDownloader = ImageDownloader()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Welcome!!!").font(.largeTitle)
            
            Group {
                if let image = imageDownloader.image {
                    Image(uiImage: image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                } else {
                    ProgressView()
                }
            }
            .frame(width: 200, height: 200)
            .onAppear {
                if let url = URL(string: thumbnail) {
                    imageDownloader.loadImage(from: url)
                }
            }
            
            Text(userName).font(.title3)
            
            Button("Go") {
                print(email)
                goTo = true
            }
            .navigationDestination(isPresented: $goTo) {
                second(email: $email)
            }
            .buttonStyle(.borderedProminent)
            
            Spacer()
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .automatic) {
                Button("Logout") {
                    logout()
                }
                .buttonStyle(.bordered)
            }
        }
    }
    
    func logout() {
        ImageDownloader.clearCache()
        KeychainManager.shared.delete(account: AccountName.userEmail.rawValue)
        KeychainManager.shared.delete(account: AccountName.userPassword.rawValue)
        UserDefaults.standard.set(false, forKey: "isLoggedIn")
        isLoggedIn = false
    }
}

struct second:View{
    @Binding var email:String
    var body: some View{
        VStack{
            Text(email)
        }
            .toolbar {
                ToolbarItem(placement: .principal){
                    Button("Title"){
                        print("title pressed")
                    }
                }
            }
        }
    }
