import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}

struct RootView: View {
    @State private var email: String = KeychainManager.shared.get(account: AccountName.userEmail.rawValue) ?? ""
    @State private var password: String = KeychainManager.shared.get(account: AccountName.userPassword.rawValue) ?? ""
    @State private var isLoggedIn: Bool = UserDefaults.standard.bool(forKey: "isLoggedIn")
    @State private var isCheckingLogin = false
    @State private var authResponse: AuthResponse? = nil

    var body: some View {
        NavigationStack {
            Group {
                if isLoggedIn {
                    if let auth = authResponse {
                        HomePageUI(
                            userName: auth.userName,
                            thumbnail: auth.thumbnail,
                            email: $email,
                            isLoggedIn: $isLoggedIn
                        )
                    } else {
                        ProgressView("Loading...")
                            .onAppear { checkLogin() }
                    }
                } else {
                    LoginPageUI(isLoggedIn: $isLoggedIn, mainEmail:$email)
                }
            }
        }
        .onAppear {
            // Listen for successful login
            NotificationCenter.default.addObserver(forName: .didLoginSuccessfully, object: nil, queue: .main) { notification in
                if let auth = notification.object as? AuthResponse {
                    authResponse = auth
                }
            }
        }
    }

    func checkLogin() {
        guard !isCheckingLogin else { return }
        isCheckingLogin = true

        AuthService.shared.login(email: email, password: password) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    authResponse = response
                case .failure:
                    ImageDownloader.clearCache()
                    isLoggedIn = false
                    KeychainManager.shared.delete(account: AccountName.userEmail.rawValue)
                    KeychainManager.shared.delete(account: AccountName.userPassword.rawValue)
                    UserDefaults.standard.set(false, forKey: "isLoggedIn")
                }
                isCheckingLogin = false
            }
        }
    }
}


extension Notification.Name {
    static let didLoginSuccessfully = Notification.Name("didLoginSuccessfully")
}

