
import SwiftUI


class LoginPageModel:ObservableObject {
    @Published var email:String = ""
    @Published var password:String = ""
    @Published var loginValidationLabel:String = ""

    func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "^[^0-9.][A-Za-z0-9._%+-]{0,49}@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        return email.range(of: emailRegex, options: .regularExpression) != nil
    }
    
}

struct LoginPageUI:View {
    @StateObject var loginPageModel:LoginPageModel = LoginPageModel()
    @Binding var isLoggedIn:Bool
    @Binding var mainEmail:String

    var canLogin: Bool {
            !loginPageModel.email.isEmpty && !loginPageModel.password.isEmpty
        }
    var body: some View {
       ScrollView {
                VStack(alignment:.leading) {
                    TitleLabel()
                    InputTextField( credential: $loginPageModel.email, type:"email")
                    InputTextField( credential: $loginPageModel.password,type: "password")
                    
                    LoginButton(email: $loginPageModel.email, password: $loginPageModel.password,loginValidationLabel: $loginPageModel.loginValidationLabel,isLoggedIn: $isLoggedIn, canLogin: canLogin, mainEmail: $mainEmail)
                    MediaSignInOptions()
                    Forgotlabels()
                    
                }
            
            .padding(.top,50)
            .padding(.leading,10)
            .padding(.trailing,10)
            
            
        }
    }
}
struct TitleLabel:View {
    var body: some View {
        Text("Parent/Guardian Log In")
            .fontWeight(.bold)
            .font(.title)
            .padding(.bottom,20)
    }
}

struct TextFieldTitleLabel: View {
    var text: String
    var body: some View {
        Text(text)
            .font(.headline)
    }
}

struct InputTextField: View {
    @Binding var credential: String
    @State var isPasswordVisible: Bool = false
    @FocusState var focusedField: Field?
    enum Field {
        case email
        case password
    }
    var type:String
    var body: some View{
         if type == "email"{
            TextFieldTitleLabel(text: "Email")
            TextField("enter your email address",text: $credential)
                .textInputAutocapitalization(.never)
                .focused($focusedField, equals: .email)
                .submitLabel(.next)
                .onSubmit {
                    focusedField = .password
                }
                .padding(4)
                .overlay(
                    RoundedRectangle(cornerRadius: 7)
                        .stroke(Color.gray, lineWidth: 1)
                )
                .padding(1)
        }
            else {
                TextFieldTitleLabel(text: "Password")
                HStack {
                    if isPasswordVisible {
                        TextField("Enter your password", text: $credential)
                            .textInputAutocapitalization(.never)
                            .focused($focusedField, equals: .password)
                            .submitLabel(.done)
                            .onSubmit { focusedField = nil }
                    } else {
                        SecureField("Enter your password", text: $credential)
                            .textInputAutocapitalization(.never)
                            .focused($focusedField, equals: .password)
                            .submitLabel(.done)
                            .onSubmit { focusedField = nil }
                    }
                    
                    Button(action: {
                        isPasswordVisible.toggle()
                    }) {
                        Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                            .foregroundColor(.gray)
                    }
                }
                .padding(4)
                .overlay(
                    RoundedRectangle(cornerRadius: 7)
                        .stroke(Color.gray, lineWidth: 1)
                )
                .padding(1)
            }
        
    }
}
struct LoginButton: View {
    @Binding var email: String
    @Binding var password: String
    @Binding var loginValidationLabel: String
    @Binding var isLoggedIn: Bool
    var canLogin: Bool
    @Binding var mainEmail:String

    var body: some View {
        VStack {
            Text(loginValidationLabel)
                .font(.system(size: 12))
                .padding(.bottom, 20)
            
            Button {
                AuthService.shared.login(email: email, password: password) { result in
                    DispatchQueue.main.async {
                        switch result {
                        case .success(let authResponse):
                            print("SUCCESS:", authResponse)
                            
                            // Save credentials
                            _ = KeychainManager.shared.save(password, account: AccountName.userPassword.rawValue)
                            _ = KeychainManager.shared.save(email, account: AccountName.userEmail.rawValue)
                            UserDefaults.standard.set(true, forKey: "isLoggedIn")
                            mainEmail = email
                            // Send notification to RootView
                            NotificationCenter.default.post(name: .didLoginSuccessfully, object: authResponse)
                            isLoggedIn = true
                            
                        case .failure(let error):
                            print(" FAILURE:", error.localizedDescription)
                            loginValidationLabel = "Login failed. Please check your credentials."
                        }
                    }
                }
            } label: {
                Text("Log In")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(!canLogin)
        }
    }
}

struct MediaSignInOptions: View {
    var body: some View {
        HStack{
            Spacer()
            VStack{
                Text("Or")
                HStack(spacing: 20){
                    Image("f_30")
                        .resizable()
                        .cornerRadius(2)
                        .frame(width: 40, height: 40)
                        .shadow(color: .black.opacity(0.5), radius: 2, x: 0, y: 0)
                    
                    Image("google_30")
                        .resizable()
                        .frame(width: 40, height: 40)
                        .cornerRadius(2)
                        .shadow(color: .black.opacity(0.5), radius: 2, x: 0, y: 0)
                    
                    Image("apple_35_2")
                        .resizable()
                        .frame(width: 40, height: 40)
                        .cornerRadius(2)
                        .shadow(color: .black.opacity(0.5), radius: 2, x: 0, y: 0)
                }
            }
            Spacer()
        }
        .padding(.bottom,20)
    }
}
struct Forgotlabels:View {
    
    var body: some View {
        VStack(alignment: .leading){
            HStack{
                Image(systemName: "network")
                Text("Forgot your password?")
                    .foregroundColor(Color.blue)
            }.padding(.top,2)
            HStack{
                Image(systemName: "person.fill")
                Text("Don't have an account? Sign Up")
                    .foregroundColor(Color.blue)
            }.padding(.top,2)
            
        }
    }
}

