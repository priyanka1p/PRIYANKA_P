//
//  AccountName.swift
//  login_page_6_10
//
//  Created by Priyanka on 06/10/25.
//


import UIKit
import Security
//account identifiers to be stored in keychain
enum AccountName: String {
    case userEmail
    case userPassword
}

class KeychainManager {
    
    static let shared = KeychainManager()
    private init() {}

    private let service = "com.priyanka.task-1-1-keychain"
    
    // Save item in Keychain
    func save(_ value: String, account: String) -> Bool {
        guard let data = value.data(using: .utf8) else { return false }

        // Delete old item if exists
        delete(account: account)
        // to set the hierarchy for the data to be stored.
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data
        ]

        let status = SecItemAdd(query as CFDictionary, nil)
        return status == errSecSuccess
    }

    //retrieving the data stored
    func get(account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
        ]

        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        guard status == errSecSuccess,
              let data = item as? Data,
              let value = String(data: data, encoding: .utf8) else { return nil }
        return value
    }

    //delete the data in keychain
    func delete(account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }

   
}
