import SwiftUI

class ImageDownloader: NSObject, ObservableObject, URLSessionDataDelegate {
    @Published var image: UIImage? = nil
    private var activeData: Data?
    private var activeURL: URL?
    static let imageCache = NSCache<NSURL, UIImage>()
    
    
    static var diskDirectory: URL = {
        let directory = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask)[0]
        let diskDirectory = directory.appendingPathComponent("ios_login_1")
        if !FileManager.default.fileExists(atPath: diskDirectory.path) {
            try? FileManager.default.createDirectory(at: diskDirectory, withIntermediateDirectories: true)
        }
        return diskDirectory
    }()

    func loadImage(from url: URL) {
        activeURL = url

        // 1. Check Memory Cache
        if let cached = Self.imageCache.object(forKey: url as NSURL) {
            DispatchQueue.main.async {
                self.image = cached
            }
            return
        }

        // 2. Check Disk Cache
        let diskFile = Self.diskDirectory.appendingPathComponent(url.lastPathComponent)
        if FileManager.default.fileExists(atPath: diskFile.path),
           let diskImage = UIImage(contentsOfFile: diskFile.path) {
            Self.imageCache.setObject(diskImage, forKey: url as NSURL)
            DispatchQueue.main.async {
                self.image = diskImage
            }
            return
        }

        // 3. Download from Network
        let config = URLSessionConfiguration.default
        let urlSession = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        activeData = Data()
        let task = urlSession.dataTask(with: url)
        task.resume()
    }

    //URLSessionDataDelegate
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        activeData?.append(data)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
            if let error = error {
                print("Image download failed:", error.localizedDescription)
                return
            }
            guard let url = self.activeURL,
                  let data = self.activeData,
                  let downloaded = UIImage(data: data) else { return }

            Self.imageCache.setObject(downloaded, forKey: url as NSURL)
            let diskFile = Self.diskDirectory.appendingPathComponent(url.lastPathComponent)
            try? data.write(to: diskFile)
            
            if self.activeURL == url {
                DispatchQueue.main.async {
                    self.image = downloaded
                }
            }
            else{
                print("not valid image for the position")
            }
    }

    // Clear Cache
    static func clearCache() {
        imageCache.removeAllObjects()
        if FileManager.default.fileExists(atPath: diskDirectory.path) {
            try? FileManager.default.removeItem(at: diskDirectory)
            try? FileManager.default.createDirectory(at: diskDirectory, withIntermediateDirectories: true)
        }
    }
}
