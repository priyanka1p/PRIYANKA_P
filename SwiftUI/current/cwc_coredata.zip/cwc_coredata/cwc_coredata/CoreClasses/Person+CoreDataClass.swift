//
//  Person+CoreDataClass.swift
//  cwc_coredata
//
//  Created by Priyanka on 13/10/25.
//
//

import Foundation
import CoreData

@objc(Person)
public class Person: NSManagedObject {

}
