//
//  ViewController.swift
//  cwc_coredata
//
//  Created by Priyanka on 13/10/25.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var TableView: UITableView!
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    @IBAction func addPerson(_ sender: Any) {
        let alert = UIAlertController(title: "Add Person", message: "enter details", preferredStyle: .alert)
        alert.addTextField{text in
            text.placeholder = "Enter Name"
        }
        alert.addTextField{text in
            text.placeholder = "Enter Age"
        }
        
        let textField = alert.textFields?.first

        let addAction = UIAlertAction(title: "Save", style: .default){ (action) in
            //create a person
            let person = Person(context: self.context)
            person.name = textField?.text
            if let age = alert.textFields?[1].text{
                if let age = Int64(age) {
                    person.age = age
                }
            }else{
                person.age = 0
            }
            // save the context
            do{
                try self.context.save()
            }
            catch{
                print("context save failed")
            }
            
            //reload the tableView
            self.fetchPeople()
            
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        alert.addAction(addAction)
        alert.addAction(cancelAction)
        self.present(alert,animated: true)
        
        }
    
    var items:[Person]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        TableView.dataSource = self
        TableView.delegate = self
        
        TableView.register(UITableViewCell.self, forCellReuseIdentifier: "MyCell")
        
        fetchPeople()
    }

    func fetchPeople(){
        
        let fetchRequest = Person.fetchRequest() as NSFetchRequest<Person>
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        fetchRequest.predicate = NSPredicate(format: "%@ == name OR name == %@ ", "pri" , "maggie")
        fetchRequest.predicate = NSPredicate(format: "age > 30 AND name in %@",["pri","sammy","priyanka"] )

        do{
            self.items = try context.fetch(fetchRequest)
        }
        catch{
            print("Cannot fetch items from context")
        }
        
        DispatchQueue.main.async{
            self.TableView.reloadData()
        }
    }

}

extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell",for: indexPath)
        cell.textLabel?.text = items?[indexPath.row].name
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let action = UIContextualAction(style: .destructive, title: "delete") {(action,view,completion) in
           
            let personToremove = self.items![indexPath.row]
            self.context.delete(personToremove)
            do{
                try self.context.save()
            }
            catch{
                print("context save error")
            }
            self.fetchPeople()
        }
        return UISwipeActionsConfiguration(actions: [action])
    }
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let alert = UIAlertController(title: "Edit name", message: "name", preferredStyle: .alert)
        alert.addTextField()
        
        let submitAction = UIAlertAction(title: "Submit", style: .default) { (action) in
            let personToEdit = self.items![indexPath.row]
            personToEdit.name = alert.textFields?.first?.text
            
            do{
                try self.context.save()
            }catch{
                print("error iin save")
            }
            self.fetchPeople()
        }
        
        alert.addAction(submitAction)
        self.present(alert, animated: true)
    }
}
