//
//  Person+CoreDataClass.swift
//  coreData
//
//  Created by Priyanka on 08/10/25.
//
//

import Foundation
import CoreData


public class Person: NSManagedObject {

}
