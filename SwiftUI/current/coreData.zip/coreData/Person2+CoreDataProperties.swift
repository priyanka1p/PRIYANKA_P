//
//  Person2+CoreDataProperties.swift
//  coreData
//
//  Created by Priyanka on 08/10/25.
//
//

import Foundation
import CoreData


extension Person2 {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Person2> {
        return NSFetchRequest<Person2>(entityName: "Person2")
    }

    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var subjects: [String]?

}

extension Person2 : Identifiable {

}
