//
//  Person+CoreDataProperties.swift
//  coreData
//
//  Created by Priyanka on 08/10/25.
//
//

import Foundation
import CoreData


extension Person {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Person> {
        return NSFetchRequest<Person>(entityName: "Person")
    }

    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var subjects: [string]?

}

extension Person : Identifiable {

}
