//
//  Person2+CoreDataClass.swift
//  coreData
//
//  Created by Priyanka on 08/10/25.
//
//

import Foundation
import CoreData

@objc(Person2)
public class Person2: NSManagedObject {

}
