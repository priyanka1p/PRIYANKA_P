import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext

    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Item.timestamp, ascending: true)],
        animation: .default)
    private var items: FetchedResults<Item>
    
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Person2.name, ascending: true)],
        animation: .default)
    private var persons: FetchedResults<Person2>
    
    @State private var showAddPersonSheet = false
    @State private var newPersonName = ""
    @State private var newPersonSubjects = ""

    var body: some View {
        NavigationStack {
            List {
                Section("Items") {
                    ForEach(items) { item in
                        NavigationLink {
                            Text("Item at \(item.timestamp!, formatter: itemFormatter)")
                        } label: {
                            Text(item.timestamp!, formatter: itemFormatter)
                        }
                    }
                    .onDelete(perform: deleteItems)
                }

                Section("Persons") {
                    ForEach(persons) { person in
                        NavigationLink {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("Name: \(person.name ?? "Unknown")")
                                Text("Subjects: \(person.subjects?.joined(separator: ", ") ?? "None")")
                            }
                            .padding()
                        } label: {
                            Text(person.name ?? "Unknown")
                        }
                    }
                    .onDelete(perform: deletePersons)
                }
            }
            .navigationTitle("Items & Persons")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                }
                ToolbarItemGroup {
                    Button(action: addItem) {
                        Label("Add Item", systemImage: "plus")
                    }
                    Button(action: { showAddPersonSheet = true }) {
                        Label("Add Person", systemImage: "person.badge.plus")
                    }
                }
            }
            .sheet(isPresented: $showAddPersonSheet) {
                VStack(spacing: 20) {
                    Text("Add New Person")
                        .font(.headline)
                    
                    TextField("Enter name", text: $newPersonName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                    
                    TextField("Enter subjects (comma separated)", text: $newPersonSubjects)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                    
                    HStack {
                        Button("Cancel") {
                            showAddPersonSheet = false
                            newPersonName = ""
                            newPersonSubjects = ""
                        }
                        Spacer()
                        Button("Add") {
                            addPerson(name: newPersonName, subjects: newPersonSubjects)
                            showAddPersonSheet = false
                            newPersonName = ""
                            newPersonSubjects = ""
                        }
                    }
                    .padding()
                }
                .padding()
            }
        }
    }


    private func addItem() {
        withAnimation {
            let newItem = Item(context: viewContext)
            newItem.timestamp = Date()

            saveContext()
        }
    }

    private func addPerson(name: String, subjects: String) {
        withAnimation {
            let newPerson = Person2(context: viewContext)
            newPerson.id = UUID()
            newPerson.name = name
            newPerson.subjects = subjects.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }

            saveContext()
        }
    }

    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { items[$0] }.forEach(viewContext.delete)
            saveContext()
        }
    }

    private func deletePersons(offsets: IndexSet) {
        withAnimation {
            offsets.map { persons[$0] }.forEach(viewContext.delete)
            saveContext()
        }
    }

    private func saveContext() {
        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
}

private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    return formatter
}()

//#Preview {
//    ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
//}
