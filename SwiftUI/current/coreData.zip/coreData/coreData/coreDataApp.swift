//
//  coreDataApp.swift
//  coreData
//
//  Created by Priyanka on 07/10/25.
//

import SwiftUI

@main
struct coreDataApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
