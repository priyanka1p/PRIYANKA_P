//
//  ContentView 2.swift
//  navigationStack_array
//
//  Created by Priyanka on 03/10/25.
//

import SwiftUI
struct ContentView3: View {
    var body: some View {
        NavigationStack {
            Text("Browser Content")
                .navigationTitle("My Browser")
                .toolbarRole(.editor) // Applying the browser role
                .toolbar {
                    ToolbarItem(placement: .primaryAction) {
                        Button("Add") {
                            // Action
                            
                        }
                    }
                }
        }
    }
}
#Preview {
    ContentView3()
}
