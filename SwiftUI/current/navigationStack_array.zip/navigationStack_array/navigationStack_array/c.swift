//
//  c.swift
//  navigationStack_array
//
//  Created by Priyanka on 03/10/25.
//

import SwiftUI
struct c:View {
    @State private var showDetails = false
    var favoriteColor: Color
    var body: some View {
        NavigationStack {
            VStack {
                Circle()
                    .fill(favoriteColor)
                    .frame(width: 100, height: 100)
                Button("Show details") {
                    showDetails = true
                }
            }
            .navigationDestination(isPresented: $showDetails) {
                ColorDetail(color: favoriteColor)
            }
            .navigationTitle("My Favorite Color")
            .navigationBarTitleDisplayMode(.automatic)
            
        }
    }
}
#Preview{
    c(favoriteColor: .blue)
}
struct ColorDetail: View {
    var color: Color
    var body: some View {
        Text("This is \(color)")
    }
}
