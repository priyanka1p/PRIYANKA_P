//
//  ModalToolbarExample.swift
//  navigationStack_array
//
//  Created by Priyanka on 03/10/25.
//


import SwiftUI

struct ModalToolbarExample: View {
    @State private var showModal = false
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Main View")
                .font(.title)
            
            Button("Show Modal") {
                showModal.toggle()
            }
        }
        .sheet(isPresented: $showModal) {
            ModalView()
        }
    }
}

struct ModalView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("This is a modal view")
                    .font(.title)
                
                Text("Toolbar works here too!")
            }
            .navigationTitle("Modal View")
            .toolbar {
                // Cancellation button
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") {
                        dismiss()
                    }
                }
                
                // Secondary action
                ToolbarItem(placement: .secondaryAction) {
                    Button {
                        print("Secondary action tapped")
                    } label: {
                        Image(systemName: "star")
                    }
                }
            }
        }
    }
}

#Preview {
    ModalToolbarExample()
}
