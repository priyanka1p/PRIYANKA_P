
import SwiftUI
struct HomeToolbar: ToolbarContent {
    var body: some ToolbarContent {
        ToolbarItem(placement: .navigationBarLeading) {
            Text("Home")
                .foregroundColor(.white)
        }
        ToolbarItem(placement: .principal) {
            Menu {
                Button("Save") { print("Save tapped") }
                Button("Edit") { print("Edit tapped") }
                Button("Delete") { print("Delete tapped") }
            } label: {
                HStack {
                    Image(systemName: "arrow.down")
                        .foregroundColor(.white)
                }
            }
        }
        ToolbarItem(placement: .navigationBarTrailing) {
            Button("Save") {
                print("delete document")
            }.buttonStyle(.borderless)
                .foregroundColor(.white)

        }
    }
}
struct ContentView2: View {
    var body: some View {
        NavigationStack {
            VStack {
                NavigationLink {
                    Text("HALLO!")
                } label: {
                    Text("Hello, world!")
                }
            }
            .navigationTitle("Chalo app")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                HomeToolbar()
            }
            .toolbarBackground(.blue, for: .automatic)
            .toolbarBackground(.visible, for: .automatic)
          //  .toolbar(Visibility.hidden)
           // .toolbarVisibility(.hidden, for: .navigationBar)
           // .toolbar(.hidden, for: .navigationBar)
            //.toolbarRole(.navigationStack)
            .toolbar(id: <#T##String#>, content: <#T##() -> CustomizableToolbarContent#>)
            .padding()
        }
    }
}
#Preview {
    ContentView2()
}
