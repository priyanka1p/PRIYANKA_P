

import SwiftUI

struct ToolbarSemanticNavigationStack: View {
    @State private var searchText = ""
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("Welcome to My App!")
                    .font(.title)
                
                NavigationLink("Go to Next Page", value: "SecondPage")
            }
            .navigationTitle("Home")
            .toolbar {
                //semantic- principal,status, atuomatic
                ToolbarItem(placement: .principal) {
                    Text("My App Title")
                        .font(.headline)
                        .foregroundColor(.blue)
                }
                
                // Navigation: navigation-related action
                ToolbarItem(placement: .secondaryAction) {
                    Button(action: {
                        print("Back or nav action pressed")
                    }){
                        Image(systemName: "arrow.backward")
                    }
                }
                
                // Automatic placement: let SwiftUI choose
                ToolbarItem(placement: .cancellationAction) {
                    Button(action: {
                        print("Search tapped")
                    }) {
                        Image(systemName: "magnifyingglass")
                    }
                }
            }
            // Handle NavigationLink destinations
            .navigationDestination(for: String.self) { value in
                if value == "SecondPage" {
                    SecondPage()
                   
                }
            }
        }
    }
}

#Preview {
    ToolbarSemanticNavigationStack()
}

struct SecondPage: View {
    var body: some View {
        VStack{
            Text("Second Page")
                .font(.title)
            Text("Toolbar items remain on top")
        }
        .navigationBarBackButtonHidden(true)
        
        .toolbar{
            ToolbarItemGroup(placement: .automatic){
                Button(
                    action:{
                    print("search tapped")
                    }){
                        Image(systemName:"arrow.backward")
                    }
                Button("click"){
                    print("123")
                }
            }
        }
    }
}
