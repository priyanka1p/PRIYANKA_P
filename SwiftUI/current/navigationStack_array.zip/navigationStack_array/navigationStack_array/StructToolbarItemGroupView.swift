import SwiftUI

struct StructToolbarItemGroupView: View {
    @State private var text = ""
    @State private var bold = false
    @State private var italic = false
    @State private var fontSize = 20.0

    var displayFont: Font {
        let font = Font.system(size: CGFloat(fontSize),
                               weight: bold ? .bold : .regular)
        return italic ? font.italic() : font
    }

    var body: some View {
        TextEditor(text: $text)
            .font(displayFont)
            .padding()
            .toolbar {
                ToolbarItemGroup(placement: .bottomBar) {
                    Slider(
                        value: $fontSize,
                        in: 20...120,
                        minimumValueLabel: Text("A").font(.system(size: 20)),
                        maximumValueLabel: Text("A").font(.system(size: 30))
                    ) {
                        Text("Font Size (\(Int(fontSize)))")
                    }
                    .frame(width: 200)
                    Toggle(isOn: $bold) {
                        Image(systemName: "bold")
                    }
                    Toggle(isOn: $italic) {
                        Image(systemName: "italic")
                    }
                }
            }
            .navigationTitle("My Note")
    }
}

#Preview {
    StructToolbarItemGroupView()
}
