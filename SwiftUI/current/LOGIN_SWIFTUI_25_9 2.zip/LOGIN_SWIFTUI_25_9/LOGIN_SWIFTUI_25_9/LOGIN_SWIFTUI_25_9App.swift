import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
enum Route:Hashable{
    case home
    case second
}

struct RootView: View {
    @State private var email: String = UserDefaults.standard.string(forKey: "email") ?? ""
    @State private var path = NavigationPath()

    var body: some View {
        print(email, UserDefaults.standard.bool(forKey: "isLoggedIn"))
        return NavigationStack(path: $path) {
            LoginPageUI(email: $email, path: $path)
                .navigationDestination(for: Route.self) { route in
                    switch route {
                    case .home:
                        HomePageUI(email: email, path: $path)
                    case .second:
                        second(email: email,path: $path)
                   
                    }
               
                
                
                
                    
                }
        }
        .onAppear {
                    if UserDefaults.standard.bool(forKey: "isLoggedIn") {
                        path.append(Route.home)
                    }
                }
    }
}
