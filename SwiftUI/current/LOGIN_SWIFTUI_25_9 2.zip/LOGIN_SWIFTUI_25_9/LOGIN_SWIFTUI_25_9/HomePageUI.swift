import SwiftUI

struct HomePageUI: View {
    var email: String
    @Binding var path: NavigationPath
    @State var goTo = false
    var body: some View {
        VStack(alignment:.center) {
            AsyncImage(url: URL(string: "https://images.indianexpress.com/2017/07/dhoni-m6.jpg?w=414")) { phase in
                switch phase {
                case .empty:
                    ProgressView()
                        .frame(width: 200, height: 200)

                case .success(let image):
                    image
                        .resizable()
                        .scaledToFit()
                case .failure(_):
                        Image(systemName: "photo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200, height: 200)
                            .foregroundColor(.gray)
                    
                @unknown default:
                    fatalError("Unknown error occurred")
                }
            }
            Text("Welcome!!!")
                .font(.largeTitle)
            Text(email)
                .font(.headline)
            Button("Go to Profile") {
                path.append(Route.second)
            }
//            Button("go"){
//                goTo = true
//            }
//            NavigationLink(
//                destination: second(email: email), isActive: $goTo
//            ) {EmptyView()}
            
            
            Spacer()
            
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button("Logout") {
                    UserDefaults.standard.removeObject(forKey: "isLoggedIn")
                    UserDefaults.standard.removeObject(forKey: "email")
                    path.removeLast()
                }
            }
        }
    }
}

struct second:View{
    var email:String
    @Binding var path: NavigationPath
    var body: some View{
                
        Text(email)
            .navigationBarBackButtonHidden(true)
        }
    }


