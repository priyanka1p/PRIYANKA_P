//
//  nav_splitviewApp.swift
//  nav_splitview
//
//  Created by Priyanka on 30/09/25.
//

import SwiftUI

@main
struct nav_splitviewApp: App {
    var body: some Scene {
        WindowGroup {
            ThreeColumnSampleCode()
        }
    }
}
