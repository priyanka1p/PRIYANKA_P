//
//  EnvironmentObjectApp.swift
//  EnvironmentObject
//
//  Created by Priyanka on 24/09/25.
//

import SwiftUI

//@main
//struct EnvironmentObjectExampleApp: App {
//    @StateObject var theme = Theme()
//    @StateObject var cart = CartManager()
//    
//    var body: some Scene {
//        WindowGroup {
//            ContentView()
//                .environmentObject(theme) // inject Theme
//                .environmentObject(cart)  // inject CartManager
//        }
//    }
//}
@main
struct ForwardingExampleApp: App {
    @StateObject var session = UserSession()
    
    var body: some Scene {
        WindowGroup {
            ViewA()
                .environmentObject(session) // inject once at the top
        }
    }
}
