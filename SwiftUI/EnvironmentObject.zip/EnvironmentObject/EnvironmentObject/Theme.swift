
import SwiftUI

class Theme: ObservableObject {
    @Published var primaryColor: Color = .blue
}

class CartManager: ObservableObject {
    @Published var items: [String] = []
    
    func addItem(_ item: String) {
        items.append(item)
    }
}

struct ContentView: View {
    @EnvironmentObject var theme: Theme
    @EnvironmentObject var cart: CartManager
    
    var body: some View {
        VStack(spacing: 20) {
            Text(" Shopping App")
                .font(.title)
                .foregroundColor(theme.primaryColor)
            
            Text("Items in Cart: \(cart.items.count)")
                .foregroundColor(.secondary)
            
            Button("Add Apple") {
                cart.addItem("Apple")
            }
            .padding()
            .background(theme.primaryColor)
            .foregroundColor(.white)
            .cornerRadius(10)
            
            ThemeSelectorView() // nested view also reads @EnvironmentObject
        }
        .padding()
    }
}

struct ThemeSelectorView: View {
    @EnvironmentObject var theme: Theme
    
    var body: some View {
        HStack {
            Button("Switch to Red") {
                theme.primaryColor = .red
            }
            Button("Switch to Green") {
                theme.primaryColor = .green
            }
        }
    }
}
#Preview(body: {
    ContentView()
        .environmentObject(Theme())
        .environmentObject(CartManager())
})
