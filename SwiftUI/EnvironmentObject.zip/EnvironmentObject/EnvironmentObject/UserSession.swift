import SwiftUI
class UserSession: ObservableObject {
    @Published var username: String = "Priya"
}


struct ViewA: View {
    var body: some View {
        VStack {
            Text("View A")
            ViewB()
        }
    }
}
struct ViewB: View {
    var body: some View {
        VStack {
            Text("View B")
            ViewC()
        }
    }
}

struct ViewC: View {
    var body: some View {
        VStack {
            Text("View C")
            ViewD()
        }
    }
}

struct ViewD: View {
    @EnvironmentObject var session: UserSession
    
    var body: some View {
        VStack {
            Text("View D")
            Text("Hello, \(session.username)!")
                .font(.headline)
            
            Button("Change Username") {
                session.username = "Praba"
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(8)
        }
    }
}
#Preview(body: {
    ViewA()
        .environmentObject(UserSession())
})
