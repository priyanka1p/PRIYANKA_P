//
//  stackviewApp.swift
//  stackview
//
//  Created by Priyanka on 22/09/25.
//

import SwiftUI

@main
struct stackviewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
