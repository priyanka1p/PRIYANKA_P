//
//  ContentView.swift
//  stackview
//
//  Created by Priyanka on 22/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
            VStack(alignment: .center){
                Image("facebook_80")
                    .resizable()
                    .frame(width: 100, height: 100)
                
                HStack{
                    
                    VStack(alignment: .leading,spacing: 10){
                        Text("welcome")
                            .bold()
                        Text("Hello, world!")
                            .font(.title)
                    }.background(.red)
                    Spacer()
                }
            }.background(.yellow)
                .padding(10)
                .border(.brown, width: 1)
        Spacer()
        }
}

#Preview {
    ContentView()
}
