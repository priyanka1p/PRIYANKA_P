
import SwiftUI

struct state:View {
    @State var turnOnLight = false
    var body: some View {
        Text("click to switch on or off main board")
        Button("click "){
            turnOnLight.toggle()
        }
        if turnOnLight == true{
            Image("yellow")
                .resizable()
                .frame(width: 200, height: 200)
        }
        else{
            Image("red")
                .resizable()
                .frame(width: 200, height: 200)
        }
        
        VStack{
            Text("on/off kitchen switch")
            kitchen()
        }
    }
}

struct kitchen:View {
    @State var turnOnLight:Bool = false
    var body: some View {
        Button("click "){
            turnOnLight.toggle()
        }
        if turnOnLight == true{
            Image("yellow")
                .resizable()
                .frame(width: 200, height: 200)
        }
        else{
            Image("red")
                .resizable()
                .frame(width: 200, height: 200)
        }
        
    }
}

#Preview(body: {
    state()
})
