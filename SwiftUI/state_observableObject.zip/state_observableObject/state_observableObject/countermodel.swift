
import SwiftUI

class CounterModel: ObservableObject {
    @Published var count = 0
    @Published var name = "priyanka"
}
struct c:View {
    @ObservedObject var model: CounterModel = CounterModel()
    @State var isset = false
    var body: some View {
        print("c view")
        return VStack {
            Text("c Count: \(model.count) \(model.name)")
            Button("c Increase") {
                model.count += 1   // updates model
                
            }
            CounterView(model: model)
            Button(isset ? "go to c view" : "go to parent view",action: {
                isset = isset ? false : true
            })
                .foregroundColor(.green)
                .padding()
                .border(.brown)
                .font(.largeTitle)
            if isset{
                ParentView()
            }
        }
    }
}

struct CounterView: View {
     @ObservedObject var model: CounterModel
     var body: some View {
         print("counterview")
         return VStack {
             Text("Count: \(model.count) \(model.name)")
             Button("Increase") {
                 model.count += 1   // updates model
             }
             TextField("tect",text: $model.name)
         }
    }
}

struct ParentView: View {
    @State  var model : CounterModel = CounterModel()// owner here

    var body: some View {
        VStack {
           CounterView(model: model)
            //CounterView() // shares same data!
        }
        Button("increase form parent", action: {
            model.count = 44
        })
        Text("parent : \(model.count) \(model.name)")
        
    }
}
#Preview(body: {
   c()
})
