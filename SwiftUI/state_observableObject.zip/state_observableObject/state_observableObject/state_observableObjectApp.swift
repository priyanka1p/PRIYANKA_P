//
//  state_observableObjectApp.swift
//  state_observableObject
//
//  Created by Priyanka on 22/09/25.
//
import SwiftUI

@main
struct state_observableObjectApp: App {
    var body: some Scene {
        WindowGroup {
//            state()
            observablestruct()
        }
    }
}
