
import SwiftUI
import Observation


@Observable
class Library {
     var name: String = "My library of books"
    var books: [String] = ["Swift Programming", "iOS Development", "Data Structures"]
}
struct PlayButton:View{
    @Binding var isPlaying: Bool
    var body: some View{
        print("playerbutton")
        return Button(isPlaying ? "pause" : "play"){
            isPlaying.toggle()
        }
    }
}
struct PlayerView: View {
    @State private var isPlaying: Bool = false
    
    var body: some View {
        print("PlayerView")
        return VStack {
            Text("Music Player")
                .font(.headline)
            
            PlayButton(isPlaying: $isPlaying)
            
            Text(isPlaying ? "Now playing" : "Stopped")
                .foregroundStyle(.secondary)
        }
    }
}

struct observablestruct:View{
    @State private var library: Library?
    var body: some View {
        print("observableStruct")
        print(library ?? "not createdin observable struct")
        return VStack{
            PlayerView()
            Divider()
            LibraryView(library:library)
            Spacer()
        }.task {
            print("delayed setup")
            try? await Task.sleep(for: .seconds(3))  // Pause 3 seconds
            library = Library()
        }
        .onAppear(){
            print("observable struct on appear")
        }

    }
}


struct LibraryView: View {
 var library: Library?

 var body: some View {
     print("LibraryView")
     print(library ?? "not created")
     return VStack(alignment: .leading) {
         if let library {
             Text(library.name)
                 .font(.title2)
             ForEach(library.books, id: \.self) { book in
                 Text("📖 \(book)")
             }
         } else {
             
             ProgressView("Loading Library…")
         }
     }
     .padding()
     .border(.gray.opacity(0.4))
 }
}
#Preview(body: {
    observablestruct()
})
