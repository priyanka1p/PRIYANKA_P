
import SwiftUI

class DataModel: ObservableObject {
    @Published var name: String
    
    init(name: String) {
        self.name = name
        print("DataModel initialized with name: \(name)")
    }
}

struct MyInitializableView: View {
    @StateObject private var model: DataModel
    
    init(name: String) {
        // Explicitly initialize StateObject
        _model = StateObject(wrappedValue: DataModel(name: name))
    }
    
    var body: some View {
        print("my init view 1")
        return VStack {
            Text("Name: \(model.name)")
                .font(.title)
                .padding()
            Button("Change Model Name") {
                model.name = "Updated \(model.name)"
            }
        }
        .border(Color.blue, width: 2)
        .padding()
    }
}

struct ContentView: View {
    @State private var currentName = "Ravi"
    
    var body: some View {
        print("1")
        return VStack(spacing: 20) {
            // Controls the input to MyInitializableView
            Button("Switch Name") {
                currentName = (currentName == "Ravi") ? "Maria" : "Ravi"
            }
            
            // Use .id() to force reinitialization when currentName changes
            MyInitializableView(name: currentName)
                            .id(currentName) // Changing identity recreates the view & StateObject
            
            Button("Switch Name") {
                currentName = (currentName == "Ravi") ? "Maria" : "Ravi"
            }
            
            // Use .id() to force reinitialization when currentName changes
            MyInitializableView(name: currentName)
                            .id(currentName)
        }
        .padding()
    }
}

#Preview(body:{
    ContentView()
})
