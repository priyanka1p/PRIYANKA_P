import SwiftUI

@Observable
class LoginPageModel {
    var email:String = ""
    var password:String = ""
    var loginValidationLabel:String = ""
    
    func loginButtonPressed(email:String,password:String){
                print(email,password)
        let email = email.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = password.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if let saved_password = emailDatabase[email]{
            if saved_password == password{
                loginValidationLabel = "Login Successful"
            }
            else{
                loginValidationLabel = "Wrong Password"
            }
        }
        else{
            loginValidationLabel = "Email not found"
        }
    }
}
let emailDatabase: [String: String] = [
    "J@GMAIL.COM": "J",
    "alice@example.com": "Alice@123",
    "priya@gmail.com": "Priya@123"
]
struct LoginPageUI:View {
    @Bindable var loginPageModel:LoginPageModel = LoginPageModel()
    @State var isPasswordVisible: Bool = false
    var body: some View {
        ScrollView{
            VStack(alignment: .leading) {
                
                VStack(alignment:.leading){
                    Text("Parent/Guardian Log In")
                        .fontWeight(.bold)
                        .font(.title)
                    Text("Email")
                        .font(.headline)
                    TextField("enter your email address",text: $loginPageModel.email)
                        .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)

                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    Text("Password")
                        .font(.headline)
                    HStack {
                        if isPasswordVisible {
                            TextField("enter your password", text: $loginPageModel.password)
                                .textInputAutocapitalization(.never)
                        } else {
                            SecureField("enter your password", text: $loginPageModel.password)
                                .textInputAutocapitalization(.never)   
                        }
                        
                        Button(action: {
                            isPasswordVisible.toggle()
                        }) {
                            Image(systemName: isPasswordVisible ? "eye.slash.fill" : "eye.fill")
                                .foregroundColor(.gray)
                        }
                        
                    }
                    
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                    
                    Text(loginPageModel.loginValidationLabel)
                        .font(.system(size: 12))
                    
                    Spacer()
                        .frame(height: 20)
                    //                    priya@gmail.com
                    Button("Log In"){
                        loginPageModel.loginButtonPressed(email: loginPageModel.email, password: loginPageModel.password)
                        print("logged in")
                    }
                    .padding(5)
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(5)
                    
                }
                .padding(.leading,10)
                .padding(.trailing,10)
                
                HStack{
                    Spacer()
                    VStack{
                        Text("Or")
                        HStack(spacing: 20){
                            Image("facebook_80")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .shadow(color: .black.opacity(0.5), radius: 7, x: 0, y: 0)
                            
                            Image("google_80")
                                .resizable()
                                .frame(width: 40, height: 40)
                            
                                .shadow(color: .black.opacity(0.5), radius: 7, x: 0, y: 0)
                            Image("apple_80")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .shadow(color: .black.opacity(0.5), radius: 7, x: 0, y: 0)
                        }
                    }
                    Spacer()
                }
                
                VStack(alignment: .leading){
                    HStack{
                        Image(systemName: "network")
                        Text("Forgot your password?")
                            .foregroundColor(Color.blue)
                    }.padding(.top,2)
                    HStack{
                        Image(systemName: "person.fill")
                        Text("Don't have an account? Sign Up")
                            .foregroundColor(Color.blue)
                    }.padding(.top,2)
                }.padding(.leading,10)
            }
        }.padding(.top,50)
    }
    
}

#Preview {
    LoginPageUI()
}



