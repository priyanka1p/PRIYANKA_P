//
//  Person.swift
//  now
//
//  Created by Priyanka on 24/09/25.
//


import SwiftUI

struct Person:Identifiable{
    let id: UUID = UUID()
    let name: String
    let age: Int
}

struct ContentView: View {
    // Sample data
    let people = [
        Person(name: "Alice", age: 25),
        Person(name: "Bob", age: 30),
        Person(name: "Charlie", age: 25),
        Person(name:"Alice", age:25)
    ]
    
    var body: some View {
        
            List() {
                ForEach(people) { person in
                        Text("\(person.name)")
                }
            }
          
    }
}

#Preview {
    ContentView()
}
