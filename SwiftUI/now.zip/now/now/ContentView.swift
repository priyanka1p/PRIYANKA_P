import SwiftUI
import Observation

@Observable
class CounterState {
    var count: Int = 0
    init(count: Int) {
        self.count = count
    }
    init(){
        self.count = 10
    }
}

struct StateExampleView: View {
    @Bindable var counter = CounterState() 
    
    var body: some View {
        print("State count = \(counter.count)")
        
        return VStack(spacing: 20) {
            Text("Count: \(counter.count)")
            
            Button("Increment") {
                counter.count += 1
            }
            Text("Count: \(counter.count)")

            ChildViewState(counter: counter)
        }
        .padding()
    }
}

struct ChildViewState: View {
    @Bindable var counter: CounterState
    
    var body: some View {
        print("Child count = \(counter.count)")
       
        return VStack{Text("Child Count: \(counter.count)")
                .padding()
                .background(Color.green.opacity(0.3))
                .cornerRadius(8)
            Button("in",action: {
                counter.count = counter.count + 10
//                counter = CounterState(count: 299)
            })
        }
    }
}
#Preview {
        StateExampleView()
}
