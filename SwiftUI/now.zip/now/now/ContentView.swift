import SwiftUI
import Observation

// MARK: - Observable Class
@Observable
class CounterState {
    var count: Int = 0
    init(count: Int) {
        self.count = count
    }
    init(){
        self.count = 10
    }
}

// MARK: - Parent View with @State
struct StateExampleView: View {
    @Bindable var counter = CounterState() // Owns the reference only
    
    var body: some View {
        print("StateExampleView body recomputed: count = \(counter.count)")
        
        return VStack(spacing: 20) {
            Text("Count: \(counter.count)")
            
            Button("Increment") {
                counter.count += 1
            }
            Text("Count: \(counter.count)")

            ChildViewState(counter: counter)
        }
        .padding()
    }
}

// MARK: - Child View
struct ChildViewState: View {
    @Bindable var counter: CounterState
    
    var body: some View {
        print("ChildViewState body recomputed: count = \(counter.count)")
       
        return VStack{Text("Child Count: \(counter.count)")
                .padding()
                .background(Color.green.opacity(0.3))
                .cornerRadius(8)
            Button("in",action: {
                counter.count = counter.count + 10
//                counter = CounterState(count: 299)
            })
        }
    }
}
#Preview {
        StateExampleView()
}
