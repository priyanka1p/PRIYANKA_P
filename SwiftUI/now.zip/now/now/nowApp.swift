//
//  nowApp.swift
//  now
//
//  Created by Priyanka on 24/09/25.
//

import SwiftUI

@main
struct nowApp: App {
    var body: some Scene {
        WindowGroup {
            StateExampleView()        }
    }
}
