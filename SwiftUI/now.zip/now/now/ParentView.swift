//
//  ParentView.swift
//  now
//
//  Created by Priyanka on 24/09/25.
//
import SwiftUI
import Observation
@Observable
class Counter {
    var count: Int = 0
    init(count: Int) {
        self.count = count
    }
    init(){
        self.count = 10
    }
}
struct ParentView: View {
    @State var counter = Counter()
    @State var isState: Bool = false
    var body: some View {
        ChildView(counter: $counter.count) // Binding to a property
            .font(.largeTitle)
        Button("Increment count",action: {
            counter.count += 1
        })
        Button(!isState ? "go to secondary view" : "go to primary view",action: {
            isState = !isState
        }).font(.headline)
        if isState == true{
            secondaryView()
        }
    }
}

struct secondaryView: View {
    @State var counter = Counter()
    var body: some View {
        Group{
            Text("Hello, World!")
                .padding(.top,100)
            Button("increment",action: {
                counter.count += 1
            })
            Text("count: \(counter.count)")
        }.font(.title)
        ChildView(counter: $counter.count) // Binding to a property
            .font(.largeTitle)
    }
}

struct ChildView: View {
    @Binding var counter: Int
    var body: some View{
        Button(" increment fromc hild",action:{
            counter = counter + 1
        })
        Text("\(counter)")
    }
}
#Preview(body: {
    ParentView()
})
