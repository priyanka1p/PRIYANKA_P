import SwiftUI
import Combine

class ArticleViewModel: ObservableObject {
    @Published var title: String = "Initial Title"
}

struct publishedContentView: View {
    @StateObject private var viewModel = ArticleViewModel()
    @State private var cancellable: AnyCancellable?
    @State private var labelText: String = ""

    var body: some View {
        VStack(spacing: 20) {
            Text(labelText)
                .font(.title)
                .padding()

            Button("Change Title") {
                viewModel.title = "Changed Title"
            }
        }
        .onAppear {
            cancellable = viewModel.$title.sink { newTitle in

                
                print("Published newTitle: \(newTitle)")
                

                labelText = newTitle
                
                print("Label text updated to: \(labelText)")
            }
        }
    }
}

#Preview(body: {
    publishedContentView()
})
