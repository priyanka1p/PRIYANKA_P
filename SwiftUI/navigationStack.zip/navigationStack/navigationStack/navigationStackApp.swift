//
//  navigationStackApp.swift
//  navigationStack
//
//  Created by Priyanka on 26/09/25.
//

import SwiftUI

@main
struct navigationStackApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
