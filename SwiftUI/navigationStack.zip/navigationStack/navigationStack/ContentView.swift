import SwiftUI

struct Park: Identifiable, Hashable, Codable {
    var id = UUID()
    let name: String
}

struct Museum: Identifiable, Hashable, Codable {
    var id = UUID()
    let name: String
}

class NavigationModel: ObservableObject {
    @Published var path = NavigationPath()
    
    func save() {
        guard let representation = path.codable else { return }
        if let data = try? JSONEncoder().encode(representation) {
            UserDefaults.standard.set(data, forKey: "navPath")
        }
    }
    
    func restore() {
        guard let data = UserDefaults.standard.data(forKey: "navPath"),
              let representation = try? JSONDecoder().decode(NavigationPath.CodableRepresentation.self, from: data) else {
            path = NavigationPath()
            return
        }
        path = NavigationPath(representation)
    }
}

struct ContentView: View {
    @StateObject private var navModel = NavigationModel()
    @Environment(\.scenePhase) private var scenePhase
    
    let parks = [Park(name: "Yosemite"), Park(name: "Sequoia"), Park(name: "Yellowstone")]
    let museums = [Museum(name: "Louvre"), Museum(name: "Metropolitan"), Museum(name: "British Museum")]
    
    var body: some View {
        NavigationStack(path: $navModel.path) {
            List {
                Section("Parks") {
                    ForEach(parks) { park in
                        NavigationLink(park.name, value: park)
                    }
                }
                
                Section("Museums") {
                    ForEach(museums) { museum in
                        NavigationLink(museum.name, value: museum)
                    }
                }
                
                Button("Show Yosemite & Louvre Programmatically") {
                    navModel.path = NavigationPath()
                    navModel.path.append(parks[0])
                    navModel.path.append(museums[0])
                }
            }
            .navigationTitle("Places")
            // Navigation destinations
            .navigationDestination(for: Park.self) { park in
                ParkDetailView(park: park)
            }
            .navigationDestination(for: Museum.self) { museum in
                MuseumDetailView(museum: museum)
            }
        }
        // Save state when app goes to background
        .onChange(of: scenePhase) { oldValue, newValue in
            if newValue == .background {
                print("background")
                navModel.save()
            }
        }

        .onAppear {
            print("onappear")
            navModel.restore()
        }
    }
}

struct ParkDetailView: View {
    let park: Park
    var body: some View {
        VStack {
            Text(park.name)
                .font(.largeTitle)
                .padding()
            Text("Beautiful national park!")
        }
    }
}

struct MuseumDetailView: View {
    let museum: Museum
    var body: some View {
        VStack {
            Text(museum.name)
                .font(.largeTitle)
                .padding()
            Text("Famous museum!")
        }
    }
}


