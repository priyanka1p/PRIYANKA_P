//
//  ViewController.swift
//  coreDataUIKit
//
//  Created by Priyanka on 08/10/25.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBAction func editbutton(_ sender: Any) {
        guard let barButton = sender as? UIBarButtonItem else { return }
        tableView.setEditing(!tableView.isEditing, animated: true)
        if tableView.isEditing {
            barButton.title = "Done"
        } else {
            barButton.title = "Edit"
        }
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    var people:[Person] = []
    let container = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        title = "The List"
        fetchPeople()
        
    }
    func fetchPeople(){
        guard let context = context else{return }
        let req = Person.fetchRequest() as NSFetchRequest<Person>
        do{
            self.people = try context.fetch(req)
        }catch{
            print("error")
        }
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
    }
    
    @IBAction func addName(_ sender: UIBarButtonItem) {
        let addButton = sender
        
        let alert = UIAlertController(title: "New Name",
                                      message: "Add a new name",
                                      preferredStyle: .alert)
        
        let saveAction = UIAlertAction(title: "Save", style: .default)
        { [weak self] action in
            addButton.isEnabled = false
            
            guard let textField = alert.textFields?.first,
                  let nameToSave = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines),
                  !nameToSave.isEmpty else { return }
            
            DispatchQueue.global().async{
                self?.save(name: nameToSave) {
                    addButton.isEnabled = true
                    print("Save completed, button re-enabled")
                }
            }
            print("function save2 completed")
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)
        alert.addTextField()
        alert.addAction(cancelAction)
        alert.addAction(saveAction)
        
        present(alert, animated: true)
    }
    
    func save(name: String, completion: @escaping () -> Void) {
        let backgroundContext = self.container?.newBackgroundContext()
        backgroundContext?.performAndWait {
            guard let bg = backgroundContext else { return }
            
            let entity = Person(context: bg)
            entity.name = name
            print("Background insert: \(name)")
            
            do {
                try bg.save()
                print("Background save completed: \(name)")
            } catch {
                print("BG save error: \(error)")
            }
            print("98")

            self.context?.performAndWait {
                print("Fetching people after background save for: \(name)")
                self.fetchPeople()
                print("101")
            }
            print("103")
            self.context?.perform {
                completion()
            }
        }
    }

}
    


extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = people[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView,
                   commit editingStyle: UITableViewCell.EditingStyle,
                   forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            guard let context = context else { return }
            let personToDelete = people[indexPath.row]
            context.delete(personToDelete)
            do {
                try context.save()
            } catch {
                print("Failed to delete person: \(error)")
                return
            }
            people.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let alert = UIAlertController(title: "add", message: "edit name", preferredStyle: .alert)
        alert.addTextField()
        alert.textFields?.first?.text = self.people[indexPath.row].name
        let submit = UIAlertAction(title: "submit", style: .default) { (_) in
            let person = self.people[indexPath.row]
            person.name = alert.textFields?.first?.text
            do{
                try self.context?.save()
            }catch{
                print("error iin save")
            }
            self.fetchPeople()
        }
        alert.addAction(submit)
        present(alert,animated: true)
        
    }
}
        
    

    

