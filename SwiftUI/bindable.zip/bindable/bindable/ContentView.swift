import SwiftUI
import Observation
//@Observable marks a class as observable.
//Swift automatically synthesizes a publisher for all its properties.
@Observable
class Book{
    var title: String = "Bhagat Singh"
    var isavailable: Bool = true
    var bookcount: Int = 5
}

struct BookView:View{
    //@Bindable is a property wrapper that lets a view own and observe an @Observable object.
    
//    It automatically subscribes to all property changes in the object.
    @State var book: Book = Book()
    @State var total = 0
    var body: some View{
        return VStack{
            Text("Book Title: \(book.title)")
            if book.isavailable{
                HStack{
                    Text("Add book to cart")
                    Button("Click", action:{
                        book.bookcount -= 1
                        total = total + 1
                        if book.bookcount == 0{
                            book.isavailable = false
                        }
                    })
                        .padding(10)
                        .background(Color.yellow)
                        .foregroundColor(.accentColor)
                    
                }
                Text("Item added: \(total)")
            }
            
        }
    }
}
#Preview(body: {
    BookView()
    
})
