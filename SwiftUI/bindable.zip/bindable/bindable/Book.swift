//
//  Book.swift
//  bindable
//
//  Created by Priyanka on 23/09/25.
//


import SwiftUI
import Combine

// Model
class nBook: ObservableObject, Identifiable {
    @Published var title: String = "Bhagat Singh"
    @Published var isavailable: Bool = true
    @Published var bookcount: Int = 5
}

// View
struct nBookView: View {
    //Here, the same view both owns and tries to mutate an ObservableObject class inside @State.
//    @State is not designed to subscribe to @Published. It only tracks the variable itself.
//    Mutating book.bookcount triggers changes inside the class, but SwiftUI doesn’t know about it, which can cause undefined behavior or crashes.
//    @State var book = nBook()
    @StateObject var book = nBook()
    @State var total = 0                // Local state for items added
    
    var body: some View {
        VStack(spacing: 10) {
            Text("Book Title: \(book.title)")
                .font(.headline)
            
            Text("Book count left: \(book.bookcount)")
            Text("Item added: \(total)")
            
            // Show button only if available
            if book.isavailable {
                HStack {
                    Text("Add book to cart")
                    Button("Click") {
                        book.bookcount -= 1
                        total += 1
                        if book.bookcount == 0 {
                            book.isavailable = false
                        }
                    }
                    .padding(10)
                    .background(Color.yellow)
                    .foregroundColor(.black)
                    .cornerRadius(8)
                }
            }
        }
        .padding()
    }
}

// Preview
#Preview {
    nBookView()
}
