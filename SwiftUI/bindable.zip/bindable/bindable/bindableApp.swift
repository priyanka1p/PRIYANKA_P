import SwiftUI

@main
struct bindableApp: App {
    var body: some Scene {
        WindowGroup {
//            BookView()
//            ContentView()
            dBookView()
        }
    }
}
