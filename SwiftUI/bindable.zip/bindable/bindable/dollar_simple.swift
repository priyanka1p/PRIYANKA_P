import SwiftUI
import Observation

@Observable
class dBook: Identifiable {
    var title = "Sample Book Title"
    var isAvailable = true
}

struct dBookView: View {
    @Bindable var book = dBook()   // Owns and observes Book

    var body: some View {
        VStack(spacing: 20) {
            Text("Book Title: \(book.title)")
                .font(.title2)
            
            Text("Available: \(book.isAvailable ? "Yes" : "No")")
            
            Divider()
            
            // Edit fields $ is used when you need a Binding.
//            A Binding is a two-way connection: the control can read and write the value.
            TextField("Title", text: $book.title)
                .textFieldStyle(.roundedBorder)
                .padding(.horizontal)
            
            
            Toggle("Neet a Print Copy", isOn: $book.isAvailable)
                .padding(.horizontal)
            if book.isAvailable {
                Text("Added a print copy")
            }
            else{
                Text("enable the button for a print copy")
            }
        }
        .padding()
    }
}

// MARK: - Preview
#Preview {
    dBookView()
}
