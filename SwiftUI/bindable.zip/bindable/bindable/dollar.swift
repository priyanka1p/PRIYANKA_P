import SwiftUI
import Observation

// MARK: - Model
@Observable
class rBook: Identifiable {
    var title = "Sample Book Title"
    var isAvailable = true
}

// MARK: - Parent View
struct ContentView: View {
    @Bindable var book = rBook()   // Owns and observes Book
    @State private var showEditor = false
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("Book Title: \(book.title)")
                    .font(.title2)
                
                Text("Available: \(book.isAvailable ? "Yes" : "No")")
                
                Button("Edit Book") {
                    showEditor = true
                }
                .padding()
                .background(Color.blue.opacity(0.7))
                .foregroundColor(.white)
                .cornerRadius(8)
            }
            .padding()
            .navigationDestination(isPresented: $showEditor) {
                BookEditView(book: book)
            }
        }
    }
}

// MARK: - Edit View
struct BookEditView: View {
    @Bindable var book: rBook       // Binding to book
    @Environment(\.dismiss) var dismiss

    var body: some View {
        Form {
            TextField("Title", text: $book.title)
            
            Toggle("Book is available", isOn: $book.isAvailable)
           
        }
        Button("Close") {
            dismiss()
        }
        .navigationTitle("Edit Book")
       
    }
}

// MARK: - Preview
#Preview {
    ContentView()
}
